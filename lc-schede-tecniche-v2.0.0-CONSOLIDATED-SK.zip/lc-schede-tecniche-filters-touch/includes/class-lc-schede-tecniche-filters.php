<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class LC_Schede_Tecniche_Filters {

    protected $post_type = 'scheda-tecnica';
    protected $filters_option = 'lc_stf_enabled_tax_filters';
    protected $quotes_option  = 'lc_stf_daily_quotes';

    protected $nameday_enabled_option = 'lc_stf_nameday_enabled';
    protected $nameday_table_option   = 'lc_stf_nameday_table';

    /**
     * Mapping COMPLETO: JetEngine meta field => taxonomy slug
     * Consolidato da lc-jetengine-taxonomy-sync
     */
    protected $meta_to_taxonomy_map = array(
        // Campi principali
        'cliente'           => 'clienti',
        'tipologia'         => 'tipologia',

        // Jadro (nucleo)
        'jadro'             => 'jadro',

        // Stoffe (tessuti) - tutti verso la stessa tassonomia
        'stoffa_sopra'      => 'stoffa',
        'stoffa_sotto'      => 'stoffa',
        'stoffa_lato'       => 'stoffa',

        // Trapuntature - tutti verso la stessa tassonomia
        'trapuntatura_sopra'=> 'trapuntatura',
        'trapuntatura_sotto'=> 'trapuntatura',
        'trapuntatura_lato' => 'trapuntatura',

        // Disegni - tutti verso la stessa tassonomia
        'disegno_sopra'     => 'disegno',
        'disegno_sotto'     => 'disegno',
        'disegno_lato'      => 'disegno',

        // Altri componenti
        'lemovka'           => 'lemovka',
        'vypuska'           => 'vypuska',
        'zip'               => 'zip',
        'bezec'             => 'bezec',
        '3d'                => '3d',
        'elastico'          => 'elastico',
        'etikety'           => 'etikety',
        'plagaty'           => 'plagaty',
        'imballaggio'       => 'imballaggio',
        'poznamky_opt'      => 'poznamky-opt',
    );

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_settings_page' ) );

        // Sincronizzazione automatica meta field → tassonomia
        add_action( 'save_post', array( $this, 'sync_meta_to_taxonomy' ), 20, 2 );
        add_action( 'jet-engine/meta-boxes/save-post', array( $this, 'sync_meta_to_taxonomy_jet' ), 20, 2 );
    }

    /**
     * Sincronizza i meta field di JetEngine con le tassonomie corrispondenti
     */
    public function sync_meta_to_taxonomy( $post_id, $post = null ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        if ( wp_is_post_revision( $post_id ) ) {
            return;
        }

        $post_type = get_post_type( $post_id );
        if ( ! in_array( $post_type, array( 'scheda-tecnica', 'scheda_tecnica' ), true ) ) {
            return;
        }

        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        $this->do_meta_taxonomy_sync( $post_id );
    }

    /**
     * Hook specifico per JetEngine meta boxes
     */
    public function sync_meta_to_taxonomy_jet( $post_id, $meta_fields = array() ) {
        $post_type = get_post_type( $post_id );
        if ( ! in_array( $post_type, array( 'scheda-tecnica', 'scheda_tecnica' ), true ) ) {
            return;
        }

        $this->do_meta_taxonomy_sync( $post_id );
    }

    /**
     * Esegue la sincronizzazione effettiva
     * Gestisce correttamente il caso di più meta field che puntano alla stessa tassonomia
     */
    protected function do_meta_taxonomy_sync( $post_id ) {
        // Raggruppa per tassonomia per evitare sovrascritture
        $taxonomy_terms = array();

        foreach ( $this->meta_to_taxonomy_map as $meta_key => $taxonomy_slug ) {
            if ( ! taxonomy_exists( $taxonomy_slug ) ) {
                continue;
            }

            $meta_value = get_post_meta( $post_id, $meta_key, true );

            if ( empty( $meta_value ) ) {
                continue;
            }

            // Inizializza l'array per questa tassonomia se non esiste
            if ( ! isset( $taxonomy_terms[ $taxonomy_slug ] ) ) {
                $taxonomy_terms[ $taxonomy_slug ] = array();
            }

            // Gestisci valori multipli (array) e singoli
            $values = is_array( $meta_value ) ? $meta_value : array( $meta_value );

            foreach ( $values as $value ) {
                $term = $this->resolve_term_from_value( $value, $taxonomy_slug );
                if ( $term ) {
                    $taxonomy_terms[ $taxonomy_slug ][] = $term->term_id;
                }
            }
        }

        // Assegna i termini alle tassonomie (rimuove duplicati)
        foreach ( $taxonomy_terms as $taxonomy_slug => $term_ids ) {
            $term_ids = array_unique( $term_ids );

            if ( ! empty( $term_ids ) ) {
                wp_set_object_terms( $post_id, $term_ids, $taxonomy_slug );
            }
        }

        // Pulisci tassonomie che non hanno più valori
        $all_taxonomies = array_unique( array_values( $this->meta_to_taxonomy_map ) );
        foreach ( $all_taxonomies as $taxonomy_slug ) {
            if ( ! isset( $taxonomy_terms[ $taxonomy_slug ] ) || empty( $taxonomy_terms[ $taxonomy_slug ] ) ) {
                // Verifica se NESSUN campo punta a questa tassonomia con valori
                $has_values = false;
                foreach ( $this->meta_to_taxonomy_map as $mk => $ts ) {
                    if ( $ts === $taxonomy_slug ) {
                        $mv = get_post_meta( $post_id, $mk, true );
                        if ( ! empty( $mv ) ) {
                            $has_values = true;
                            break;
                        }
                    }
                }

                if ( ! $has_values && taxonomy_exists( $taxonomy_slug ) ) {
                    wp_set_object_terms( $post_id, array(), $taxonomy_slug );
                }
            }
        }
    }

    /**
     * Risolve un valore (ID, nome, slug) in un oggetto WP_Term
     */
    protected function resolve_term_from_value( $value, $taxonomy_slug ) {
        if ( empty( $value ) ) {
            return null;
        }

        // Se è un ID numerico
        if ( is_numeric( $value ) ) {
            $term = get_term( (int) $value, $taxonomy_slug );
            if ( $term && ! is_wp_error( $term ) ) {
                return $term;
            }

            // Potrebbe essere un post ID (relazione JetEngine)
            $related_post = get_post( (int) $value );
            if ( $related_post ) {
                $term_name = $related_post->post_title;
                $term = get_term_by( 'name', $term_name, $taxonomy_slug );
                if ( $term && ! is_wp_error( $term ) ) {
                    return $term;
                }
                $term = get_term_by( 'slug', sanitize_title( $term_name ), $taxonomy_slug );
                if ( $term && ! is_wp_error( $term ) ) {
                    return $term;
                }
            }
        }

        // Se è una stringa, cerca per nome o slug
        $value = (string) $value;

        $term = get_term_by( 'name', $value, $taxonomy_slug );
        if ( $term && ! is_wp_error( $term ) ) {
            return $term;
        }

        $term = get_term_by( 'slug', $value, $taxonomy_slug );
        if ( $term && ! is_wp_error( $term ) ) {
            return $term;
        }

        $term = get_term_by( 'slug', sanitize_title( $value ), $taxonomy_slug );
        if ( $term && ! is_wp_error( $term ) ) {
            return $term;
        }

        return null;
    }

    protected function detect_post_type() {
        if ( post_type_exists( 'scheda_tecnica' ) ) {
            $this->post_type = 'scheda_tecnica';
        } elseif ( post_type_exists( 'scheda-tecnica' ) ) {
            $this->post_type = 'scheda-tecnica';
        }

        if ( $this->post_type && post_type_exists( $this->post_type ) ) {
            add_post_type_support( $this->post_type, 'thumbnail' );
            add_post_type_support( $this->post_type, 'excerpt' );
        }
    }

    public function add_settings_page() {
        $this->detect_post_type();
        if ( ! post_type_exists( $this->post_type ) ) { return; }

        $parent_slug = 'edit.php?post_type=' . $this->post_type;

        add_submenu_page(
            $parent_slug,
            __( 'Filtre, citáty a meniny', 'lc-stf' ),
            __( 'Filtre, citáty a meniny', 'lc-stf' ),
            'manage_options',
            'lc-stf-filters',
            array( $this, 'render_settings_page' )
        );
    }

    public function render_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        $this->detect_post_type();

        if ( isset( $_POST['lc_stf_save_settings'] ) && check_admin_referer( 'lc_stf_save_settings_action', 'lc_stf_nonce' ) ) {

            $enabled = isset( $_POST['lc_stf_taxonomies'] ) ? (array) $_POST['lc_stf_taxonomies'] : array();
            $enabled = array_map( 'sanitize_text_field', $enabled );
            update_option( $this->filters_option, $enabled );

            $quotes_raw = isset( $_POST['lc_stf_quotes'] ) ? wp_unslash( $_POST['lc_stf_quotes'] ) : '';
            $quotes_raw = str_replace( array( "\r\n", "\r" ), "\n", $quotes_raw );
            $lines      = preg_split( "/\r\n|\r|\n/", $quotes_raw );
            $lines      = array_filter( array_map( 'trim', (array) $lines ) );
            update_option( $this->quotes_option, $lines );

            $nameday_enabled = ! empty( $_POST['lc_stf_nameday_enabled'] ) ? 1 : 0;
            update_option( $this->nameday_enabled_option, $nameday_enabled );

            $table_raw = isset( $_POST['lc_stf_nameday_table'] ) ? wp_unslash( $_POST['lc_stf_nameday_table'] ) : '';
            $table_raw = str_replace( array( "\r\n", "\r" ), "\n", $table_raw );
            $rows      = preg_split( "/\r\n|\r|\n/", $table_raw );
            $table     = array();

            foreach ( $rows as $row ) {
                $row = trim( $row );
                if ( '' === $row || 0 === strpos( $row, '#' ) ) { continue; }
                $parts = array_map( 'trim', explode( '|', $row ) );
                if ( empty( $parts[0] ) ) { continue; }
                $date = $parts[0];
                if ( ! preg_match( '/^\d{2}-\d{2}$/', $date ) ) { continue; }
                $names   = isset( $parts[1] ) ? $parts[1] : '';
                $holiday = isset( $parts[2] ) ? $parts[2] : '';
                $table[ $date ] = array( 'names' => $names, 'holiday' => $holiday );
            }

            update_option( $this->nameday_table_option, $table );

            echo '<div class="updated"><p>' . esc_html__( 'Nastavenia boli uložené.', 'lc-stf' ) . '</p></div>';
        }

        // Gestione sincronizzazione manuale
        if ( isset( $_POST['lc_stf_sync_all'] ) && check_admin_referer( 'lc_stf_sync_all_action', 'lc_stf_sync_nonce' ) ) {
            $synced = $this->sync_all_posts();
            echo '<div class="updated"><p>' . sprintf(
                esc_html__( 'Synchronizácia dokončená! %d technických kariet synchronizovaných.', 'lc-stf' ),
                $synced
            ) . '</p></div>';
        }

        $taxonomies      = $this->get_all_taxonomies();
        $enabled_current = $this->get_enabled_taxonomies_slugs( false );

        $quotes = get_option( $this->quotes_option, array() );
        if ( ! is_array( $quotes ) ) { $quotes = array(); }
        $quotes_text = implode( "\n", $quotes );

        $nameday_enabled = (int) get_option( $this->nameday_enabled_option, 0 );
        $nameday_table   = get_option( $this->nameday_table_option, array() );

        $nameday_lines = array();
        if ( is_array( $nameday_table ) ) {
            foreach ( $nameday_table as $date => $row ) {
                $names   = isset( $row['names'] ) ? $row['names'] : '';
                $holiday = isset( $row['holiday'] ) ? $row['holiday'] : '';
                $nameday_lines[] = $date . ' | ' . $names . ' | ' . $holiday;
            }
        }
        $nameday_text = implode( "\n", $nameday_lines );
        ?>

        <div class="wrap">
            <h1><?php esc_html_e( 'Filtre, motivačné citáty a meniny', 'lc-stf' ); ?></h1>

            <form method="post">
                <?php wp_nonce_field( 'lc_stf_save_settings_action', 'lc_stf_nonce' ); ?>

                <h2><?php esc_html_e( 'Filtre pre CPT „scheda tecnica"', 'lc-stf' ); ?></h2>
                <p><?php esc_html_e( 'Vyber taxonómie, ktoré sa majú použiť ako filtre v dotykovej mriežke.', 'lc-stf' ); ?></p>

                <table class="form-table" role="presentation"><tbody>
                <?php if ( ! empty( $taxonomies ) ) : ?>
                    <?php foreach ( $taxonomies as $tax ) : ?>
                        <tr>
                            <th scope="row">
                                <label for="lc_stf_tax_<?php echo esc_attr( $tax->name ); ?>"><?php echo esc_html( $tax->label ); ?></label>
                            </th>
                            <td>
                                <label>
                                    <input type="checkbox"
                                           id="lc_stf_tax_<?php echo esc_attr( $tax->name ); ?>"
                                           name="lc_stf_taxonomies[]"
                                           value="<?php echo esc_attr( $tax->name ); ?>"
                                        <?php checked( in_array( $tax->name, (array) $enabled_current, true ) ); ?>
                                    >
                                    <?php printf( esc_html__( 'Použiť %s ako filter', 'lc-stf' ), esc_html( $tax->label ) ); ?>
                                </label>
                                <p class="description"><?php printf( esc_html__( 'Slug: %s', 'lc-stf' ), esc_html( $tax->name ) ); ?></p>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr><td colspan="2"><?php esc_html_e( 'Tento CPT nemá priradené žiadne taxonómie.', 'lc-stf' ); ?></td></tr>
                <?php endif; ?>
                </tbody></table>

                <hr>

                <h2><?php esc_html_e( 'Motivačné citáty pre ženy (slovensky)', 'lc-stf' ); ?></h2>
                <p><?php esc_html_e( 'Zadaj jeden citát na každý riadok. Plugin vyberie jeden citát denne a po skončení zoznamu začne odznova.', 'lc-stf' ); ?></p>

                <table class="form-table" role="presentation"><tbody>
                    <tr>
                        <th scope="row"><label for="lc_stf_quotes"><?php esc_html_e( 'Zoznam citátov', 'lc-stf' ); ?></label></th>
                        <td>
                            <textarea name="lc_stf_quotes" id="lc_stf_quotes" rows="12" cols="80" class="large-text code"><?php echo esc_textarea( $quotes_text ); ?></textarea>
                        </td>
                    </tr>
                </tbody></table>

                <hr>

                <h2><?php esc_html_e( 'Meniny a sviatky – lokálna tabuľka', 'lc-stf' ); ?></h2>
                <table class="form-table" role="presentation"><tbody>
                    <tr>
                        <th scope="row"><?php esc_html_e( 'Aktivovať meniny', 'lc-stf' ); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="lc_stf_nameday_enabled" value="1" <?php checked( 1, $nameday_enabled ); ?>>
                                <?php esc_html_e( 'Zobraziť meniny a sviatky cez shortcode [lc_nameday_local]', 'lc-stf' ); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="lc_stf_nameday_table"><?php esc_html_e( 'Tabuľka dátumov', 'lc-stf' ); ?></label></th>
                        <td>
                            <textarea name="lc_stf_nameday_table" id="lc_stf_nameday_table" rows="14" cols="80" class="large-text code"><?php echo esc_textarea( $nameday_text ); ?></textarea>
                            <p class="description"><?php esc_html_e( 'Formát: MM-DD | mená (oddelené čiarkou) | sviatok (voliteľné).', 'lc-stf' ); ?></p>
                        </td>
                    </tr>
                </tbody></table>

                <hr>

                <h2><?php esc_html_e( 'Synchronizácia Meta → Taxonómie', 'lc-stf' ); ?></h2>
                <p><?php esc_html_e( 'Tento plugin automaticky synchronizuje polia JetEngine s taxonómiami pri ukladaní technickej karty.', 'lc-stf' ); ?></p>

                <table class="form-table" role="presentation"><tbody>
                    <tr>
                        <th scope="row"><?php esc_html_e( 'Aktívne mapovanie', 'lc-stf' ); ?></th>
                        <td>
                            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; max-width: 800px;">
                                <?php foreach ( $this->meta_to_taxonomy_map as $meta => $tax ) : ?>
                                    <div style="background: #f0f0f1; padding: 5px 10px; border-radius: 3px;">
                                        <code style="font-size: 11px;"><?php echo esc_html( $meta ); ?></code> → <code style="font-size: 11px;"><?php echo esc_html( $tax ); ?></code>
                                        <?php if ( taxonomy_exists( $tax ) ) : ?>
                                            <span style="color: green;">✓</span>
                                        <?php else : ?>
                                            <span style="color: red;">✗</span>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <p class="description"><?php esc_html_e( 'Keď vyberiete hodnotu z poľa JetEngine, automaticky sa priradí aj k príslušnej taxonómii.', 'lc-stf' ); ?></p>
                        </td>
                    </tr>
                </tbody></table>

                <p class="submit">
                    <button type="submit" name="lc_stf_save_settings" class="button button-primary"><?php esc_html_e( 'Uložiť nastavenia', 'lc-stf' ); ?></button>
                </p>
            </form>

            <hr>

            <h2><?php esc_html_e( 'Synchronizovať všetky existujúce karty', 'lc-stf' ); ?></h2>
            <p><?php esc_html_e( 'Použi toto tlačidlo na synchronizáciu všetkých existujúcich technických kariet. Užitočné, ak už máš karty vytvorené pred aktiváciou tejto funkcie.', 'lc-stf' ); ?></p>

            <form method="post">
                <?php wp_nonce_field( 'lc_stf_sync_all_action', 'lc_stf_sync_nonce' ); ?>
                <p class="submit">
                    <button type="submit" name="lc_stf_sync_all" class="button button-secondary" onclick="return confirm('<?php esc_attr_e( 'Naozaj chceš synchronizovať všetky karty?', 'lc-stf' ); ?>');">
                        <?php esc_html_e( 'Synchronizovať všetky karty', 'lc-stf' ); ?>
                    </button>
                </p>
            </form>

            <hr>

            <h2><?php esc_html_e( 'Diagnostika', 'lc-stf' ); ?></h2>
            <?php $this->render_diagnostic_section(); ?>
        </div>
        <?php
    }

    /**
     * Sincronizza tutte le schede tecniche esistenti
     */
    protected function sync_all_posts() {
        $this->detect_post_type();

        $posts = get_posts( array(
            'post_type'      => $this->post_type,
            'posts_per_page' => -1,
            'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
            'fields'         => 'ids',
        ) );

        $count = 0;
        foreach ( $posts as $post_id ) {
            $this->do_meta_taxonomy_sync( $post_id );
            $count++;
        }

        return $count;
    }

    /**
     * Render sezione diagnostica
     */
    protected function render_diagnostic_section() {
        $this->detect_post_type();

        $posts = get_posts( array(
            'post_type'      => $this->post_type,
            'posts_per_page' => 5,
            'post_status'    => 'publish',
        ) );

        if ( empty( $posts ) ) {
            echo '<p>' . esc_html__( 'Nenašla sa žiadna technická karta.', 'lc-stf' ) . '</p>';
            return;
        }

        echo '<table class="widefat striped" style="max-width: 800px;">';
        echo '<thead><tr>';
        echo '<th>' . esc_html__( 'Názov', 'lc-stf' ) . '</th>';
        echo '<th>' . esc_html__( 'Meta „klient"', 'lc-stf' ) . '</th>';
        echo '<th>' . esc_html__( 'Taxonómia „klienti"', 'lc-stf' ) . '</th>';
        echo '<th>' . esc_html__( 'Stav', 'lc-stf' ) . '</th>';
        echo '</tr></thead><tbody>';

        foreach ( $posts as $post ) {
            $meta_value = get_post_meta( $post->ID, 'cliente', true );
            $tax_terms = get_the_terms( $post->ID, 'clienti' );

            $meta_display = $this->format_meta_for_display( $meta_value );

            $tax_display = '';
            if ( ! empty( $tax_terms ) && ! is_wp_error( $tax_terms ) ) {
                $names = array();
                foreach ( $tax_terms as $t ) {
                    $names[] = $t->name;
                }
                $tax_display = implode( ', ', $names );
            } else {
                $tax_display = '<em style="color:#999;">' . esc_html__( '(prázdne)', 'lc-stf' ) . '</em>';
            }

            $status = '❌';
            $status_text = __( 'Nesynchronizované', 'lc-stf' );
            if ( ! empty( $tax_terms ) && ! is_wp_error( $tax_terms ) ) {
                $status = '✅';
                $status_text = __( 'OK', 'lc-stf' );
            } elseif ( empty( $meta_value ) ) {
                $status = '⚪';
                $status_text = __( 'Žiadny klient', 'lc-stf' );
            }

            echo '<tr>';
            echo '<td><a href="' . esc_url( get_edit_post_link( $post->ID ) ) . '">' . esc_html( $post->post_title ) . '</a></td>';
            echo '<td>' . $meta_display . '</td>';
            echo '<td>' . $tax_display . '</td>';
            echo '<td title="' . esc_attr( $status_text ) . '">' . $status . ' ' . esc_html( $status_text ) . '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '<p class="description">' . esc_html__( 'Zobrazuje posledných 5 kariet. ✅ = synchronizované, ❌ = meta prítomné ale taxonómia prázdna, ⚪ = žiadny klient priradený.', 'lc-stf' ) . '</p>';
    }

    /**
     * Formatta il valore meta per la visualizzazione
     */
    protected function format_meta_for_display( $value ) {
        if ( empty( $value ) ) {
            return '<em style="color:#999;">' . esc_html__( '(prázdne)', 'lc-stf' ) . '</em>';
        }

        if ( is_array( $value ) ) {
            $items = array();
            foreach ( $value as $v ) {
                $items[] = $this->format_single_meta_value( $v );
            }
            return implode( ', ', $items );
        }

        return $this->format_single_meta_value( $value );
    }

    /**
     * Formatta un singolo valore meta
     */
    protected function format_single_meta_value( $value ) {
        if ( is_numeric( $value ) ) {
            $post = get_post( (int) $value );
            if ( $post ) {
                return esc_html( $post->post_title ) . ' <small>(ID:' . $value . ')</small>';
            }
            $term = get_term( (int) $value );
            if ( $term && ! is_wp_error( $term ) ) {
                return esc_html( $term->name ) . ' <small>(term:' . $value . ')</small>';
            }
            return '<code>' . esc_html( $value ) . '</code>';
        }

        return esc_html( (string) $value );
    }

    protected function get_all_taxonomies() {
        $this->detect_post_type();
        if ( ! post_type_exists( $this->post_type ) ) { return array(); }
        $taxonomies = get_object_taxonomies( $this->post_type, 'objects' );
        uasort($taxonomies, function($a,$b){ return strcasecmp($a->label,$b->label); });
        return $taxonomies;
    }

    protected function get_enabled_taxonomies_slugs( $fallback_all = true ) {
        $enabled = get_option( $this->filters_option );
        if ( ! is_array( $enabled ) || empty( $enabled ) ) {
            if ( ! $fallback_all ) { return array(); }
            $taxonomies = $this->get_all_taxonomies();
            return array_keys( $taxonomies );
        }
        return $enabled;
    }

    /**
     * Get active taxonomies ordered (clienti, tipologia first)
     */
    protected function get_active_taxonomies() {
        $enabled_tax_slugs = $this->get_enabled_taxonomies_slugs( true );
        $all_taxonomies    = $this->get_all_taxonomies();

        $active_taxonomies = array();
        foreach ( $enabled_tax_slugs as $slug ) {
            if ( isset( $all_taxonomies[ $slug ] ) ) {
                $active_taxonomies[ $slug ] = $all_taxonomies[ $slug ];
            }
        }

        $ordered = array();
        if ( isset( $active_taxonomies['clienti'] ) ) {
            $ordered['clienti'] = $active_taxonomies['clienti'];
            unset($active_taxonomies['clienti']);
        }
        if ( isset( $active_taxonomies['tipologia'] ) ) {
            $ordered['tipologia'] = $active_taxonomies['tipologia'];
            unset($active_taxonomies['tipologia']);
        }

        return $ordered + $active_taxonomies;
    }

    public function render_shortcode( $atts = array(), $content = null ) {
        $this->detect_post_type();
        if ( ! post_type_exists( $this->post_type ) ) {
            return '<p>' . esc_html__( 'CPT „scheda tecnica" nebol nájdený.', 'lc-stf' ) . '</p>';
        }

        $active_taxonomies = $this->get_active_taxonomies();

        ob_start();
        echo '<div class="lc-stf-wrapper" data-post-type="' . esc_attr( $this->post_type ) . '">';

        $this->output_filters_form( $active_taxonomies );

        echo '<div class="lc-stf-grid-container">';
        echo '<div class="lc-stf-loading" style="display:none;"><span>Načítavam...</span></div>';
        echo '<div class="lc-stf-grid">';

        $this->output_grid_cards( array() );

        echo '</div>';
        echo '</div>';
        echo '</div>';

        return ob_get_clean();
    }

    public function render_grid_only( $filters = array() ) {
        $this->detect_post_type();

        ob_start();
        $this->output_grid_cards( $filters );
        return ob_get_clean();
    }

    protected function output_grid_cards( $filters = array() ) {
        $active_taxonomies = $this->get_active_taxonomies();

        $args = array(
            'post_type'      => $this->post_type,
            'posts_per_page' => -1,
            'post_status'    => 'publish',
        );

        $tax_query = array();
        foreach ( $active_taxonomies as $slug => $tax ) {
            $param_key = 'tax_' . $slug;
            $value = isset( $filters[ $param_key ] ) ? sanitize_text_field( $filters[ $param_key ] ) : '';

            if ( ! empty( $value ) ) {
                $tax_query[] = array(
                    'taxonomy' => $slug,
                    'field'    => 'slug',
                    'terms'    => $value,
                );
            }
        }

        if ( ! empty( $tax_query ) ) {
            if ( count( $tax_query ) > 1 ) {
                $tax_query['relation'] = 'AND';
            }
            $args['tax_query'] = $tax_query;
        }

        $query = new WP_Query( $args );

        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
                $this->output_card( get_the_ID(), $active_taxonomies );
            }
            wp_reset_postdata();
        } else {
            echo '<p class="lc-stf-no-results">' . esc_html__( 'Nenašli sa žiadne produkty.', 'lc-stf' ) . '</p>';
        }
    }

    protected function output_filters_form( $taxonomies ) {
        echo '<div class="lc-stf-filters">';

        foreach ( $taxonomies as $slug => $tax ) {
            $param_key = 'tax_' . $slug;
            $terms     = get_terms( array( 'taxonomy' => $slug, 'hide_empty' => false ) );
            if ( is_wp_error( $terms ) || empty( $terms ) ) { continue; }

            echo '<div class="lc-stf-filter lc-stf-filter-' . esc_attr( $slug ) . '">';
            echo '<label for="' . esc_attr( $param_key ) . '">' . esc_html( $tax->label ) . '</label>';
            echo '<div class="lc-stf-filter-select-wrap">';
            echo '<select name="' . esc_attr( $param_key ) . '" id="' . esc_attr( $param_key ) . '" class="lc-stf-filter-select">';
            echo '<option value="">ALL</option>';

            foreach ( $terms as $term ) {
                echo '<option value="' . esc_attr( $term->slug ) . '">' . esc_html( $term->name ) . '</option>';
            }

            echo '</select></div></div>';
        }

        echo '<div class="lc-stf-filter-submit">';
        echo '<button type="button" class="lc-stf-btn lc-stf-btn-apply" id="lc-stf-apply-filters">' . esc_html__( 'Filtrovať', 'lc-stf' ) . '</button>';
        echo '<button type="button" class="lc-stf-btn lc-stf-btn-reset" id="lc-stf-reset-filters">' . esc_html__( 'Reset', 'lc-stf' ) . '</button>';
        echo '</div>';

        echo '</div>';
    }

    protected function get_card_image_url( $post_id ) {
        $thumb = get_the_post_thumbnail_url( $post_id, 'large' );
        if ( $thumb ) { return $thumb; }

        $attachments = get_children(
            array(
                'post_parent'    => $post_id,
                'post_type'      => 'attachment',
                'post_mime_type' => 'image',
                'numberposts'    => 1,
                'orderby'        => 'menu_order ID',
                'order'          => 'ASC',
            )
        );
        if ( ! empty( $attachments ) ) {
            $attachment = array_shift( $attachments );
            $url = wp_get_attachment_image_url( $attachment->ID, 'large' );
            if ( $url ) { return $url; }
        }
        return '';
    }

    protected function output_card( $post_id, $taxonomies ) {
        $title = get_the_title( $post_id );
        $link  = get_permalink( $post_id );
        $thumb = $this->get_card_image_url( $post_id );

        echo '<article class="lc-stf-card">';
        if ( $thumb ) {
            echo '<a href="' . esc_url( $link ) . '" class="lc-stf-thumb-wrap"><img src="' . esc_url( $thumb ) . '" alt="' . esc_attr( $title ) . '"></a>';
        }
        echo '<div class="lc-stf-card-body">';
        echo '<h3 class="lc-stf-title"><a href="' . esc_url( $link ) . '">' . esc_html( $title ) . '</a></h3>';
        echo '<div class="lc-stf-tax-badges">';

        if ( isset( $taxonomies['clienti'] ) ) {
            $tax = $taxonomies['clienti'];
            $terms = get_the_terms( $post_id, 'clienti' );
            if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
                echo '<div class="lc-stf-tax-group lc-stf-tax-clienti"><span class="tax-label">' . esc_html( $tax->label ) . ':</span>';
                foreach ( $terms as $term ) { echo '<span class="tax-term">' . esc_html( $term->name ) . '</span>'; }
                echo '</div>';
            }
        }

        if ( isset( $taxonomies['tipologia'] ) ) {
            $tax = $taxonomies['tipologia'];
            $terms = get_the_terms( $post_id, 'tipologia' );
            if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
                echo '<div class="lc-stf-tax-group lc-stf-tax-tipologia"><span class="tax-label">' . esc_html( $tax->label ) . ':</span>';
                foreach ( $terms as $term ) { echo '<span class="tax-term">' . esc_html( $term->name ) . '</span>'; }
                echo '</div>';
            }
        }

        foreach ( $taxonomies as $slug => $tax ) {
            if ( in_array( $slug, array('clienti','tipologia'), true ) ) { continue; }
            $terms = get_the_terms( $post_id, $slug );
            if ( empty( $terms ) || is_wp_error( $terms ) ) { continue; }
            echo '<div class="lc-stf-tax-group"><span class="tax-label">' . esc_html( $tax->label ) . ':</span>';
            foreach ( $terms as $term ) { echo '<span class="tax-term">' . esc_html( $term->name ) . '</span>'; }
            echo '</div>';
        }

        echo '</div></div></article>';
    }

    protected function get_daily_quote() {
        $lines = get_option( $this->quotes_option, array() );
        if ( ! is_array( $lines ) ) { $lines = array(); }
        $lines = array_filter( array_map( 'trim', $lines ) );

        if ( empty( $lines ) ) {
            $raw = "Dobré ráno: dnes si vyber byť ženou, o ktorej snívaš.\n"
                 . "Dobré ráno: svet dnes potrebuje tvoje svetlo.\n"
                 . "Dobré ráno: si silnejšia, než si myslíš.\n"
                 . "Dobré ráno: tvoja elegancia je tvoja sila.\n"
                 . "Dobré ráno: každým dňom rastieš o krok ďalej.";
            $lines = array_filter( array_map( 'trim', explode( "\n", $raw ) ) );
        }
        if ( empty( $lines ) ) { return ''; }

        $day_of_year = (int) current_time( 'z' );
        $index = $day_of_year % count( $lines );
        return $lines[ $index ];
    }

    public function render_daily_quote_shortcode() {
        $quote = $this->get_daily_quote();
        if ( ! $quote ) { return ''; }
        return '<p class="lc-daily-quote">' . esc_html( $quote ) . '</p>';
    }

    protected function get_local_nameday_row() {
        $enabled = (int) get_option( $this->nameday_enabled_option, 0 );
        if ( ! $enabled ) { return array( 'names' => '', 'holiday' => '' ); }
        $table = get_option( $this->nameday_table_option, array() );
        if ( ! is_array( $table ) || empty( $table ) ) { return array( 'names' => '', 'holiday' => '' ); }

        $timestamp = current_time( 'timestamp' );
        $key       = date_i18n( 'm-d', $timestamp );

        if ( isset( $table[ $key ] ) && is_array( $table[ $key ] ) ) {
            $row = $table[ $key ];
            return array(
                'names'   => isset( $row['names'] ) ? $row['names'] : '',
                'holiday' => isset( $row['holiday'] ) ? $row['holiday'] : '',
            );
        }
        return array( 'names' => '', 'holiday' => '' );
    }

    public function render_nameday_local_shortcode() {
        $row = $this->get_local_nameday_row();
        $names = trim( $row['names'] );
        $holiday = trim( $row['holiday'] );

        if ( '' === $names && '' === $holiday ) { return ''; }

        $parts = array();
        if ( '' !== $names ) {
            $parts[] = sprintf( esc_html__( 'Dnes má meniny: %s', 'lc-stf' ), esc_html( $names ) );
        }
        if ( '' !== $holiday ) {
            $parts[] = sprintf( esc_html__( 'Dnes je sviatok: %s', 'lc-stf' ), esc_html( $holiday ) );
        }
        return '<p class="lc-nameday-sk">' . implode( ' ', $parts ) . '</p>';
    }

    /* =========================================================
     * SHORTCODES per SINGLE TEMPLATE (Cliente/Tipologia)
     * ========================================================= */

    protected function get_current_post_id_from_atts( $atts ) {
        if ( isset( $atts['post_id'] ) && $atts['post_id'] !== '' ) {
            return absint( $atts['post_id'] );
        }
        $id = get_the_ID();
        return $id ? (int) $id : 0;
    }

    protected function render_tax_terms_line( $taxonomy, $label = '', $atts = array() ) {
        $post_id = $this->get_current_post_id_from_atts( $atts );
        if ( ! $post_id || ! taxonomy_exists( $taxonomy ) ) { return ''; }

        $terms = get_the_terms( $post_id, $taxonomy );
        if ( empty( $terms ) || is_wp_error( $terms ) ) { return ''; }

        $names = array();
        foreach ( $terms as $t ) { $names[] = $t->name; }

        $sep = isset( $atts['sep'] ) && $atts['sep'] !== '' ? sanitize_text_field( $atts['sep'] ) : ', ';
        $value = esc_html( implode( $sep, $names ) );

        $wrap = isset( $atts['wrap'] ) ? sanitize_text_field( $atts['wrap'] ) : 'p';
        $class = isset( $atts['class'] ) ? sanitize_text_field( $atts['class'] ) : 'lc-tax-line';

        $before = '';
        if ( $label !== '' ) {
            $before = '<strong class="lc-tax-label">' . esc_html( $label ) . ':</strong> ';
        }

        return sprintf(
            '<%1$s class="%2$s">%3$s%4$s</%1$s>',
            esc_attr( $wrap ),
            esc_attr( $class ),
            $before,
            $value
        );
    }

    public function sc_cliente_shortcode( $atts = array() ) {
        $atts = shortcode_atts(
            array(
                'label' => 'Klient',
                'sep'   => ', ',
                'wrap'  => 'p',
                'class' => 'lc-tax-line lc-tax-cliente',
                'post_id' => '',
            ),
            $atts
        );
        return $this->render_tax_terms_line( 'clienti', $atts['label'], $atts );
    }

    public function sc_tipologia_shortcode( $atts = array() ) {
        $atts = shortcode_atts(
            array(
                'label' => 'Typológia',
                'sep'   => ', ',
                'wrap'  => 'p',
                'class' => 'lc-tax-line lc-tax-tipologia',
                'post_id' => '',
            ),
            $atts
        );
        return $this->render_tax_terms_line( 'tipologia', $atts['label'], $atts );
    }

    public function sc_tax_terms_shortcode( $atts = array() ) {
        $atts = shortcode_atts(
            array(
                'taxonomy' => '',
                'label'    => '',
                'sep'      => ', ',
                'wrap'     => 'p',
                'class'    => 'lc-tax-line',
                'post_id'  => '',
            ),
            $atts
        );

        $taxonomy = sanitize_text_field( $atts['taxonomy'] );
        if ( $taxonomy === '' ) { return ''; }

        return $this->render_tax_terms_line( $taxonomy, $atts['label'], $atts );
    }

    public function sc_scheda_meta_shortcode( $atts = array() ) {
        $atts = shortcode_atts(
            array(
                'post_id' => '',
                'sep'     => ' · ',
                'class'   => 'lc-scheda-meta',
            ),
            $atts
        );

        $post_id = $this->get_current_post_id_from_atts( $atts );
        if ( ! $post_id ) { return ''; }

        $parts = array();

        if ( taxonomy_exists( 'clienti' ) ) {
            $terms = get_the_terms( $post_id, 'clienti' );
            if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
                $names = array();
                foreach ( $terms as $t ) { $names[] = $t->name; }
                if ( ! empty( $names ) ) {
                    $parts[] = esc_html( implode( ', ', $names ) );
                }
            }
        }

        if ( taxonomy_exists( 'tipologia' ) ) {
            $terms = get_the_terms( $post_id, 'tipologia' );
            if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
                $names = array();
                foreach ( $terms as $t ) { $names[] = $t->name; }
                if ( ! empty( $names ) ) {
                    $parts[] = esc_html( implode( ', ', $names ) );
                }
            }
        }

        if ( empty( $parts ) ) { return ''; }

        $out  = '<div class="' . esc_attr( $atts['class'] ) . '">';
        foreach ( $parts as $p ) {
            $out .= '<span class="lc-scheda-meta-pill">' . $p . '</span>';
        }
        $out .= '</div>';

        return $out;
    }

}
