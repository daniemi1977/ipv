<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class LC_Schede_Tecniche_Filters {

    protected $post_type = 'scheda-tecnica';

    /**
     * Mapping COMPLETO: JetEngine meta field => taxonomy slug
     */
    protected $meta_to_taxonomy_map = array(
        // Campi principali
        'cliente'           => 'clienti',
        'tipologia'         => 'tipologia',

        // Jadro (nucleo)
        'jadro'             => 'jadro',

        // Stoffe (tessuti) - tutti verso la stessa tassonomia
        'stoffa_sopra'      => 'stoffa',
        'stoffa_sotto'      => 'stoffa',
        'stoffa_lato'       => 'stoffa',

        // Trapuntature - tutti verso la stessa tassonomia
        'trapuntatura_sopra'=> 'trapuntatura',
        'trapuntatura_sotto'=> 'trapuntatura',
        'trapuntatura_lato' => 'trapuntatura',

        // Disegni - tutti verso la stessa tassonomia
        'disegno_sopra'     => 'disegno',
        'disegno_sotto'     => 'disegno',
        'disegno_lato'      => 'disegno',

        // Altri componenti
        'lemovka'           => 'lemovka',
        'vypuska'           => 'vypuska',
        'zip'               => 'zip',
        'bezec'             => 'bezec',
        '3d'                => '3d',
        'elastico'          => 'elastico',
        'etikety'           => 'etikety',
        'plagaty'           => 'plagaty',
        'imballaggio'       => 'imballaggio',
        'poznamky_opt'      => 'poznamky-opt',
    );

    public function __construct() {
        // Sincronizzazione automatica meta field → tassonomia
        add_action( 'save_post', array( $this, 'sync_meta_to_taxonomy' ), 20, 2 );
        add_action( 'jet-engine/meta-boxes/save-post', array( $this, 'sync_meta_to_taxonomy_jet' ), 20, 2 );
    }

    /**
     * Sincronizza i meta field di JetEngine con le tassonomie corrispondenti
     */
    public function sync_meta_to_taxonomy( $post_id, $post = null ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        if ( wp_is_post_revision( $post_id ) ) {
            return;
        }

        $post_type = get_post_type( $post_id );
        if ( ! in_array( $post_type, array( 'scheda-tecnica', 'scheda_tecnica' ), true ) ) {
            return;
        }

        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        $this->do_meta_taxonomy_sync( $post_id );
    }

    /**
     * Hook specifico per JetEngine meta boxes
     */
    public function sync_meta_to_taxonomy_jet( $post_id, $meta_fields = array() ) {
        $post_type = get_post_type( $post_id );
        if ( ! in_array( $post_type, array( 'scheda-tecnica', 'scheda_tecnica' ), true ) ) {
            return;
        }

        $this->do_meta_taxonomy_sync( $post_id );
    }

    /**
     * Esegue la sincronizzazione effettiva
     */
    protected function do_meta_taxonomy_sync( $post_id ) {
        $taxonomy_terms = array();

        foreach ( $this->meta_to_taxonomy_map as $meta_key => $taxonomy_slug ) {
            if ( ! taxonomy_exists( $taxonomy_slug ) ) {
                continue;
            }

            $meta_value = get_post_meta( $post_id, $meta_key, true );

            if ( empty( $meta_value ) ) {
                continue;
            }

            if ( ! isset( $taxonomy_terms[ $taxonomy_slug ] ) ) {
                $taxonomy_terms[ $taxonomy_slug ] = array();
            }

            $values = is_array( $meta_value ) ? $meta_value : array( $meta_value );

            foreach ( $values as $value ) {
                $term = $this->resolve_term_from_value( $value, $taxonomy_slug );
                if ( $term ) {
                    $taxonomy_terms[ $taxonomy_slug ][] = $term->term_id;
                }
            }
        }

        // Assegna i termini alle tassonomie
        foreach ( $taxonomy_terms as $taxonomy_slug => $term_ids ) {
            $term_ids = array_unique( $term_ids );
            if ( ! empty( $term_ids ) ) {
                wp_set_object_terms( $post_id, $term_ids, $taxonomy_slug );
            }
        }

        // Pulisci tassonomie vuote
        $all_taxonomies = array_unique( array_values( $this->meta_to_taxonomy_map ) );
        foreach ( $all_taxonomies as $taxonomy_slug ) {
            if ( ! isset( $taxonomy_terms[ $taxonomy_slug ] ) || empty( $taxonomy_terms[ $taxonomy_slug ] ) ) {
                $has_values = false;
                foreach ( $this->meta_to_taxonomy_map as $mk => $ts ) {
                    if ( $ts === $taxonomy_slug ) {
                        $mv = get_post_meta( $post_id, $mk, true );
                        if ( ! empty( $mv ) ) {
                            $has_values = true;
                            break;
                        }
                    }
                }

                if ( ! $has_values && taxonomy_exists( $taxonomy_slug ) ) {
                    wp_set_object_terms( $post_id, array(), $taxonomy_slug );
                }
            }
        }
    }

    /**
     * Risolve un valore in un WP_Term
     */
    protected function resolve_term_from_value( $value, $taxonomy_slug ) {
        if ( empty( $value ) ) {
            return null;
        }

        if ( is_numeric( $value ) ) {
            $term = get_term( (int) $value, $taxonomy_slug );
            if ( $term && ! is_wp_error( $term ) ) {
                return $term;
            }

            // Post ID (relazione JetEngine)
            $related_post = get_post( (int) $value );
            if ( $related_post ) {
                $term_name = $related_post->post_title;
                $term = get_term_by( 'name', $term_name, $taxonomy_slug );
                if ( $term && ! is_wp_error( $term ) ) {
                    return $term;
                }
                $term = get_term_by( 'slug', sanitize_title( $term_name ), $taxonomy_slug );
                if ( $term && ! is_wp_error( $term ) ) {
                    return $term;
                }
            }
        }

        $value = (string) $value;

        $term = get_term_by( 'name', $value, $taxonomy_slug );
        if ( $term && ! is_wp_error( $term ) ) {
            return $term;
        }

        $term = get_term_by( 'slug', $value, $taxonomy_slug );
        if ( $term && ! is_wp_error( $term ) ) {
            return $term;
        }

        return null;
    }

    /**
     * Shortcode placeholder per griglia (opzionale)
     */
    public function render_shortcode( $atts = array() ) {
        return '<!-- LC Schede Tecniche Grid -->';
    }
}
