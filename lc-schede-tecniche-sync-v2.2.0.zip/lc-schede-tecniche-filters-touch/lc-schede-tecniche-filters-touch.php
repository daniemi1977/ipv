<?php
/**
 * Plugin Name: LC Technické karty – Sync & Filtre (v2.2)
 * Description: Automatická synchronizácia JetEngine meta → taxonómie pre JetSmartFilters. Podporuje 20+ polí vrátane stoffa, trapuntatura, disegno (sopra/sotto/lato).
 * Version:     2.2.0
 * Author:      LC
 *
 * CHANGELOG v2.2.0:
 * - SYNC META→TAXONOMY: Automatická synchronizácia pri uložení
 * - KOMPLETNÉ MAPOVANIE: 20+ meta polí
 * - KOMPATIBILNÉ S JETENGINE: Natívne widgety v Elementor šablónach
 *
 * NAHRÁDZA TIETO PLUGINY:
 * - lc-jetengine-taxonomy-sync
 * - jetengine-order-fix
 * - jetengine-imballaggio-fix
 * - je-order-fix
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'LC_STF_VERSION', '2.2.0' );
define( 'LC_STF_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'LC_STF_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once LC_STF_PLUGIN_DIR . 'includes/class-lc-schede-tecniche-filters.php';

function lc_stf_instance() {
    static $instance = null;
    if ( null === $instance ) {
        $instance = new LC_Schede_Tecniche_Filters();
    }
    return $instance;
}
add_action( 'plugins_loaded', 'lc_stf_instance' );

// Registra shortcodes
add_action( 'init', function() {
    $instance = lc_stf_instance();
    add_shortcode( 'lc_schede_tecniche_grid', array( $instance, 'render_shortcode' ) );
} );
