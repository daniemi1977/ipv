<?php
/**
 * Plugin Name: LC JetEngine Taxonomy Sync
 * Description: Sincronizza automaticamente i campi select di JetEngine con le tassonomie corrispondenti per il CPT "scheda tecnica". Risolve il problema dei filtri JetSmartFilters che non funzionano quando i dati sono solo nei meta field.
 * Version:     1.0.0
 * Author:      LC Manager
 * 
 * PROBLEMA RISOLTO:
 * JetEngine salva i valori dei campi select come post_meta (usando term_id),
 * ma NON li sincronizza con le tassonomie. I filtri JetSmartFilters cercano
 * nelle tassonomie, quindi senza sincronizzazione i filtri non funzionano.
 * 
 * SOLUZIONE:
 * Questo plugin intercetta il salvataggio delle schede tecniche e sincronizza
 * automaticamente tutti i meta field con le rispettive tassonomie.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class LC_JetEngine_Taxonomy_Sync {

    /**
     * Mapping completo: meta_field_name => taxonomy_slug
     * Estratto dalla configurazione JetEngine
     */
    protected $meta_to_taxonomy_map = array(
        // Campi principali
        'cliente'           => 'clienti',
        'tipologia'         => 'tipologia',
        
        // Jadro (nucleo)
        'jadro'             => 'jadro',
        
        // Stoffe (tessuti)
        'stoffa_sopra'      => 'stoffa',
        'stoffa_sotto'      => 'stoffa',
        'stoffa_lato'       => 'stoffa',
        
        // Trapuntature
        'trapuntatura_sopra'=> 'trapuntatura',
        'trapuntatura_sotto'=> 'trapuntatura',
        'trapuntatura_lato' => 'trapuntatura',
        
        // Disegni
        'disegno_sopra'     => 'disegno',
        'disegno_sotto'     => 'disegno',
        'disegno_lato'      => 'disegno',
        
        // Altri componenti
        'lemovka'           => 'lemovka',
        'vypuska'           => 'vypuska',
        'zip'               => 'zip',
        'bezec'             => 'bezec',
        '3d'                => '3d',
        'elastico'          => 'elastico',
        'etikety'           => 'etikety',
        'plagaty'           => 'plagaty',
        'imballaggio'       => 'imballaggio',
        'poznamky_opt'      => 'poznamky-opt',
    );

    protected $post_type = 'scheda-tecnica';

    public function __construct() {
        // Hooks per sincronizzazione automatica
        add_action( 'save_post', array( $this, 'sync_on_save' ), 20, 2 );
        add_action( 'jet-engine/meta-boxes/save-post', array( $this, 'sync_on_jet_save' ), 20, 2 );
        
        // Admin menu
        add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
        
        // Detect post type variant
        add_action( 'init', array( $this, 'detect_post_type' ), 999 );
    }

    /**
     * Rileva la variante del post type (scheda-tecnica vs scheda_tecnica)
     */
    public function detect_post_type() {
        if ( post_type_exists( 'scheda_tecnica' ) ) {
            $this->post_type = 'scheda_tecnica';
        } elseif ( post_type_exists( 'scheda-tecnica' ) ) {
            $this->post_type = 'scheda-tecnica';
        }
    }

    /**
     * Hook standard WordPress save_post
     */
    public function sync_on_save( $post_id, $post = null ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        
        if ( wp_is_post_revision( $post_id ) ) {
            return;
        }

        $post_type = get_post_type( $post_id );
        if ( ! in_array( $post_type, array( 'scheda-tecnica', 'scheda_tecnica' ), true ) ) {
            return;
        }

        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        $this->sync_all_meta_to_taxonomies( $post_id );
    }

    /**
     * Hook JetEngine save
     */
    public function sync_on_jet_save( $post_id, $meta_fields = array() ) {
        $post_type = get_post_type( $post_id );
        if ( ! in_array( $post_type, array( 'scheda-tecnica', 'scheda_tecnica' ), true ) ) {
            return;
        }

        $this->sync_all_meta_to_taxonomies( $post_id );
    }

    /**
     * Sincronizza tutti i meta field con le tassonomie
     */
    public function sync_all_meta_to_taxonomies( $post_id ) {
        // Raggruppa per tassonomia per evitare sovrascritture
        $taxonomy_terms = array();

        foreach ( $this->meta_to_taxonomy_map as $meta_key => $taxonomy_slug ) {
            if ( ! taxonomy_exists( $taxonomy_slug ) ) {
                continue;
            }

            $meta_value = get_post_meta( $post_id, $meta_key, true );
            
            if ( empty( $meta_value ) ) {
                continue;
            }

            // Inizializza l'array per questa tassonomia se non esiste
            if ( ! isset( $taxonomy_terms[ $taxonomy_slug ] ) ) {
                $taxonomy_terms[ $taxonomy_slug ] = array();
            }

            // Gestisci valori multipli (array) e singoli
            $values = is_array( $meta_value ) ? $meta_value : array( $meta_value );
            
            foreach ( $values as $value ) {
                $term = $this->resolve_term( $value, $taxonomy_slug );
                if ( $term ) {
                    $taxonomy_terms[ $taxonomy_slug ][] = $term->term_id;
                }
            }
        }

        // Assegna i termini alle tassonomie
        foreach ( $taxonomy_terms as $taxonomy_slug => $term_ids ) {
            // Rimuovi duplicati
            $term_ids = array_unique( $term_ids );
            
            if ( ! empty( $term_ids ) ) {
                wp_set_object_terms( $post_id, $term_ids, $taxonomy_slug );
            }
        }

        // Pulisci tassonomie che non hanno più valori
        foreach ( $this->meta_to_taxonomy_map as $meta_key => $taxonomy_slug ) {
            if ( ! isset( $taxonomy_terms[ $taxonomy_slug ] ) || empty( $taxonomy_terms[ $taxonomy_slug ] ) ) {
                // Verifica se NESSUN campo punta a questa tassonomia con valori
                $has_values = false;
                foreach ( $this->meta_to_taxonomy_map as $mk => $ts ) {
                    if ( $ts === $taxonomy_slug ) {
                        $mv = get_post_meta( $post_id, $mk, true );
                        if ( ! empty( $mv ) ) {
                            $has_values = true;
                            break;
                        }
                    }
                }
                
                if ( ! $has_values && taxonomy_exists( $taxonomy_slug ) ) {
                    wp_set_object_terms( $post_id, array(), $taxonomy_slug );
                }
            }
        }
    }

    /**
     * Risolve un valore in un termine WP
     */
    protected function resolve_term( $value, $taxonomy_slug ) {
        if ( empty( $value ) ) {
            return null;
        }

        // Se è un ID numerico, cerca direttamente
        if ( is_numeric( $value ) ) {
            $term = get_term( (int) $value, $taxonomy_slug );
            if ( $term && ! is_wp_error( $term ) ) {
                return $term;
            }
        }

        // Cerca per nome
        $term = get_term_by( 'name', (string) $value, $taxonomy_slug );
        if ( $term && ! is_wp_error( $term ) ) {
            return $term;
        }

        // Cerca per slug
        $term = get_term_by( 'slug', sanitize_title( (string) $value ), $taxonomy_slug );
        if ( $term && ! is_wp_error( $term ) ) {
            return $term;
        }

        return null;
    }

    /**
     * Aggiunge la pagina admin
     */
    public function add_admin_menu() {
        $this->detect_post_type();
        
        if ( ! post_type_exists( $this->post_type ) ) {
            return;
        }

        add_submenu_page(
            'edit.php?post_type=' . $this->post_type,
            __( 'Sync Meta → Tassonomie', 'lc-jets' ),
            __( 'Sync Meta → Tax', 'lc-jets' ),
            'manage_options',
            'lc-jetengine-sync',
            array( $this, 'render_admin_page' )
        );
    }

    /**
     * Render pagina admin
     */
    public function render_admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $this->detect_post_type();

        // Gestione sincronizzazione manuale
        if ( isset( $_POST['lc_sync_all'] ) && check_admin_referer( 'lc_sync_all_action', 'lc_sync_nonce' ) ) {
            $synced = $this->sync_all_posts();
            echo '<div class="updated"><p><strong>' . sprintf( 
                __( '✅ Sincronizzazione completata! %d schede tecniche sincronizzate.', 'lc-jets' ), 
                $synced 
            ) . '</strong></p></div>';
        }

        ?>
        <div class="wrap">
            <h1>🔄 LC JetEngine Taxonomy Sync</h1>
            
            <div class="card" style="max-width: 800px; padding: 20px; margin-bottom: 20px;">
                <h2>ℹ️ Cosa fa questo plugin</h2>
                <p>Risolve il problema dei filtri JetSmartFilters che non funzionano quando i campi JetEngine salvano i valori solo nei meta field invece che nelle tassonomie.</p>
                <p><strong>Sincronizzazione automatica:</strong> Ogni volta che salvi una scheda tecnica, tutti i campi select vengono sincronizzati con le rispettive tassonomie.</p>
            </div>

            <div class="card" style="max-width: 800px; padding: 20px; margin-bottom: 20px;">
                <h2>📋 Mapping Meta → Tassonomie</h2>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th>Meta Field</th>
                            <th>Tassonomia</th>
                            <th>Stato</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $this->meta_to_taxonomy_map as $meta => $tax ) : ?>
                            <?php $exists = taxonomy_exists( $tax ); ?>
                            <tr>
                                <td><code><?php echo esc_html( $meta ); ?></code></td>
                                <td><code><?php echo esc_html( $tax ); ?></code></td>
                                <td><?php echo $exists ? '✅ OK' : '❌ Tassonomia non trovata'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="card" style="max-width: 800px; padding: 20px; margin-bottom: 20px;">
                <h2>🔧 Sincronizza tutte le schede esistenti</h2>
                <p>Usa questo pulsante per sincronizzare tutte le schede tecniche esistenti. Utile dopo l'installazione iniziale del plugin.</p>
                
                <form method="post">
                    <?php wp_nonce_field( 'lc_sync_all_action', 'lc_sync_nonce' ); ?>
                    <p>
                        <button type="submit" name="lc_sync_all" class="button button-primary button-hero" 
                                onclick="return confirm('Sicuro di voler sincronizzare tutte le schede? Questa operazione potrebbe richiedere qualche secondo.');">
                            🚀 Sincronizza TUTTE le schede tecniche
                        </button>
                    </p>
                </form>
            </div>

            <div class="card" style="max-width: 800px; padding: 20px;">
                <h2>📊 Diagnosi</h2>
                <?php $this->render_diagnostics(); ?>
            </div>
        </div>
        <?php
    }

    /**
     * Sincronizza tutti i post esistenti
     */
    public function sync_all_posts() {
        $this->detect_post_type();
        
        $posts = get_posts( array(
            'post_type'      => $this->post_type,
            'posts_per_page' => -1,
            'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
            'fields'         => 'ids',
        ) );

        $count = 0;
        foreach ( $posts as $post_id ) {
            $this->sync_all_meta_to_taxonomies( $post_id );
            $count++;
        }

        return $count;
    }

    /**
     * Render sezione diagnostica
     */
    protected function render_diagnostics() {
        $this->detect_post_type();
        
        $posts = get_posts( array(
            'post_type'      => $this->post_type,
            'posts_per_page' => 10,
            'post_status'    => 'publish',
        ) );

        if ( empty( $posts ) ) {
            echo '<p>Nessuna scheda tecnica trovata.</p>';
            return;
        }

        // Statistiche generali
        $total_posts = wp_count_posts( $this->post_type )->publish;
        echo '<p><strong>Totale schede pubblicate:</strong> ' . intval( $total_posts ) . '</p>';

        // Tabella diagnostica per le ultime 10 schede
        echo '<h3>Ultime 10 schede:</h3>';
        echo '<table class="widefat striped">';
        echo '<thead><tr>';
        echo '<th>Titolo</th>';
        echo '<th>Meta cliente</th>';
        echo '<th>Tax clienti</th>';
        echo '<th>Stato</th>';
        echo '</tr></thead><tbody>';

        foreach ( $posts as $post ) {
            $meta_cliente = get_post_meta( $post->ID, 'cliente', true );
            $tax_terms = get_the_terms( $post->ID, 'clienti' );
            
            // Formatta meta
            $meta_display = $this->format_meta_value( $meta_cliente );
            
            // Formatta tax
            $tax_display = '<em style="color:#999;">(vuoto)</em>';
            if ( ! empty( $tax_terms ) && ! is_wp_error( $tax_terms ) ) {
                $names = wp_list_pluck( $tax_terms, 'name' );
                $tax_display = esc_html( implode( ', ', $names ) );
            }

            // Stato
            $status = '❌';
            $status_text = 'Non sincronizzato';
            if ( ! empty( $tax_terms ) && ! is_wp_error( $tax_terms ) ) {
                $status = '✅';
                $status_text = 'OK';
            } elseif ( empty( $meta_cliente ) ) {
                $status = '⚪';
                $status_text = 'Nessun cliente';
            }

            echo '<tr>';
            echo '<td><a href="' . esc_url( get_edit_post_link( $post->ID ) ) . '">' . esc_html( $post->post_title ) . '</a></td>';
            echo '<td>' . $meta_display . '</td>';
            echo '<td>' . $tax_display . '</td>';
            echo '<td title="' . esc_attr( $status_text ) . '">' . $status . ' ' . esc_html( $status_text ) . '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '<p class="description">✅ = sincronizzato, ❌ = meta presente ma tassonomia vuota, ⚪ = nessun valore</p>';
    }

    /**
     * Formatta un valore meta per la visualizzazione
     */
    protected function format_meta_value( $value ) {
        if ( empty( $value ) ) {
            return '<em style="color:#999;">(vuoto)</em>';
        }

        if ( is_array( $value ) ) {
            $formatted = array();
            foreach ( $value as $v ) {
                $formatted[] = $this->format_single_value( $v );
            }
            return implode( ', ', $formatted );
        }

        return $this->format_single_value( $value );
    }

    /**
     * Formatta un singolo valore
     */
    protected function format_single_value( $value ) {
        if ( is_numeric( $value ) ) {
            // Cerca il termine
            $term = get_term( (int) $value );
            if ( $term && ! is_wp_error( $term ) ) {
                return esc_html( $term->name ) . ' <small>(ID:' . $value . ')</small>';
            }
            return '<code>' . esc_html( $value ) . '</code>';
        }
        return esc_html( (string) $value );
    }
}

// Inizializza il plugin
add_action( 'plugins_loaded', function() {
    new LC_JetEngine_Taxonomy_Sync();
} );
