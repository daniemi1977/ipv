<?php
/**
 * Elementor Dynamic Tag personalizzato per il campo Imballaggio
 * Salva questo file come: includes/elementor-dynamic-tag.php
 */

if (!defined('ABSPATH')) {
    exit;
}

class JetEngine_Imballaggio_Tag extends \Elementor\Core\DynamicTags\Tag {
    
    public function get_name() {
        return 'jetengine-imballaggio';
    }
    
    public function get_title() {
        return 'Imballaggio (Nome)';
    }
    
    public function get_group() {
        return 'post';
    }
    
    public function get_categories() {
        return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
    }
    
    public function render() {
        $post_id = get_the_ID();
        $imballaggio_value = get_post_meta($post_id, 'imballaggio', true);
        
        if (is_numeric($imballaggio_value)) {
            // Prova prima con i termini
            $term = get_term($imballaggio_value);
            if (!is_wp_error($term) && $term) {
                echo $term->name;
                return;
            }
            
            // Poi con i post
            $post = get_post($imballaggio_value);
            if ($post) {
                echo $post->post_title;
                return;
            }
            
            // Tabella di lookup personalizzata
            $lookup = array(
                '505' => 'Scatola Standard',
                '488' => 'Busta Imbottita',
                '001' => 'Confezione Base',
                // Aggiungi altri valori qui
            );
            
            if (isset($lookup[$imballaggio_value])) {
                echo $lookup[$imballaggio_value];
                return;
            }
        }
        
        // Fallback: mostra il valore originale
        echo $imballaggio_value;
    }
}
?>