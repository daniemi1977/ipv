<?php
/**
 * Plugin Name: JetElements Imballaggio Fix
 * Description: Corregge la visualizzazione dei campi imballaggio mostrando i nomi invece degli ID
 * Version: 1.0.0
 * Author: Il tuo nome
 * Text Domain: jetengine-imballaggio-fix
 */

// Previeni accesso diretto
if (!defined('ABSPATH')) {
    exit;
}

class JetEngineImballaggioFix {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    public function init() {
        // Hook per modificare la visualizzazione dei campi imballaggio
        add_filter('jet-engine/listings/dynamic-field/field-value', array($this, 'fix_imballaggio_display'), 10, 3);
        
        // Hook alternativo per JetEngine
        add_filter('jet-engine/meta-fields/field-value', array($this, 'fix_imballaggio_display'), 10, 3);
        
        // Hook per Dynamic Tags
        add_filter('jet-engine/dynamic-tags/field-value', array($this, 'fix_imballaggio_display'), 10, 3);
    }
    
    /**
     * Corregge la visualizzazione del campo imballaggio
     */
    public function fix_imballaggio_display($value, $field_key, $settings = array()) {
        
        // Controlla se questo è il campo imballaggio
        if ($field_key !== 'imballaggio' && $field_key !== '_imballaggio') {
            return $value;
        }
        
        // Se il valore è numerico (ID), convertilo nel nome
        if (is_numeric($value)) {
            $term = get_term($value);
            if (!is_wp_error($term) && $term) {
                return $term->name;
            }
            
            // Se non è un termine, prova con un post
            $post = get_post($value);
            if ($post) {
                return $post->post_title;
            }
            
            // Prova con le opzioni personalizzate se hai una tabella di lookup
            $lookup_values = $this->get_imballaggio_lookup();
            if (isset($lookup_values[$value])) {
                return $lookup_values[$value];
            }
        }
        
        // Se è un array di ID
        if (is_array($value)) {
            $names = array();
            foreach ($value as $single_value) {
                if (is_numeric($single_value)) {
                    $term = get_term($single_value);
                    if (!is_wp_error($term) && $term) {
                        $names[] = $term->name;
                    } else {
                        $post = get_post($single_value);
                        if ($post) {
                            $names[] = $post->post_title;
                        }
                    }
                } else {
                    $names[] = $single_value;
                }
            }
            return implode(', ', $names);
        }
        
        return $value;
    }
    
    /**
     * Tabella di lookup per i valori di imballaggio
     * Personalizza questa funzione in base ai tuoi dati
     */
    private function get_imballaggio_lookup() {
        return array(
            '505' => 'Scatola Standard',
            '488' => 'Busta Imbottita',
            '001' => 'Confezione Base',
            // Aggiungi altri mapping ID => Nome qui
        );
    }
}

// Inizializza il plugin
new JetEngineImballaggioFix();

/**
 * Hook aggiuntivo per JetEngine Listing Grid
 */
add_filter('jet-engine/listing/grid-items/field-value', function($value, $field_name, $post_id) {
    if ($field_name === 'imballaggio' && is_numeric($value)) {
        // Prova prima con i termini
        $term = get_term($value);
        if (!is_wp_error($term) && $term) {
            return $term->name;
        }
        
        // Poi con i post
        $post = get_post($value);
        if ($post) {
            return $post->post_title;
        }
        
        // Infine con una tabella di lookup personalizzata
        $lookup = array(
            '505' => 'Scatola Standard',
            '488' => 'Busta Imbottita',
            // Aggiungi altri valori qui
        );
        
        if (isset($lookup[$value])) {
            return $lookup[$value];
        }
    }
    return $value;
}, 10, 3);

/**
 * Aggiunge supporto per Elementor Dynamic Tags
 */
add_action('elementor/dynamic_tags/register_tags', function($dynamic_tags) {
    require_once plugin_dir_path(__FILE__) . 'includes/elementor-dynamic-tag.php';
    $dynamic_tags->register_tag('JetEngine_Imballaggio_Tag');
});

/**
 * Hook per modificare direttamente l'output di JetEngine
 */
add_filter('jet-engine/elementor-views/frontend/custom-fields/field-value', function($value, $field_name, $post_id) {
    if ($field_name === 'imballaggio' && is_numeric($value)) {
        $term = get_term($value);
        if (!is_wp_error($term) && $term) {
            return $term->name;
        }
    }
    return $value;
}, 10, 3);

/**
 * Hook per i template di JetEngine
 */
add_filter('jet-engine/templates/frontend-field-value', function($value, $field_name, $context) {
    if ($field_name === 'imballaggio' && is_numeric($value)) {
        // Cerca prima nei termini della tassonomia
        $taxonomies = get_taxonomies();
        foreach ($taxonomies as $taxonomy) {
            $term = get_term_by('id', $value, $taxonomy);
            if ($term && !is_wp_error($term)) {
                return $term->name;
            }
        }
        
        // Poi nei post
        $post = get_post($value);
        if ($post) {
            return $post->post_title;
        }
    }
    return $value;
}, 10, 3);

/**
 * Funzione di debug per identificare il problema
 */
function debug_imballaggio_field() {
    if (current_user_can('manage_options') && isset($_GET['debug_imballaggio'])) {
        $post_id = get_the_ID();
        $imballaggio_value = get_post_meta($post_id, 'imballaggio', true);
        
        echo '<div style="background: #fff; padding: 10px; border: 1px solid #ccc; margin: 10px;">';
        echo '<strong>Debug Imballaggio:</strong><br>';
        echo 'Post ID: ' . $post_id . '<br>';
        echo 'Valore grezzo: ' . var_export($imballaggio_value, true) . '<br>';
        
        if (is_numeric($imballaggio_value)) {
            $term = get_term($imballaggio_value);
            echo 'Come termine: ' . ($term ? $term->name : 'Non trovato') . '<br>';
            
            $post = get_post($imballaggio_value);
            echo 'Come post: ' . ($post ? $post->post_title : 'Non trovato') . '<br>';
        }
        echo '</div>';
    }
}
add_action('wp_head', 'debug_imballaggio_field');
?>
