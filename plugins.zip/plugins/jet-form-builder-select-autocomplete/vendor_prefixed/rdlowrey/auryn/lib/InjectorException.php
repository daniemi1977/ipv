<?php

namespace JFB\SelectAutocomplete\Vendor\Auryn;

class InjectorException extends \Exception
{
}
