<?php return array('dependencies' => array(), 'version' => 'c208ab7af367a4308333');
