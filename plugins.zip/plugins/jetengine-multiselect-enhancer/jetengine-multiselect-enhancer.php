<?php
/**
 * Plugin Name: JetEngine Multiselect Enhancer
 * Description: Replaces JetEngine admin multiselects with a searchable, draggable UI that preserves JetEngine data format and saving.
 * Version: 2.0.1
 * Author: NexaLance Team
 * License: GPLv2 or later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'JEMSE_Plugin' ) ) {

	class JEMSE_Plugin {

		private static $instance = null;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		private function __construct() {
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin' ) );
			// Persist custom order chosen in the admin UI
			add_action( 'save_post', array( $this, 'save_orders' ), 999, 2 );
		}

		/**
		 * Enqueue admin assets on post editor screens only.
		 */
		public function enqueue_admin( $hook ) {

			$base_url  = plugin_dir_url( __FILE__ );
			$base_path = plugin_dir_path( __FILE__ );
			$css_ver  = @filemtime( $base_path . 'assets/css/admin.css' );
			$js_ver   = @filemtime( $base_path . 'assets/js/admin.js' );
			$css_ver  = $css_ver ? (string) $css_ver : '1.0.0';
			$js_ver   = $js_ver ? (string) $js_ver : '1.0.0';

			wp_register_style(
				'jemse-admin',
				$base_url . 'assets/css/admin.css',
				array(),
				$css_ver
			);

			wp_register_script(
				'jemse-admin',
				$base_url . 'assets/js/admin.js',
				array( 'jquery', 'jquery-ui-sortable' ),
				$js_ver,
				true
			);

			wp_enqueue_style( 'jemse-admin' );
			wp_enqueue_script( 'jemse-admin' );

			$orders = $this->get_saved_orders_map();

			wp_localize_script( 'jemse-admin', 'JEMSE_Config', array(
				'placeholder'  => __( 'Search options...', 'jet-engine' ),
				'savedOrders'  => $orders,
				'poolLimit'    => 5,
				'moreText'     => __( 'More', 'jet-engine' ),
				'lessText'     => __( 'Less', 'jet-engine' ),
				'dropdownMaxHeight' => 182,
			) );
		}

		/**
		 * Save per-field order on post save and enforce order in post meta.
		 */
		public function save_orders( $post_id, $post ) {
			// Skip autosaves and revisions
			if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
				return;
			}
			if ( wp_is_post_revision( $post_id ) ) {
				return;
			}
			// Permissions
			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				return;
			}

			if ( empty( $_POST['jemse_order'] ) || ! is_array( $_POST['jemse_order'] ) ) {
				return;
			}

			foreach ( $_POST['jemse_order'] as $field_key => $csv_order ) {
				$field_key      = is_string( $field_key ) ? sanitize_text_field( $field_key ) : '';
				if ( '' === $field_key ) {
					continue;
				}
				$csv_order      = is_string( $csv_order ) ? $csv_order : '';
				$ordered_values = array_filter( array_map( 'trim', explode( ',', $csv_order ) ), 'strlen' );

				// Store the order for later restoration in admin (private meta key)
				update_post_meta( $post_id, '_jemse_order_' . $field_key, implode( ',', $ordered_values ) );
			}
		}

		/**
		 * Build map of saved orders for current post to restore UI on load.
		 */
		private function get_saved_orders_map() {
			$post_id = 0;
			if ( isset( $_GET['post'] ) ) {
				$post_id = absint( $_GET['post'] );
			} elseif ( isset( $_POST['post_ID'] ) ) {
				$post_id = absint( $_POST['post_ID'] );
			}

			if ( ! $post_id ) {
				return array();
			}

			$all_meta = get_post_meta( $post_id );
			$map      = array();
			foreach ( $all_meta as $key => $values ) {
				if ( 0 === strpos( $key, '_jemse_order_' ) ) {
					$field_key        = substr( $key, strlen( '_jemse_order_' ) );
					$csv               = is_array( $values ) ? reset( $values ) : $values;
					$map[ $field_key ] = $csv; // private key takes precedence
					continue;
				}
				if ( 0 === strpos( $key, 'jemse_order_' ) ) {
					$field_key        = substr( $key, strlen( 'jemse_order_' ) );
					$csv               = is_array( $values ) ? reset( $values ) : $values;
					if ( ! isset( $map[ $field_key ] ) ) {
						$map[ $field_key ] = $csv;
					}
				}
			}

			return $map;
		}
	}

	JEMSE_Plugin::instance();
}


