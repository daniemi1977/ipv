## JetEngine Multiselect Enhancer — Deep Analysis

### Overview

This plugin enhances JetEngine admin multi-select controls by replacing the default Select2 UI with a custom, searchable and draggable interface. It keeps JetEngine’s data format intact by syncing selections and their order back to the original `<select multiple>` element before save.

### File Inventory

- `jetengine-multiselect-enhancer.php`: Main bootstrap; registers/enqueues assets and localizes configuration.
- `assets/js/admin.js`: Core logic for building the enhancer UI, syncing with the original select, filtering, and drag-sort.
- `assets/css/admin.css`: Styles for hidden select, enhancer container, list, items, option pool, and optional (commented) Select2 overrides.

---

### PHP Bootstrap: `jetengine-multiselect-enhancer.php`

Key points:

- Defines singleton `JEMSE_Plugin` and hooks `admin_enqueue_scripts`.
- Registers and enqueues `jemse-admin` style and script.
- Script dependencies: `jquery`, `jquery-ui-sortable` (needed for drag sorting).
- Localizes `JEMSE_Config.placeholder` used as the search input placeholder.

Considerations:

- No screen filtering: assets load on all admin pages. Optimizing by limiting to JetEngine editor screens would reduce overhead.
- Version constants are hardcoded; consider defining plugin constants and using `filemtime` for cache-busting during development.

---

### JavaScript Logic: `assets/js/admin.js`

Responsibilities:

- Build enhancer markup next to each `select.cx-ui-select[multiple]`.
- Hide the original select (and any adjacent Select2 container) while maintaining the select as the source of truth for saving.
- Render two zones:
  - Selected list (`.jemse-list`) with draggable items.
  - Option pool (`.jemse-pool`) for unselected options with a text filter (`.jemse-search`).

Important functions:

- `buildEnhancerMarkup($select)`: Creates wrapper, search field, choices list, and pool.
- `refreshFromSelect($select, $wrap)`: Reads `<option>`s from the select and populates the list/pool based on selection state.
- `applyOrderBackToSelect($select, $wrap)`: Writes the ordered selections back into the `<select>` by:
  - Marking options as `selected`.
  - Reordering `<option>` DOM nodes to match the chosen order (affects submit order).
  - Setting `$select.val(ordered).trigger('change')` to notify listeners.
- `attachHandlers($select, $wrap)`: Handles click-to-select/deselect, live search filter, and jQuery UI `sortable` updates to keep the select in sync.
- `init()`: Enhances all `.cx-ui-select[multiple]` on DOM ready and on JetEngine’s `cx-control-init` event (for dynamically added controls). Also re-syncs when the original select changes externally.

Compatibility handling:

- Skips AJAX-powered post selects (checks `data-action` and `data-post-type`).
- Skips repeater template placeholders (`name` containing `__i__`).
- Hides adjacent `.select2` container when present.

Potential improvements:

- Add keyboard accessibility for moving items between pool and selected list.
- Announce changes via ARIA live regions for screen readers (there is `aria-live="polite"` on choices, but explicit announcements could help).
- Debounce search input for very large option sets.
- Optionally persist search query per field instance.

Edge cases to note:

- Very large option lists: DOM building could be heavy; consider virtualization if performance becomes an issue.
- Externally mutated `<select>` (e.g., via other scripts) is handled via delegated `change` listener; ensure no infinite loops occur (current flow appears safe).

---

### CSS Styling: `assets/css/admin.css`

Highlights:

- `.jemse-hidden` hides the original select.
- `.jemse-enhancer` is a flex column container with gaps.
- `.jemse-list` is a flex wrap list for selected items; `.jemse-item` has drag cursor and light borders.
- `.jemse-pool` displays unselected options as clickable pills (`.jemse-option`).
- Commented Select2 overrides to hide containers if needed; JS already hides adjacent `.select2`.

Considerations:

- Ensure colors meet contrast requirements in WP admin.
- Provide focus styles for `.jemse-item` and `.jemse-option` to improve keyboard and accessibility support.

---

### Behavior Summary

1. On admin load, script finds `select.cx-ui-select[multiple]` and replaces UI with enhancer.
2. Selected options appear as draggable list items; unselected options appear in the pool.
3. Clicking moves options between pool and list; sorting updates order.
4. Each change updates the underlying `<select>` selection and DOM order so saved values preserve custom ordering.
5. Works with JetEngine’s dynamic control initialization via `cx-control-init` event.

---

### Risks and Compatibility

- Loads on all admin pages; scope can be narrowed to JetEngine contexts to avoid side effects.
- Interaction with other plugins that also manipulate JetEngine selects could cause race conditions; current checks (hiding Select2, syncing on `change`) mitigate common conflicts.
- Accessibility is basic; improved focus states and keyboard operations recommended.

---

### Recommendations

- Enqueue conditionally for JetEngine admin screens only.
- Add focus-visible styles and keyboard controls (e.g., Enter to move, Arrow keys to reorder with buttons as fallback).
- Debounce search input for performance with large datasets.
- Use namespaced events and data attributes to improve robustness.
- Consider a small view-agnostic store to avoid repeated DOM reads on each change.

---

### Quick Reference: Key Selectors and Events

- Selectors:
  - `.cx-ui-select[multiple]`: JetEngine multi-selects targeted for enhancement
  - `.jemse-enhancer`, `.jemse-search`, `.jemse-choices`, `.jemse-list`, `.jemse-pool`, `.jemse-option`, `.jemse-item`
- Events:
  - `cx-control-init`: JetEngine control initialization hook
  - `change` on `select.cx-ui-select[multiple]`: sync back from external mutations
  - jQuery UI `sortable` `update`: reorder sync

---

### Conclusion

The plugin is concise and purposeful: it replaces JetEngine’s default multi-select UI with a more ergonomic search-and-drag interface while preserving the original field’s value semantics. With minor improvements around conditional loading, accessibility, and performance for large lists, it should be stable and user-friendly in JetEngine-powered admin workflows.

---

## v1.1.5 update — Persistence design and JetEngine compatibility

### What changed in v1.1.5

- Persist order in a private meta key: `_jemse_order_<field_key>` (CSV). This avoids any collision with user/meta keys and keeps JetEngine’s original field value untouched.
- Localize saved orders to the admin script as `JEMSE_Config.savedOrders` for the current post; on editor load the enhancer reorders the original `<option>` DOM before building the UI so the saved order is reflected immediately.
- Add a hidden input per field `jemse_order[<field_key>]` that mirrors the current drag order as CSV. This lets the saver persist the order without affecting JetEngine’s own meta save flow.
- Hardened Select2 handling and meta-key detection in JS so the enhancer works reliably across JetEngine controls and dynamic initializations.

### Lifecycle recap with persistence

1. Editor loads → PHP enqueues assets and provides `savedOrders` for the current post.
2. JS enhances each `select.cx-ui-select[multiple]`, reorders underlying `<option>` elements using the saved CSV if available.
3. User drags/selects → JS updates the `<select>` selected state and DOM order, and writes CSV into the hidden `jemse_order[<field_key>]` input.
4. Save post → Saver stores the CSV to `_jemse_order_<field_key>` only. JetEngine still saves the field values to their original meta key unchanged in format.
5. Reload → Enhancer uses the stored CSV to restore item order.

### JetEngine format compatibility

- Field value format is not altered. JetEngine continues to save the multi-select as an array under the original meta key.
- Queries/filters/dynamic listings that rely on the field key will behave exactly as before. Only the order of the array is influenced by the admin-chosen order (which is typically desirable).
- The private `_jemse_order_<field_key>` can be optionally consumed by custom code if the order needs to drive front-end sorting, but JetEngine itself does not depend on it.

### Security and data handling

- Saver runs on `save_post` with standard capability checks (`current_user_can('edit_post')`) and avoids autosaves/revisions.
- Field keys are sanitized; the CSV order is parsed into a clean array before storing.
- Only a single private meta per field is added; no modification to user meta keys or JetEngine internals.

### Edge cases and current handling

- AJAX-powered selects (e.g., posts/tax queries) are skipped to avoid breaking asynchronous data sources.
- Repeater templates with placeholder names (`__i__`) are skipped to avoid enhancing non-instantiated controls.
- If another script mutates the original `<select>` after init, a delegated `change` listener re-syncs the enhancer.
- Very large lists: DOM building may be heavy; consider optional virtualization/debounced filtering if needed.

### Testing checklist

- Reorder items, save, and reload: order should persist in both the enhancer UI and the underlying array.
- Confirm JetEngine Listing/Grid queries continue to read the same field key and values.
- Create a brand-new post with selections and verify order persists from first save.
- Test a field in a dynamic (AJAX) JetEngine control to confirm it’s correctly skipped.
- Nested structures: confirm repeaters and cloned fields are not double-enhanced (template placeholders should be skipped).

### Recommended future improvements (non-breaking)

- Conditional enqueue on JetEngine admin screens to reduce admin-wide overhead.
- Accessibility: focus styles and keyboard actions to move items between pool and selected list.
- Optional debounce for the search input; optional virtualization for very large lists.
- Use the plugin’s own text domain (instead of `jet-engine`) for the placeholder string and load it via `load_plugin_textdomain`.
