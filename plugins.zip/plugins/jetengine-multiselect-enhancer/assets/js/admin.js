(function($){
	'use strict';

	function sanitizeKeyJS(str){
		return String(str || '')
			.toLowerCase()
			.replace(/\s+/g,'_')
			.replace(/[^a-z0-9_]/g,'_');
	}

	function extractMetaKeyFromName(name){
		if (!name) { return ''; }
		// Prefer JetEngine meta structure: jet_engine_meta[my_key][...]
		var m = name.match(/jet_engine_meta\[([^\]]+)\]/);
		if (m && m[1]) { return m[1]; }
		// Generic pattern: take the last non-numeric bracketed key
		var matches = name.match(/\[([^\]]+)\](?!.*\[)/);
		if (matches && matches[1]) {
			return matches[1];
		}
		// Fallback to a sanitized version
		return sanitizeKeyJS(name);
	}

	function getPoolLimit(){
		var limit = 5;
		if (window.JEMSE_Config && typeof JEMSE_Config.poolLimit !== 'undefined'){
			var n = parseInt(JEMSE_Config.poolLimit, 10);
			if (!isNaN(n) && n > 0) { limit = n; }
		}
		return limit;
	}

	function getTexts(){
		return {
			more: (window.JEMSE_Config && JEMSE_Config.moreText) ? JEMSE_Config.moreText : 'More',
			less: (window.JEMSE_Config && JEMSE_Config.lessText) ? JEMSE_Config.lessText : 'Less'
		};
	}

	function getDropdownMaxHeight(){
		var h = 300;
		if (window.JEMSE_Config && typeof JEMSE_Config.dropdownMaxHeight !== 'undefined'){
			var n = parseInt(JEMSE_Config.dropdownMaxHeight, 10);
			if (!isNaN(n) && n > 100) { h = n; }
		}
		return h;
	}

	function ensureToggleButton($wrap){
		var $btn = $wrap.find('.jemse-toggle');
		if (!$btn.length){
			var t = getTexts();
			$btn = $('<button type="button" class="button jemse-toggle" />').text(t.more);
			$wrap.append($btn);
		}
		return $btn;
	}

	function isExpanded($wrap){
		return $wrap.data('jemse-expanded') === true;
	}

	function setExpanded($wrap, expanded){
		$wrap.data('jemse-expanded', !!expanded);
		var t = getTexts();
		var $btn = ensureToggleButton($wrap);
		$btn.text(expanded ? t.less : t.more);
	}

	function enforcePoolLimit($wrap){
		var $pool = $wrap.find('.jemse-pool');
		var limit = getPoolLimit();
		var shown = 0;
		var expanded = isExpanded($wrap);
		var matchedCount = 0;
		$pool.children().each(function(){
			var $o = $(this);
			var match = $o.data('jemse-match');
			if (match === false) {
				$o.hide();
				return;
			}
			matchedCount++;
			if (expanded || shown < limit) {
				$o.show();
				shown++;
			} else {
				$o.hide();
			}
		});
		ensureToggleButton($wrap).toggle(matchedCount > limit);
	}

	function buildEnhancerMarkup($select){
		var id = $select.attr('id') || '';
		var $wrap = $('<div class="jemse-enhancer" />');
		var $search = $('<input type="search" class="jemse-search" placeholder="'+ (window.JEMSE_Config ? JEMSE_Config.placeholder : 'Search...') +'" />');
		var $choices = $('<div class="jemse-choices" aria-live="polite" />');
		var $list = $('<ul class="jemse-list" />');
		var $pool = $('<div class="jemse-pool" />');
		var $dropdown = $('<div class="jemse-dropdown" />').css('max-height', getDropdownMaxHeight() + 'px');
		var metaKey = extractMetaKeyFromName($select.attr('name') || '');
		var $hidden = $('<input type="hidden" class="jemse-order-holder" />')
			.attr('name', 'jemse_order[' + metaKey + ']')
			.val('');

		$wrap.append($search).append($dropdown).append($choices.append($list)).append($pool).append($hidden);
		$wrap.attr('data-for', id);
		$wrap.attr('data-meta-key', metaKey);
		return $wrap;
	}

	function refreshFromSelect($select, $wrap){
		var values = $select.val() || [];
		var selected = new Set(Array.isArray(values) ? values : [values]);
		var $list = $wrap.find('.jemse-list');
		var $pool = $wrap.find('.jemse-pool');
		$list.empty();
		$pool.empty();

		$('option', $select).each(function(){
			var $opt = $(this);
			var val = $opt.attr('value');
			var text = $opt.text();
			if (val === undefined) { return; }
			if (val === '') { return; }
			var $item = $('<li class="jemse-item" tabindex="0" />').attr('data-value', val).text(text);
			if (selected.has(val)){
				$list.append($item);
			}else{
				var $optDiv = $('<div class="jemse-option" />').attr('data-value', val).text(text);
				$optDiv.data('jemse-match', true);
				$pool.append($optDiv);
			}
		});
		enforcePoolLimit($wrap);
		refreshDropdownFromPool($wrap);
	}

	function applyOrderBackToSelect($select, $wrap){
		var ordered = [];
		$wrap.find('.jemse-list .jemse-item').each(function(){
			ordered.push($(this).attr('data-value'));
		});
		// Update selected state in DOM to preserve JetEngine/Select2 saving behavior
		$('option', $select).each(function(){
			var $opt = $(this);
			var val = $opt.attr('value');
			$opt.prop('selected', ordered.indexOf(val) !== -1);
		});
		// Reorder option nodes to reflect custom order (browsers submit in DOM order)
		var $opts = $select.find('option');
		var mapping = {};
		$opts.each(function(){ mapping[$(this).attr('value')] = this; });
		ordered.forEach(function(val){
			var node = mapping[val];
			if (node) { $select.append(node); }
		});
		$select.val(ordered).trigger('change');
		// Update hidden input for server-side persistence
		var $hidden = $wrap.find('input.jemse-order-holder');
		$hidden.val(ordered.join(','));
	}

	function attachHandlers($select, $wrap){
		var $search = $wrap.find('.jemse-search');
		var $pool = $wrap.find('.jemse-pool');
		var $list = $wrap.find('.jemse-list');
		var $dropdown = $wrap.find('.jemse-dropdown');

		$pool.on('click', '.jemse-option', function(){
			var val = $(this).attr('data-value');
			var text = $(this).text();
			$(this).remove();
			$list.append($('<li class="jemse-item" tabindex="0" />').attr('data-value', val).text(text));
			applyOrderBackToSelect($select, $wrap);
			enforcePoolLimit($wrap);
			refreshDropdownFromPool($wrap);
		});

		$list.on('click', '.jemse-item', function(){
			var val = $(this).attr('data-value');
			var text = $(this).text();
			$(this).remove();
			var $optDiv = $('<div class="jemse-option" />').attr('data-value', val).text(text);
			$optDiv.data('jemse-match', true);
			$pool.append($optDiv);
			applyOrderBackToSelect($select, $wrap);
			enforcePoolLimit($wrap);
			refreshDropdownFromPool($wrap);
		});

		$search.on('input', function(){
			var q = $(this).val().toLowerCase();
			$pool.children().each(function(){
				var $o = $(this);
				var txt = $o.text().toLowerCase();
				var isMatch = (txt.indexOf(q) !== -1);
				$o.data('jemse-match', isMatch);
			});
			enforcePoolLimit($wrap);
			refreshDropdownFromPool($wrap);
		});

		// Toggle button
		$wrap.on('click', '.jemse-toggle', function(){
			setExpanded($wrap, !isExpanded($wrap));
			enforcePoolLimit($wrap);
			refreshDropdownFromPool($wrap);
		});

		// Dropdown open/close and selection
		$search.on('focus click', function(){
			$dropdown.show();
		});
		$(document).on('mousedown.jemse', function(e){
			if (!$wrap.get(0).contains(e.target)){
				$dropdown.hide();
			}
		});
		$wrap.on('click', '.jemse-dropdown-option', function(){
			var val = $(this).attr('data-value');
			var $optInPool = $wrap.find('.jemse-pool .jemse-option[data-value="'+val+'"]');
			if ($optInPool.length){ $optInPool.trigger('click'); }
		});

		// Make selected list sortable
		$list.sortable({
			axis: 'x',
			containment: 'parent',
			update: function(){
				applyOrderBackToSelect($select, $wrap);
			}
		});
	}

	function refreshDropdownFromPool($wrap){
		var $pool = $wrap.find('.jemse-pool');
		var $dropdown = $wrap.find('.jemse-dropdown');
		$dropdown.empty();
		$pool.children().each(function(){
			var $p = $(this);
			var val = $p.attr('data-value');
			var txt = $p.text();
			var match = $p.data('jemse-match');
			if (match === false) { return; }
			var $row = $('<div class="jemse-dropdown-option" />').attr('data-value', val).text(txt);
			$dropdown.append($row);
		});
	}

	function isJetEngineSelect($select){
		return $select.hasClass('cx-ui-select');
	}

	function isMultiple($select){
		return $select.is('[multiple]');
	}

	function isAjaxPostsSelect($select){
		return !!($select.data('action') && $select.data('post-type'));
	}

	function enhanceSelect($select){
		if (!$select.length) return;
		if (!$select.is('select[multiple]')) return;
		if (isAjaxPostsSelect($select)) return; // skip AJAX posts selects
		var name = $select.attr('name') || '';
		if (name.indexOf('__i__') !== -1) return; // skip repeater templates
		var metaKey = extractMetaKeyFromName(name);
		var $wrap = buildEnhancerMarkup($select);
		$select.addClass('jemse-hidden').after($wrap);
		// Hide Select2 container if present (adjacent or sibling span)
		var $s2 = $select.next('.select2');
		if (!$s2.length) { $s2 = $select.siblings('.select2, span.select2'); }
		if ($s2.length){ $s2.hide(); }

		// Apply saved order if available before rendering list
		if (window.JEMSE_Config && JEMSE_Config.savedOrders && metaKey) {
			var csv = JEMSE_Config.savedOrders[ metaKey ];
			if (csv && typeof csv === 'string'){
				var order = csv.split(',').map(function(s){ return s.trim(); }).filter(Boolean);
				if (order.length){
					var mapping = {};
					$select.find('option').each(function(){ mapping[$(this).attr('value')] = this; });
					order.forEach(function(val){ var node = mapping[val]; if (node) { $select.append(node); } });
				}
			}
		}
		refreshFromSelect($select, $wrap);
		attachHandlers($select, $wrap);
		// Initialize hidden input value
		applyOrderBackToSelect($select, $wrap);
		enforcePoolLimit($wrap);
		refreshDropdownFromPool($wrap);
	}

	function init(){
		$('.cx-ui-select').each(function(){
			var $sel = $(this);
			if (isJetEngineSelect($sel) && isMultiple($sel)){
				enhanceSelect($sel);
			}
		});

		// When JetEngine dynamically initializes controls
		$(document).on('cx-control-init', function(e){
			var $target = e.target ? $(e.target) : $('body');
			$('.cx-ui-select[multiple]', $target).each(function(){
				var $sel = $(this);
				if (!$sel.next().hasClass('jemse-enhancer')){
					enhanceSelect($sel);
				}
			});
		});

		// Keep enhancer in sync if original select changes externally
		$('body').on('change', 'select.cx-ui-select[multiple]', function(){
			var $sel = $(this);
			var $wrap = $sel.next('.jemse-enhancer');
			if ($wrap.length){
				refreshFromSelect($sel, $wrap);
			}
		});
	}

	$(init);

})(jQuery);


