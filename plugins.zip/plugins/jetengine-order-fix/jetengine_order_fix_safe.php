<?php
/**
 * Plugin Name: Force Taxonomy Order - Direct Intervention
 * Description: Intercetta e forza fisicamente l'ordine delle tassonomie
 * Version: 1.0
 * Author: ChatGPT
 */

if (!defined('ABSPATH')) {
    exit;
}

class ForceTaxonomyOrder {
    
    public function __construct() {
        // Hook molto precoce per intercettare i dati
        add_action('init', array($this, 'intercept_post_data'), 1);
        add_action('admin_footer', array($this, 'force_order_script'));
        
        // Hook molto tardivo per salvare l'ordine
        add_action('save_post', array($this, 'force_save_order'), 999, 2);
        
        // Filtra wp_set_object_terms per mantenere l'ordine
        add_filter('wp_set_object_terms', array($this, 'maintain_term_order'), 10, 6);
    }
    
    public function intercept_post_data() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['post_ID']) || isset($_POST['post_id']))) {
            error_log("🚨 INTERCETTAZIONE POST DATA COMPLETA:");
            
            // Log di TUTTO quello che viene inviato
            foreach ($_POST as $key => $value) {
                if (is_array($value)) {
                    error_log("Array $key: " . print_r($value, true));
                } else {
                    error_log("Campo $key: " . $value);
                }
            }
            
            // Cerca specificamente campi relativi a clienti
            foreach ($_POST as $key => $value) {
                if (stripos($key, 'client') !== false || stripos($key, 'klient') !== false) {
                    error_log("🎯 CAMPO CLIENTI TROVATO - $key: " . print_r($value, true));
                }
            }
            
            error_log("🚨 FINE INTERCETTAZIONE POST DATA");
        }
    }
    
    public function force_order_script() {
        global $pagenow;
        if (!in_array($pagenow, array('post.php', 'post-new.php'))) {
            return;
        }
        ?>
        
        <script>
        jQuery(document).ready(function($) {
            
            console.log('🔥 Force Taxonomy Order - ATTACCO DIRETTO');
            
            var FORCED_ORDERS = {};
            
            // Intercetta OGNI cambio di checkbox sui campi JetEngine
            $(document).on('change', 'input[type="checkbox"]', function() {
                var checkbox = $(this);
                var name = checkbox.attr('name');
                
                // Controlla se è un campo che ci interessa
                if (name && (name.includes('clienti') || name.includes('cliente'))) {
                    var value = checkbox.val();
                    
                    if (!FORCED_ORDERS.cliente) {
                        FORCED_ORDERS.cliente = [];
                    }
                    
                    if (checkbox.is(':checked')) {
                        if (FORCED_ORDERS.cliente.indexOf(value) === -1) {
                            FORCED_ORDERS.cliente.push(value);
                        }
                    } else {
                        var idx = FORCED_ORDERS.cliente.indexOf(value);
                        if (idx > -1) {
                            FORCED_ORDERS.cliente.splice(idx, 1);
                        }
                    }
                    
                    console.log('🎯 ORDINE FORZATO CLIENTE:', FORCED_ORDERS.cliente);
                    
                    // Salva immediatamente in un campo super nascosto
                    updateForceField();
                }
            });
            
            function updateForceField() {
                var field = $('#force_cliente_order');
                if (field.length === 0) {
                    field = $('<input type="hidden" id="force_cliente_order" name="FORCE_CLIENTE_ORDER" />');
                    $('body').append(field);
                }
                field.val(JSON.stringify(FORCED_ORDERS.cliente || []));
            }
            
            // INTERCETTA IL FORM SUBMIT E MODIFICA I DATI
            $('form#post').on('submit', function(e) {
                console.log('🚨 INTERCETTAZIONE FORM SUBMIT');
                
                if (FORCED_ORDERS.cliente && FORCED_ORDERS.cliente.length > 0) {
                    
                    console.log('🔥 Modificando campo cliente nell\'ordine:', FORCED_ORDERS.cliente);
                    
                    // Trova e modifica il campo cliente esistente
                    var clienteInputs = $('input[name="cliente[]"], select[name="cliente[]"]');
                    if (clienteInputs.length > 0) {
                        clienteInputs.remove();
                    }
                    
                    // Crea nuovi input nell'ordine forzato
                    FORCED_ORDERS.cliente.forEach(function(value, index) {
                        if (value) { // Evita valori vuoti
                            var newInput = $('<input type="hidden" name="cliente[]" value="' + value + '" />');
                            $(this).append(newInput);
                            console.log('➕ Aggiunto cliente forzato:', value, 'posizione:', index);
                        }
                    }.bind(this));
                    
                    console.log('✅ CAMPO CLIENTE MODIFICATO - Ordine forzato applicato');
                }
            });
            
            // BACKUP: Modifica anche via AJAX se WordPress usa AJAX
            var originalAjax = $.ajax;
            $.ajax = function(options) {
                if (options.data && options.data.includes && options.data.includes('tax_input')) {
                    console.log('🌐 INTERCETTATA CHIAMATA AJAX CON TAX_INPUT');
                    
                    if (FORCED_ORDERS.clienti && FORCED_ORDERS.clienti.length > 0) {
                        // Modifica i dati AJAX
                        var formData = new URLSearchParams(options.data);
                        
                        // Rimuovi tax_input[clienti][] esistenti
                        for (let [key, value] of formData.entries()) {
                            if (key === 'tax_input[clienti][]') {
                                formData.delete(key);
                            }
                        }
                        
                        // Aggiungi nell'ordine forzato
                        FORCED_ORDERS.clienti.forEach(function(value) {
                            formData.append('tax_input[clienti][]', value);
                        });
                        
                        options.data = formData.toString();
                        console.log('✅ DATI AJAX MODIFICATI');
                    }
                }
                
                return originalAjax.apply(this, arguments);
            };
            
        });
        </script>
        <?php
    }
    
    public function force_save_order($post_id, $post) {
        error_log("🔥 FORCE SAVE ORDER - Post ID: $post_id");
        
        // Log TUTTO quello che arriva in save_post
        error_log("🔥 TUTTI I CAMPI POST:");
        foreach ($_POST as $key => $value) {
            if (is_array($value)) {
                error_log("  Array $key: " . print_r($value, true));
            } else {
                error_log("  Campo $key: " . substr($value, 0, 100) . (strlen($value) > 100 ? '...' : ''));
            }
        }
        
        // Cerca campi clienti in qualsiasi forma
        foreach ($_POST as $key => $value) {
            if (stripos($key, 'client') !== false || stripos($key, 'klient') !== false) {
                error_log("🎯 SAVE - CAMPO CLIENTI: $key = " . print_r($value, true));
            }
        }
        
        // Se abbiamo l'ordine forzato
        if (isset($_POST['FORCE_CLIENTI_ORDER'])) {
            $forced_order = json_decode(stripslashes($_POST['FORCE_CLIENTI_ORDER']), true);
            
            if (is_array($forced_order) && !empty($forced_order)) {
                error_log("🔥 APPLICANDO ORDINE FORZATO: " . implode(', ', $forced_order));
                
                // FORZA l'ordine bypassando tutto
                $this->force_term_assignment($post_id, $forced_order, 'clienti');
                
                // Salva anche come meta per recupero futuro
                update_post_meta($post_id, '_forced_clienti_order', $forced_order);
                
                return; // Esci per evitare altri processamenti
            }
        }
        
        // Controlla anche i metadati del post per vedere cosa viene salvato
        $all_meta = get_post_meta($post_id);
        error_log("🔥 METADATI POST SALVATI:");
        foreach ($all_meta as $meta_key => $meta_value) {
            if (stripos($meta_key, 'client') !== false || stripos($meta_key, 'klient') !== false) {
                error_log("  Meta $meta_key: " . print_r($meta_value, true));
            }
        }
    }
    
    private function force_term_assignment($post_id, $term_ids, $taxonomy) {
        // Rimuovi tutti i termini esistenti
        wp_delete_object_term_relationships($post_id, $taxonomy);
        
        // Aggiungi i termini uno per uno nell'ordine specifico
        foreach ($term_ids as $index => $term_id) {
            wp_set_object_terms($post_id, array($term_id), $taxonomy, true); // append = true
            error_log("🔥 Aggiunto termine $term_id in posizione $index");
        }
        
        error_log("🔥 FORCE ASSIGNMENT COMPLETATO per $taxonomy");
    }
    
    public function maintain_term_order($tt_ids, $object_id, $terms, $taxonomy, $append, $old_tt_ids) {
        error_log("🔥 wp_set_object_terms chiamato per $taxonomy: " . implode(', ', $terms));
        
        // Se è per clienti e abbiamo un ordine salvato, usalo
        if ($taxonomy === 'clienti') {
            $forced_order = get_post_meta($object_id, '_forced_clienti_order', true);
            if (!empty($forced_order)) {
                error_log("🔥 Usando ordine forzato salvato: " . implode(', ', $forced_order));
                // Non modificare, lascia che usi l'ordine forzato
            }
        }
        
        return $tt_ids;
    }
}

new ForceTaxonomyOrder();