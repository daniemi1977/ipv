(function($){
    if (typeof JEOrderFix === 'undefined') return;

    const targetFields = Array.isArray(JEOrderFix.fields) ? JEOrderFix.fields : [];
    const enableDrag = !!JEOrderFix.enableDrag;

    function fieldMatches($select){
        if ($select.prop('multiple') !== true) return false;

        const name = ($select.attr('name') || '');
        if (targetFields.length === 0) {
            // No whitelist provided: try to match JetEngine multi selects in meta boxes.
            return /\[(.*?)\]\[\]$/.test(name); // any field[]
        }
        // Match one of configured keys
        return targetFields.some(key => name.includes('[' + key + ']'));
    }

    function getFieldKey($select){
        const name = ($select.attr('name') || '');
        const m = name.match(/\[([^\]]+)\]\[\]$/);
        return m ? m[1] : null;
    }

    function ensureOrderInput($select, key){
        const id = 'jeof-order-' + key;
        let $hidden = $('#'+id);
        if ($hidden.length === 0) {
            $hidden = $('<input>', {type:'hidden', id:id, name:'jeof_order['+key+']'});
            $select.closest('.jet-engine-meta-field, .cmb-row, .postbox, .inside, .metabox-holder, body').first().append($hidden);
        }
        return $hidden;
    }

    function buildLabelToValueMap($select){
        const map = {};
        $select.find('option').each(function(){
            const $opt = $(this);
            map[$opt.text().trim()] = $opt.val();
        });
        return map;
    }

    function reorderOptionsDom($select, values){
        // Detach and append selected options in the desired order to influence posted order
        values.forEach(function(val){
            const $opt = $select.find('option[value="'+ CSS.escape(String(val)) +'"]');
            if ($opt.length) {
                $opt.detach();
                // Mark as selected explicitly (Select2 sometimes toggles asynchronously)
                $opt.prop('selected', true);
                $select.append($opt);
            }
        });
    }

    function captureOrder($select, $ul, $hidden, labelMap){
        if (!$select || $select.length === 0) return;
        // Build order using visible tokens
        const labels = [];
        $ul.find('li.select2-selection__choice').each(function(){
            const t = ($(this).attr('title') || '').trim();
            if (t) labels.push(t);
        });
        // Map labels -> values (fallback to current select2 data when possible)
        const values = [];
        const data = ($select.data('select2') && $select.select2('data')) ? $select.select2('data') : [];
        const labelToValFromData = {};
        data.forEach(function(d){
            if (d && typeof d.text !== 'undefined' && typeof d.id !== 'undefined') {
                labelToValFromData[String(d.text).trim()] = d.id;
            }
        });

        labels.forEach(function(lbl){
            let v = labelToValFromData[lbl];
            if (typeof v === 'undefined') v = labelMap[lbl];
            if (typeof v !== 'undefined') values.push(v);
        });

        // Update hidden field and reorder DOM <option>s
        $hidden.val(values.join(','));
        reorderOptionsDom($select, values);
    }

    function makeSortable($select){
        if (!enableDrag) return;

        // Wait until select2 is attached
        const tryInit = function(){
            const $container = $select.next('.select2');
            if ($container.length === 0) return false;

            const $ul = $container.find('.select2-selection__rendered');
            if ($ul.data('jeof-sortable')) return true;

            const labelMap = buildLabelToValueMap($select);
            const key = getFieldKey($select);
            if (!key) return true;

            const $hidden = ensureOrderInput($select, key);

            // initial capture
            setTimeout(function(){
                captureOrder($select, $ul, $hidden, labelMap);
            }, 50);

            // Bind sortable
            try {
                $ul.sortable({
                    containment: 'parent',
                    tolerance: 'pointer',
                    update: function(){
                        captureOrder($select, $ul, $hidden, labelMap);
                        $select.trigger('change');
                    }
                });
                $ul.data('jeof-sortable', true);
            } catch(e){
                console.warn('JEOrderFix sortable error', e);
            }

            // Keep the order when items are (un)selected
            $select.on('select2:select select2:unselect', function(){
                setTimeout(function(){
                    captureOrder($select, $ul, $hidden, labelMap);
                }, 10);
            });

            return true;
        };

        // attempt multiple times (JetEngine may init select2 later)
        let attempts = 0;
        const iv = setInterval(function(){
            attempts++;
            if (tryInit() || attempts > 40) clearInterval(iv);
        }, 200);
    }

    function boot(){
        $('select[multiple]').each(function(){
            const $sel = $(this);
            if (!$sel.is(':visible')) return;
            if (!fieldMatches($sel)) return;
            if ($sel.data('jeof-bound')) return;

            $sel.data('jeof-bound', true);
            makeSortable($sel);
        });
    }

    $(document).ready(function(){
        boot();
        // In case blocks/meta reload dynamically
        setInterval(boot, 800);
    });

})(jQuery);
