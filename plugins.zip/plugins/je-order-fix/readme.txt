=== JetEngine Order Fix – Preserve Multi-Select Order ===
Contributors: chatgpt-assistant
Tags: jetengine, select2, order, meta, custom fields, crocoblock
Requires at least: 5.6
Tested up to: 6.6
Stable tag: 1.0.0
License: GPLv2 or later

Preserves manual order for JetEngine Multi Select fields: prevents automatic reordering, enables drag & drop of selected tokens, and enforces the desired order on save.

== Description ==
- Keep the **insertion order** of selected items in JetEngine multi-select fields.
- Optional **drag & drop** to rearrange selected tokens via Select2.
- Enforce order in `save_post` to avoid backend auto-sorting.
- Target specific fields by listing their **meta keys** in Settings → JE Order Fix. Leave empty to target all JetEngine multi-selects.

== Installation ==
1. Upload the plugin zip and activate it.
2. Go to **Settings → JE Order Fix**.
3. Enter the **meta keys** (comma-separated) of your JetEngine Multi Select fields (optional).
4. Ensure **Drag & Drop** and **Enforce on Save** are enabled.

== Notes ==
Works best with JetEngine meta boxes using Select2 multi-selects. For relationship or repeater fields, behavior may vary.

== Changelog ==
= 1.0.0 =
* Initial release.
