<?php
/*
Plugin Name: JetEngine Order Fix – Preserve Multi-Select Order
Description: Disabilita il riordino automatico dei campi Multi Select di JetEngine, preservando l'ordine di inserimento e consentendo il drag & drop dei tag selezionati. Applica e salva l'ordine scelto.
Version: 1.0.0
Author: ChatGPT Assistant
Text Domain: je-order-fix
*/

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'JEOF_VERSION', '1.0.0' );
define( 'JEOF_PATH', plugin_dir_path( __FILE__ ) );
define( 'JEOF_URL', plugin_dir_url( __FILE__ ) );

require_once JEOF_PATH . 'includes/class-admin.php';
require_once JEOF_PATH . 'includes/class-order-fixer.php';

// init
add_action( 'plugins_loaded', function() {
    // defaults
    $defaults = array(
        'meta_keys'    => '',
        'enable_drag'  => 1,
        'enforce_save' => 1,
    );
    $opt = get_option( 'jeof_options' );
    if ( ! is_array( $opt ) ) {
        update_option( 'jeof_options', $defaults );
    } else {
        // ensure required keys exist
        update_option( 'jeof_options', wp_parse_args( $opt, $defaults ) );
    }
});

// admin UI + assets
new JEOF_Admin();
// save_post reorder enforcement
new JEOF_Order_Fixer();
