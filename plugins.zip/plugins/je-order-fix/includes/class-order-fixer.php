<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class JEOF_Order_Fixer {

    public function __construct() {
        // enforce after JetEngine saved meta; run late
        add_action( 'save_post', array( $this, 'enforce_order_on_save' ), 99, 2 );
    }

    /**
     * Reorder saved meta arrays according to jeof_order[field_key] submitted by our JS.
     */
    public function enforce_order_on_save( $post_id, $post ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( wp_is_post_revision( $post_id ) ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;

        $opt = get_option( 'jeof_options', array() );
        if ( empty( $opt['enforce_save'] ) ) return;

        if ( empty( $_POST['jeof_order'] ) || ! is_array( $_POST['jeof_order'] ) ) return;

        $orders = wp_unslash( $_POST['jeof_order'] );

        foreach ( $orders as $meta_key => $csv ) {
            $csv = trim( (string) $csv );
            if ( $csv === '' ) continue;

            $desired = array_values( array_filter( array_map( 'trim', explode( ',', $csv ) ), 'strlen' ) );
            if ( empty( $desired ) ) continue;

            // Get current saved value (after JetEngine)
            $current = get_post_meta( $post_id, $meta_key, true );

            // If not array, try to parse as comma list
            if ( ! is_array( $current ) ) {
                if ( is_string( $current ) && strpos( $current, ',' ) !== false ) {
                    $current = array_map( 'trim', explode( ',', $current ) );
                } elseif ( $current === '' || $current === null ) {
                    $current = array();
                } else {
                    $current = array( (string) $current );
                }
            }

            if ( empty( $current ) ) {
                // nothing to do
                continue;
            }

            // Keep only items that exist in current selection
            $ordered = array();
            foreach ( $desired as $val ) {
                // Loose compare as strings
                foreach ( $current as $curr ) {
                    if ( (string) $curr === (string) $val ) {
                        $ordered[] = $curr;
                        break;
                    }
                }
            }

            // Append any remaining items that were selected but not present in desired list (fallback)
            foreach ( $current as $curr ) {
                if ( ! in_array( (string) $curr, array_map( 'strval', $ordered ), true ) ) {
                    $ordered[] = $curr;
                }
            }

            // Update only if array changed
            if ( $ordered !== $current ) {
                update_post_meta( $post_id, $meta_key, $ordered );
            }
        }
    }
}
