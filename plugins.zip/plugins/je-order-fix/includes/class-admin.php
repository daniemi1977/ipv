<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class JEOF_Admin {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'menu' ) );
        add_action( 'admin_init', array( $this, 'settings' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
    }

    public function menu() {
        add_options_page(
            __( 'JE Order Fix', 'je-order-fix' ),
            __( 'JE Order Fix', 'je-order-fix' ),
            'manage_options',
            'je-order-fix',
            array( $this, 'render' )
        );
    }

    public function settings() {
        register_setting( 'jeof', 'jeof_options', array(
            'type' => 'array',
            'sanitize_callback' => array( $this, 'sanitize' ),
            'default' => array(
                'meta_keys'    => '',
                'enable_drag'  => 1,
                'enforce_save' => 1,
            ),
        ));

        add_settings_section( 'jeof_section_main', __( 'Impostazioni principali', 'je-order-fix' ), function(){
            echo '<p>' . esc_html__( 'Indica i meta key (field name JetEngine) dei campi Multi Select dove vuoi preservare l’ordine. Opzionale: abilita il drag & drop e forza l’ordine in salvataggio.', 'je-order-fix' ) . '</p>';
        }, 'je-order-fix' );

        add_settings_field( 'meta_keys', __( 'Meta key dei campi (comma-separated)', 'je-order-fix' ), array( $this, 'field_meta_keys' ), 'je-order-fix', 'jeof_section_main' );
        add_settings_field( 'enable_drag', __( 'Abilita drag & drop in editor', 'je-order-fix' ), array( $this, 'field_enable_drag' ), 'je-order-fix', 'jeof_section_main' );
        add_settings_field( 'enforce_save', __( 'Forza ordine durante il salvataggio', 'je-order-fix' ), array( $this, 'field_enforce_save' ), 'je-order-fix', 'jeof_section_main' );
    }

    public function sanitize( $input ) {
        $out = array();
        $out['meta_keys'] = isset( $input['meta_keys'] ) ? sanitize_text_field( $input['meta_keys'] ) : '';
        $out['enable_drag'] = ! empty( $input['enable_drag'] ) ? 1 : 0;
        $out['enforce_save'] = ! empty( $input['enforce_save'] ) ? 1 : 0;
        return $out;
    }

    public function field_meta_keys() {
        $opt = get_option( 'jeof_options', array() );
        printf(
            '<input type="text" name="jeof_options[meta_keys]" value="%s" class="regular-text" placeholder="es. process_steps, prodotti_collegati">',
            isset( $opt['meta_keys'] ) ? esc_attr( $opt['meta_keys'] ) : ''
        );
        echo '<p class="description">' . esc_html__( 'Usa i nomi dei campi JetEngine (meta key). Se vuoto, il plugin tenterà di abilitarsi su tutti i select multipli JetEngine.', 'je-order-fix' ) . '</p>';
    }

    public function field_enable_drag() {
        $opt = get_option( 'jeof_options', array() );
        printf(
            '<label><input type="checkbox" name="jeof_options[enable_drag]" value="1" %s> %s</label>',
            ! empty( $opt['enable_drag'] ) ? 'checked' : '',
            esc_html__( 'Permetti ordinamento manuale dei tag selezionati (drag & drop).', 'je-order-fix' )
        );
    }

    public function field_enforce_save() {
        $opt = get_option( 'jeof_options', array() );
        printf(
            '<label><input type="checkbox" name="jeof_options[enforce_save]" value="1" %s> %s</label>',
            ! empty( $opt['enforce_save'] ) ? 'checked' : '',
            esc_html__( 'Durante il salvataggio del post, forza l’ordine configurato, evitando riordini automatici.', 'je-order-fix' )
        );
    }

    public function render() {
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'JetEngine Order Fix', 'je-order-fix' ); ?></h1>
            <form action="options.php" method="post">
                <?php
                    settings_fields( 'jeof' );
                    do_settings_sections( 'je-order-fix' );
                    submit_button();
                ?>
            </form>

            <hr>
            <h2><?php esc_html_e( 'Come funziona', 'je-order-fix' ); ?></h2>
            <ol>
                <li><?php esc_html_e( 'Inserisci i meta key dei campi Multi Select interessati (opzionale).', 'je-order-fix' ); ?></li>
                <li><?php esc_html_e( 'Abilita il drag & drop per riordinare visivamente i tag selezionati.', 'je-order-fix' ); ?></li>
                <li><?php esc_html_e( 'Abilita l’enforcement in salvataggio per preservare l’ordine anche se JetEngine applica riordini.', 'je-order-fix' ); ?></li>
            </ol>
            <p><strong><?php esc_html_e( 'Nota:', 'je-order-fix' ); ?></strong> <?php esc_html_e( 'Il plugin non modifica i dati non selezionati; agisce solo sull’ordine degli elementi selezionati.', 'je-order-fix' ); ?></p>
        </div>
        <?php
    }

    public function assets( $hook ) {
        // Only on post edit screens and on our settings page
        $screen = get_current_screen();
        $is_edit = in_array( $hook, array( 'post.php', 'post-new.php' ), true );
        $is_settings = ( $hook === 'settings_page_je-order-fix' );

        if ( ! $is_edit && ! $is_settings ) {
            return;
        }

        $opt = get_option( 'jeof_options', array() );
        $fields = array();
        if ( ! empty( $opt['meta_keys'] ) ) {
            $fields = array_filter( array_map( 'trim', explode( ',', $opt['meta_keys'] ) ) );
        }

        wp_enqueue_style( 'jeof-admin', JEOF_URL . 'assets/admin.css', array(), JEOF_VERSION );
        wp_enqueue_script( 'jquery-ui-sortable' );
        wp_enqueue_script( 'jeof-admin', JEOF_URL . 'assets/admin.js', array( 'jquery' ), JEOF_VERSION, true );
        wp_localize_script( 'jeof-admin', 'JEOrderFix', array(
            'fields' => $fields,
            'enableDrag' => ! empty( $opt['enable_drag'] ),
            'enforceSave' => ! empty( $opt['enforce_save'] ),
        ) );
    }
}
