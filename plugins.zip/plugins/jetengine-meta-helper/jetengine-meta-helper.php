<?php
/*
Plugin Name: JetEngine Meta Helper
Description: Shortcode to display JetEngine meta fields including taxonomy select fields.
Version: 1.1
Author: ChatGPT
*/

function jemh_display_meta_field($atts) {
    $atts = shortcode_atts(array(
        'field' => '',
    ), $atts);

    if (empty($atts['field'])) {
        return '';
    }

    $post_id = get_the_ID();
    $field = $atts['field'];
    $value = get_post_meta($post_id, $field, true);

    if (!$value) {
        return '';
    }

    // If it's a taxonomy term ID, try to get its name
    if (is_numeric($value)) {
        $term = get_term($value);
        if ($term && !is_wp_error($term)) {
            return esc_html($term->name);
        }
    }

    // If it's a serialized array, maybe from multiple selects
    if (is_serialized($value)) {
        $value = maybe_unserialize($value);
    }
    
    // Handle arrays (both serialized and regular arrays)
    if (is_array($value)) {
        $names = array();
        foreach ($value as $val) {
            // Skip empty values
            if (empty($val)) {
                continue;
            }
            
            if (is_numeric($val)) {
                $term = get_term($val);
                if ($term && !is_wp_error($term)) {
                    $names[] = esc_html($term->name);
                }
            } else {
                $names[] = esc_html($val);
            }
        }
        
        // Only return if we have valid names
        if (!empty($names)) {
            return implode(', ', $names);
        }
        return '';
    }

    return esc_html($value);
}
add_shortcode('jetmeta', 'jemh_display_meta_field');
?>