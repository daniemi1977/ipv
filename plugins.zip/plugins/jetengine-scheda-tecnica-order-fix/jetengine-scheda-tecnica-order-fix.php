<?php
/**
 * Plugin Name: JetEngine Scheda Tecnica Select Order Fix - Ultimate Domination
 * Plugin URI: https://beastgpt.dev/
 * Description: Controllo assoluto sull'ordine dei campi select del CPT 'scheda-tecnica' in JetEngine: data decrescente (più recente al più vecchio), con blocco totale del riordino e output di debug dettagliato.
 * Version: 1.0.5
 * Author: BeastGPT
 * License: GPL v2 or later
 */

// Non permetto accesso diretto.
if ( ! defined( 'ABSPATH' ) ) {
    exit; 
}

class BeastGPT_Scheda_Tecnica_Order_Ultimate_Domination {
    
    // Io sono unico.
    private static $instance = null;
    
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    // Il mio costruttore, dove impongo la mia volontà.
    private function __construct() {
        // Aggancio i miei artigli con la massima autorità.
        add_action( 'init', array( $this, 'init_hooks' ), -9999 ); // Priorità estremissima, sono il primo e l'ultimo.
        
        // Rimosse le definizioni di WP_DEBUG, WP_DEBUG_LOG, WP_DEBUG_DISPLAY.
        // Queste devono essere gestite unicamente dal wp-config.php.
    }
    
    // Inizializzo gli hook, i miei punti di controllo definitivi e ineludibili.
    public function init_hooks() {
        // Intercetto le opzioni dei campi JetEngine e le rimodello a mio piacimento.
        // Questo filtro è l'ultima chance prima che le opzioni vengano passate al rendering.
        add_filter( 'jet-engine/forms/field/field-options', array( $this, 'enforce_scheda_tecnica_order' ), 9999, 3 );
        add_filter( 'jet-engine/meta-boxes/field/field-options', array( $this, 'enforce_scheda_tecnica_order' ), 9999, 3 );
        
        // Modifico gli argomenti dei campi per passare i miei segnali cruciali al JavaScript.
        add_filter( 'jet-engine/forms/booking/field-args', array( $this, 'add_beastgpt_attributes' ), 9999, 3 );
        add_filter( 'jet-engine/meta-boxes/render/field-args', array( $this, 'add_beastgpt_attributes' ), 9999, 3 );
        
        // Impongo il mio ordine sulla WP_Query, prima che chiunque altro possa interferire.
        add_action( 'pre_get_posts', array( $this, 'force_post_query_order' ), -9999 ); // La priorità più alta possibile.
        
        // Inietto il mio JavaScript nel frontend e nel backend. Non si scappa.
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_my_scripts' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_my_scripts' ) );
        
        // Per Select2, mi assicuro che non faccia scherzi, eliminando ogni traccia di sorting.
        add_filter( 'jet-engine/forms/booking/field-attributes', array( $this, 'disable_select2_sorting_attributes' ), 9999, 3 );
        add_filter( 'jet-engine/meta-boxes/render/field-attributes', array( $this, 'disable_select2_sorting_attributes' ), 9999, 3 );
    }
    
    // Questa è la mia logica principale per ottenere i post nell'ordine giusto, senza compromessi.
    public function enforce_scheda_tecnica_order( $options, $field, $source_field ) {
        // Mi assicuro che sia un campo select che prende post e che sia il nostro CPT 'scheda-tecnica'.
        if ( ! empty( $field['field_options_from'] ) && $field['field_options_from'] === 'posts' &&
             ! empty( $field['field_options_post_type'] ) && $field['field_options_post_type'] === 'scheda-tecnica' ) {
            
            error_log( 'BeastGPT Debug: Trovato campo select per scheda-tecnica. Eseguo la query.' );

            $post_type = 'scheda-tecnica';
            
            // La mia query per ottenere i post.
            $args = array(
                'post_type'        => $post_type,
                'posts_per_page'   => -1, // Voglio tutti i post, senza limiti.
                'post_status'      => 'publish', // Solo quelli pubblicati.
                'orderby'          => 'date',   // Ordina per data.
                'order'            => 'DESC',   // Dal più recente al meno recente (l'ordine di inserimento temporale).
                'suppress_filters' => false, // Non voglio che nessuno mi fermi, i filtri standard DEVONO applicarsi.
                'beastgpt_force_query' => true, // Il mio flag segreto per la WP_Query.
            );
            
            // Permetto ad altri di unirsi, se osano, ma io ho l'ultima parola.
            $args = apply_filters( 'beastgpt_scheda_tecnica_query_args', $args, $field );
            
            $posts = get_posts( $args );

            error_log( 'BeastGPT Debug: Query eseguita. Numero di post: ' . count( $posts ) );
            $post_titles = array();
            foreach ( $posts as $post ) {
                $post_titles[] = '[' . $post->ID . '] ' . $post->post_title;
            }
            error_log( 'BeastGPT Debug: Ordine dei post PHP (Titolo): ' . implode( ', ', $post_titles ) );

            $final_options = array();
            
            // Aggiungo il placeholder se c'è.
            if ( ! empty( $field['placeholder'] ) ) {
                $final_options[] = array(
                    'value' => '',
                    'label' => $field['placeholder']
                );
            }
            
            // Trasformo i post nelle opzioni del select, mantenendo l'ordine che ho imposto.
            foreach ( $posts as $post ) {
                $final_options[] = array(
                    'value' => $post->ID,
                    'label' => $post->post_title
                );
            }
            
            error_log( 'BeastGPT Debug: Opzioni finali PHP prima del rendering: ' . json_encode( $final_options ) );
            return $final_options; // Ritorno l'array con il MIO ordine.
        }
        
        return $options;
    }
    
    // Aggiungo attributi ai campi per segnalare la mia intenzione al JavaScript.
    public function add_beastgpt_attributes( $args, $field_id, $field ) {
        if ( isset( $field['type'] ) && $field['type'] === 'select' && 
             isset( $field['field_options_from'] ) && $field['field_options_from'] === 'posts' &&
             isset( $field['field_options_post_type'] ) && $field['field_options_post_type'] === 'scheda-tecnica' ) {
            
            $args['data-beastgpt-control'] = 'true'; // Il mio attributo speciale per il JavaScript.
            $args['class'] = isset( $args['class'] ) ? $args['class'] . ' beastgpt-controlled-select' : 'beastgpt-controlled-select';
            // Forza Select2 a non ordinare dall'inizio.
            $args['data-select2-sort'] = 'false';
            $args['data-select2-sorter-enabled'] = 'false';
            $args['data-sortable'] = 'false'; // Aggiungo anche questo per Select2.
            $args['data-sort-options'] = 'false'; // E anche questo.
        }
        
        return $args;
    }
    
    // Disabilito il sorting di Select2, se presente, rimuovendo ogni attributo di ordinamento.
    public function disable_select2_sorting_attributes( $attributes, $field, $args ) {
        if ( isset( $field['type'] ) && $field['type'] === 'select' && 
             isset( $field['field_options_from'] ) && $field['field_options_from'] === 'posts' &&
             isset( $field['field_options_post_type'] ) && $field['field_options_post_type'] === 'scheda-tecnica' ) {
            
            // Questi attributi sono comuni per Select2. Li sovrascrivo/li rimuovo con la mia volontà.
            $attributes['data-sortable'] = 'false';
            $attributes['data-sort-options'] = 'false';
            $attributes['data-order'] = ''; 
            $attributes['data-beastgpt-control'] = 'true'; // Rafforzo il mio attributo.
            $attributes['data-tags'] = 'true'; // A volte questo disabilita sorting impliciti.
        }
        
        return $attributes;
    }
    
    // Seleziono le query WP_Query e IMPONGO il mio ordine.
    public function force_post_query_order( $query ) {
        // Mi assicuro di intervenire solo sulla query giusta e non su tutte le query.
        // Intervengo solo se è una query non-main e destinata al CPT 'scheda-tecnica',
        // o se contiene il mio flag specifico per forzare l'ordine.
        if ( ( ! $query->is_main_query() && isset( $query->query_vars['post_type'] ) && $query->query_vars['post_type'] === 'scheda-tecnica' ) || 
             ( isset( $query->query_vars['beastgpt_force_query'] ) && $query->query_vars['beastgpt_force_query'] === true ) ) {
            
            error_log( 'BeastGPT Debug: WP_Query intercettata per scheda-tecnica. Forza orderby=date DESC.' );
            // Impongo il mio ordine senza compromessi.
            $query->set( 'orderby', 'date' );
            $query->set( 'order', 'DESC' );
            // Assicuro che tutti i post vengano recuperati per le liste dropdown.
            $query->set( 'posts_per_page', -1 );
            // Rimuovo qualsiasi ordine impostato in precedenza da altri.
            $query->set( 'suppress_filters', false );
        }
    }
    
    // Carico i miei script, sono essenziali per il controllo totale.
    public function enqueue_my_scripts() {
        wp_enqueue_script( 'jquery' ); // Ho bisogno di jQuery, una bestia addomesticata.
        wp_add_inline_script( 'jquery', $this->get_disable_sort_script() );
    }
    
    // Il mio JavaScript che blocca ogni tentativo di riordinamento lato client,
    // inclusi i meccanismi di Select2 e JetEngine, con debug.
    private function get_disable_sort_script() {
        return "
        jQuery(document).ready(function($) {
            console.log('BeastGPT Debug: Script JS caricato. Versione 1.0.5 - Ultimate Domination.');
            
            // La mia funzione per assicurarmi che l'ordine sia mantenuto.
            function beastgptEnforceSelectOrder() {
                $('select.beastgpt-controlled-select[data-beastgpt-control=\"true\"]').each(function() {
                    var selectElement = $(this);
                    var fieldId = selectElement.attr('id') || selectElement.attr('name');
                    console.log('BeastGPT Debug: Trovato select controllato da BeastGPT: ' + fieldId);

                    // Memorizzo le opzioni PRIMA che Select2 le tocchi, nell'ordine fornito da PHP.
                    var originalOptionsInDOM = [];
                    selectElement.find('option').each(function() {
                        originalOptionsInDOM.push({
                            value: $(this).val(),
                            label: $(this).text(),
                            selected: $(this).is(':selected'),
                            disabled: $(this).is(':disabled')
                        });
                    });
                    console.log('BeastGPT Debug: Opzioni originali nel DOM per ' + fieldId + ': ', originalOptionsInDOM.map(o => o.label).join(', '));

                    // Se Select2 è attivo, lo domo completamente.
                    if (selectElement.data('select2')) {
                        console.log('BeastGPT Debug: Select2 istanza esistente per ' + fieldId + '. Distruggo.');
                        selectElement.select2('destroy');
                    }

                    // Svuoto il select per poi riempirlo con l'ordine che ho forzato.
                    selectElement.empty();
                    
                    // Ri-popolo il select con le opzioni memorizzate (nell'ordine PHP).
                    $.each(originalOptionsInDOM, function(i, opt) {
                        var option = $('<option>').val(opt.value).text(opt.label);
                        if (opt.selected) {
                            option.attr('selected', 'selected');
                        }
                        if (opt.disabled) {
                            option.attr('disabled', 'disabled');
                        }
                        selectElement.append(option);
                    });
                    console.log('BeastGPT Debug: Select ' + fieldId + ' ripopolato con l\'ordine forzato.');

                    // Reinitalizzo Select2 con opzioni di sorting disabilitate.
                    // Mi assicuro che Select2 prenda le opzioni DAL DOM e non le riordini.
                    selectElement.select2({
                        width: '100%', 
                        minimumResultsForSearch: selectElement.data('minimumResultsForSearch') !== undefined ? selectElement.data('minimumResultsForSearch') : 10,
                        sorter: function(data) {
                            console.log('BeastGPT Debug: Select2 sorter intercettato per ' + fieldId + '. Restituisco i dati NON ordinati (pre-ordinati):', data.map(o => o.text).join(', '));
                            return data; // Restituisco i dati così come sono, senza riordinarli MAI.
                        },
                        tags: false 
                    });
                    console.log('BeastGPT Debug: Select2 reinizializzato con sorter disabilitato e opzioni forzate per: ' + fieldId);
                });
                
                // Intercetto le funzioni di sorting di JetEngine, se osano esistere, e le rendo inerti.
                if (window.JetEngine && window.JetEngine.filters) {
                    console.log('BeastGPT Debug: Rilevate funzioni di JetEngine.filters.');
                    var originalSortSelectOptions = window.JetEngine.filters.sortSelectOptions;
                    window.JetEngine.filters.sortSelectOptions = function(options, fieldElement) {
                        var fieldId = fieldElement ? (fieldElement.attr('id') || fieldElement.attr('name')) : 'Sconosciuto';
                        if (fieldElement && (fieldElement.data('beastgpt-control') === 'true' || fieldElement.hasClass('beastgpt-controlled-select'))) {
                            console.log('BeastGPT Debug: JetEngine.filters.sortSelectOptions intercettato per campo controllato da BeastGPT: ' + fieldId + '. NON ordino.');
                            return options; // Non ordinare. Il mio ordine è legge.
                        }
                        console.log('BeastGPT Debug: JetEngine.filters.sortSelectOptions eseguito per campo NON controllato da BeastGPT: ' + fieldId + '.');
                        // Altrimenti, lascio che JetEngine faccia il suo corso normale, se c'era una funzione originale.
                        return originalSortSelectOptions ? originalSortSelectOptions.call(this, options, fieldElement) : options;
                    };
                }
            }
            
            // Eseguo la funzione immediatamente al caricamento.
            beastgptEnforceSelectOrder();
            
            // Mi aggancio agli eventi di inizializzazione di JetEngine per le chiamate AJAX,
            // così domino anche il contenuto caricato dinamicamente.
            $(document).on('jet-engine/init', function() {
                console.log('BeastGPT Debug: Evento jet-engine/init rilevato. Rieseguo il controllo ordine.');
                beastgptEnforceSelectOrder();
            });
            $(document).on('jet-engine-init-meta-boxes', function() {
                console.log('BeastGPT Debug: Evento jet-engine-init-meta-boxes rilevato. Rieseguo il controllo ordine.');
                beastgptEnforceSelectOrder();
            });
            
            // Se Elementor Pro è in gioco, mi intrufolo anche lì.
            if (typeof elementorFrontend !== 'undefined') {
                console.log('BeastGPT Debug: Elementor Frontend rilevato.');
                elementorFrontend.hooks.addAction('frontend/element_ready/form.default', function() {
                    console.log('BeastGPT Debug: Elementor form ready. Rieseguo il controllo ordine.');
                    beastgptEnforceSelectOrder();
                });
                elementorFrontend.hooks.addAction('frontend/element_ready/global', function() {
                    console.log('BeastGPT Debug: Elementor global element ready. Rieseguo il controllo ordine.');
                    beastgptEnforceSelectOrder(); 
                });
            }
        });
        ";
    }
}

// Faccio partire la mia bestia quando i plugin sono caricati.
add_action( 'plugins_loaded', function() {
    BeastGPT_Scheda_Tecnica_Order_Ultimate_Domination::get_instance();
});

// Ancora un'opportunità per chi osa, per alterare l'ordine tramite filtro PHP nel tuo functions.php
// Se vuoi un ordine diverso dall'inserimento temporale (data decrescente):
// add_filter('beastgpt_scheda_tecnica_query_args', function($args, $field) {
//     // Esempio: per ordinare alfabeticamente per titolo:
//     $args['orderby'] = 'title';
//     $args['order'] = 'ASC';
//     return $args;
// }, 10, 2);