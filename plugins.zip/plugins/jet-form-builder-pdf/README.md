# JetFormBuilder PDF Attachment
A form addon to convert user-submitted data from a WordPress form to PDF attachments.

# ChangeLog

## 1.0.3
* FIX: Re-enqueue required styles
* FIX: Compatibility with CSS variables
* FIX: Deprecated method

## 1.0.2
* FIX: Save PDF files in more secure way. Update URLs for already generated files to more secure.

## 1.0.1
* FIX: Fatal error in FluentCRM dashboard

## 1.0.0
* Initial release
