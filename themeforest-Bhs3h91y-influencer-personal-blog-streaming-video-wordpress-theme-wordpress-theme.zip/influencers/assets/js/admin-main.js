!(function($){
	"use strict";

	jQuery(document).ready(function($) {

	});

	jQuery(window).on('resize', function() {
    InfluencersSubmenuAuto();
	});

	jQuery(window).on('scroll', function() {

	});

})(jQuery);
