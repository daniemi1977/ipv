		<?php get_template_part( 'framework/templates/site', 'footer'); ?>
	</div><!-- #page -->
	<?php wp_footer(); ?>
</body>
</html>
