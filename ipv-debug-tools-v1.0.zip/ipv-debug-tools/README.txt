╔════════════════════════════════════════════════════════════════════════╗
║                                                                        ║
║   IPV PRO VENDOR - DEBUG TOOLS v1.0                                   ║
║   Per risolvere: "Error: unauthorized" persistente                    ║
║                                                                        ║
╚════════════════════════════════════════════════════════════════════════╝

📦 CONTENUTO PACKAGE

1. ipv-vendor-debug-test.php
   → Script HTML che mostra quali header arrivano al server
   → Carica nella ROOT del server (public_html/)
   → Accedi via browser: https://tuo-server.com/ipv-vendor-debug-test.php

2. ipv-vendor-test-endpoint.php
   → Endpoint WordPress REST API per test avanzati
   → Carica in: wp-content/plugins/ipv-pro-vendor/
   → Attiva modificando ipv-pro-vendor.php (vedi istruzioni nel file)

3. DEBUG-UNAUTHORIZED-ERROR.md
   → Guida completa step-by-step per il debug
   → Leggi questo file per istruzioni dettagliate
   → 6 fasi di debug progressive

4. README.txt
   → Questo file

═══════════════════════════════════════════════════════════════════════

🚀 QUICK START (5 MINUTI)

FASE 1: Verifica Header Authorization
─────────────────────────────────────

1. Carica "ipv-vendor-debug-test.php" in: public_html/

2. Visita: https://aiedintorni.it/ipv-vendor-debug-test.php

3. Leggi il risultato:

   ✅ "SUCCESS: Authorization header RICEVUTO"
      → L'header arriva! Vai a FASE 2

   ❌ "FAIL: Authorization header NON ARRIVA"
      → L'hosting blocca l'header! Vai a FASE 3


FASE 2: Debug Licenza (se header arriva)
─────────────────────────────────────────

1. Carica "ipv-vendor-test-endpoint.php" in:
   wp-content/plugins/ipv-pro-vendor/

2. Modifica: wp-content/plugins/ipv-pro-vendor/ipv-pro-vendor.php

   Aggiungi PRIMA dell'ultima riga:

   require_once IPV_VENDOR_DIR . 'ipv-vendor-test-endpoint.php';

3. Test endpoint debug:
   https://aiedintorni.it/wp-json/ipv-vendor/v1/test-debug

4. Test con license key reale dal client:

   Nel browser console (F12):

   fetch('https://aiedintorni.it/wp-json/ipv-vendor/v1/test-transcript', {
     method: 'POST',
     headers: {
       'Authorization': 'Bearer TUA_LICENSE_KEY',
       'Content-Type': 'application/json'
     },
     body: JSON.stringify({video_id: 'test', mode: 'auto'})
   }).then(r => r.json()).then(console.log)

5. Leggi risultato:

   "overall_status": "AUTHORIZATION_RECEIVED"
   "license_test": {"result": "SUCCESS"}
   → ✅ Tutto OK!

   "overall_status": "AUTHORIZATION_RECEIVED"
   "license_test": {"result": "ERROR", "error_message": "License not found"}
   → ❌ License key non esiste nel database


FASE 3: Fix .htaccess (se header NON arriva)
─────────────────────────────────────────────

1. Apri: public_html/.htaccess

2. Aggiungi IN CIMA (prima di tutto):

   # BEGIN IPV Authorization Fix
   <IfModule mod_rewrite.c>
   RewriteEngine On
   RewriteCond %{HTTP:Authorization} ^(.*)
   RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]
   </IfModule>
   # END IPV Authorization Fix

3. Salva e riprova FASE 1

═══════════════════════════════════════════════════════════════════════

🔍 TROUBLESHOOTING RAPIDO

❌ Problema: Script debug non si apre
✅ Soluzione: Verifica che il file sia in public_html/ (non in sottocartelle)

❌ Problema: 404 su test endpoint
✅ Soluzione: Verifica che ipv-pro-vendor.php sia modificato correttamente

❌ Problema: Header arriva ma licenza fallisce
✅ Soluzione: Controlla database wp_ipv_licenses (phpMyAdmin)

❌ Problema: Niente funziona
✅ Soluzione: Leggi DEBUG-UNAUTHORIZED-ERROR.md per guida completa

═══════════════════════════════════════════════════════════════════════

⚠️  IMPORTANTE: Pulizia Dopo Debug

Dopo aver risolto, ELIMINA questi file per sicurezza:

1. public_html/ipv-vendor-debug-test.php
2. wp-content/plugins/ipv-pro-vendor/ipv-vendor-test-endpoint.php
3. Rimuovi la riga aggiunta in ipv-pro-vendor.php

═══════════════════════════════════════════════════════════════════════

📚 DOCUMENTAZIONE COMPLETA

Per istruzioni dettagliate, leggi:
→ DEBUG-UNAUTHORIZED-ERROR.md

Include:
- 6 fasi di debug progressive
- Interpretazione risultati
- Query database SQL
- cURL test commands
- Checklist completa
- Cosa inviare al supporto

═══════════════════════════════════════════════════════════════════════

📊 HOSTING COMPATIBILITY

SiteGround     → Richiede .htaccess FIX (Fase 3)
Bluehost       → Richiede .htaccess FIX (Fase 3)
GoDaddy        → Richiede .htaccess FIX (Fase 3)
HostGator      → Richiede .htaccess FIX (Fase 3)
WP Engine      → Usa Nginx (contatta hosting per config)
Kinsta         → Usa Nginx (contatta hosting per config)

═══════════════════════════════════════════════════════════════════════

🆘 SUPPORTO

Se dopo aver seguito TUTTE le fasi continui ad avere problemi:

1. Esegui script debug e copia OUTPUT COMPLETO
2. Esegui test endpoint e copia JSON
3. Copia ultimi 100 righe di wp-content/debug.log
4. Screenshot diagnostica client (IPV Videos → Diagnostica)
5. Invia tutto a: https://github.com/daniemi1977/ipv/issues

═══════════════════════════════════════════════════════════════════════

Versione: 1.0
Data: 9 Dicembre 2024
Compatibile con: Server v1.3.2+ | Client v10.0.8+
