<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<div class="wrap ipv-wrap">
    <div class="ipv-header">
        <h1>📡 Auto-Import RSS</h1>
        <p>Importa automaticamente nuovi video dal tuo canale YouTube</p>
    </div>

    <!-- ℹ️ HELP BOX PRINCIPALE -->
    <div style="background: linear-gradient(135deg, #e0f2fe 0%, #f0f9ff 100%); border: 1px solid #0ea5e9; border-radius: 8px; padding: 16px; margin-bottom: 20px;">
        <div style="display: flex; align-items: flex-start; gap: 12px;">
            <span style="font-size: 24px;">ℹ️</span>
            <div style="flex: 1;">
                <h3 style="margin: 0 0 8px 0; color: #0c4a6e; font-size: 16px;">Come Funziona l'Auto-Import RSS con il Golden Prompt</h3>
                <div style="font-size: 13px; color: #075985; line-height: 1.6;">
                    <p style="margin: 0 0 8px 0;"><strong>🔄 Workflow completo:</strong> RSS importa video → Golden Prompt genera descrizioni AI personalizzate → Video pubblicati automaticamente</p>
                    <details style="margin-top: 8px;">
                        <summary style="cursor: pointer; font-weight: bold; color: #0369a1;">📖 Guida completa per recuperare il Channel ID...</summary>
                        <div style="margin-top: 8px; padding: 12px; background: white; border-radius: 4px; border: 1px solid #7dd3fc;">
                            <p style="margin: 0 0 10px 0; font-weight: bold; color: #0c4a6e;">🔍 Metodo 1: Dalla pagina del canale</p>
                            <ol style="margin: 0 0 12px 0; padding-left: 20px;">
                                <li>Vai sul tuo canale YouTube</li>
                                <li>Clicca con tasto destro → "Visualizza sorgente pagina"</li>
                                <li>Cerca "channelId" (Ctrl+F): troverai <code>"channelId":"UCxxxxxxxxxx"</code></li>
                            </ol>

                            <p style="margin: 0 0 10px 0; font-weight: bold; color: #0c4a6e;">🔍 Metodo 2: Dalle impostazioni YouTube</p>
                            <ol style="margin: 0 0 12px 0; padding-left: 20px;">
                                <li>Vai su YouTube Studio (studio.youtube.com)</li>
                                <li>Impostazioni → Canale → Impostazioni avanzate</li>
                                <li>Troverai "ID canale" (inizia con "UC")</li>
                            </ol>

                            <p style="margin: 0 0 10px 0; font-weight: bold; color: #0c4a6e;">🔍 Metodo 3: Dall'URL del canale</p>
                            <ol style="margin: 0 0 12px 0; padding-left: 20px;">
                                <li>Se l'URL è: youtube.com/channel/<strong>UCxxxxxxxxxx</strong></li>
                                <li>Il Channel ID è la parte dopo /channel/</li>
                            </ol>

                            <p style="margin: 0 0 8px 0; font-weight: bold; color: #0c4a6e;">📝 Costruisci l'URL del Feed:</p>
                            <code style="display: block; padding: 8px; background: #f0f9ff; border-radius: 4px; font-size: 12px;">https://www.youtube.com/feeds/videos.xml?channel_id=<strong style="color: #0ea5e9;">TUO_CHANNEL_ID</strong></code>

                            <div style="margin-top: 12px; padding: 10px; background: #fef3c7; border-radius: 4px; border: 1px solid #fbbf24;">
                                <p style="margin: 0; font-size: 12px; color: #92400e;"><strong>⚠️ Importante:</strong> Il Channel ID inizia sempre con "UC" ed è lungo 24 caratteri. Non confonderlo con l'handle (@canale)!</p>
                            </div>
                        </div>
                    </details>
                    <details style="margin-top: 8px;">
                        <summary style="cursor: pointer; font-weight: bold; color: #0369a1;">🤖 Come si collega al Golden Prompt...</summary>
                        <div style="margin-top: 8px; padding: 12px; background: white; border-radius: 4px; border: 1px solid #7dd3fc;">
                            <p style="margin: 0 0 8px 0;">Quando un video viene importato via RSS:</p>
                            <ol style="margin: 0 0 8px 0; padding-left: 20px;">
                                <li><strong>RSS importa</strong> il video con titolo e metadati base</li>
                                <li><strong>Il sistema recupera</strong> la trascrizione dal video</li>
                                <li><strong>Il Golden Prompt</strong> viene caricato dal server (con i tuoi dati personali)</li>
                                <li><strong>L'AI genera</strong> descrizione, titolo SEO, hashtag usando il tuo template personalizzato</li>
                            </ol>
                            <p style="margin: 0; font-size: 12px; color: #666;"><strong>💡 Tip:</strong> Assicurati di aver configurato il Golden Prompt nella pagina "AI & Prompt" prima di attivare l'auto-import!</p>
                        </div>
                    </details>
                </div>
            </div>
        </div>
    </div>

    <?php if ( isset( $test_result ) ) : ?>
        <div class="ipv-notice ipv-notice-<?php echo $test_result['success'] ? 'success' : 'danger'; ?>">
            <strong>Test Feed:</strong> <?php echo esc_html( $test_result['message'] ); ?>
            <?php if ( $test_result['success'] ) : ?>
                <br><small>Trovati <?php echo intval( $test_result['video_count'] ); ?> video nel feed</small>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if ( isset( $import_result ) ) : ?>
        <div class="ipv-notice ipv-notice-success">
            <strong><?php echo esc_html( $import_result['message'] ); ?></strong>
        </div>
    <?php endif; ?>

    <div class="ipv-row">
        <div class="ipv-col-8">
            <div class="ipv-card ipv-card-primary">
                <div class="ipv-card-header">
                    <h3>⚙️ Configurazione Feed RSS</h3>
                </div>
                <div class="ipv-card-body">
                    <form method="post" action="">
                        <?php wp_nonce_field( 'ipv_rss_settings_save' ); ?>
                        <input type="hidden" name="ipv_save_rss_settings" value="1" />

                        <div class="ipv-form-group">
                            <label class="ipv-flex ipv-items-center ipv-gap-1">
                                <input type="checkbox" name="ipv_rss_enabled" id="ipv_rss_enabled" value="1" <?php checked( $rss_enabled, true ); ?> />
                                <strong>Abilita Auto-Import RSS</strong>
                            </label>
                            <p class="ipv-form-hint">Quando attivo, il sistema controlla automaticamente il feed e importa nuovi video</p>
                        </div>

                        <div class="ipv-form-group">
                            <label class="ipv-form-label">URL Feed RSS YouTube <span class="ipv-text-danger">*</span></label>
                            <input type="url" class="ipv-form-input" name="ipv_rss_feed_url" value="<?php echo esc_attr( $feed_url ); ?>" placeholder="https://www.youtube.com/feeds/videos.xml?channel_id=UC..." required />
                            <p class="ipv-form-hint">Formato: <code>https://www.youtube.com/feeds/videos.xml?channel_id=TUO_CHANNEL_ID</code></p>
                        </div>

                        <div class="ipv-form-group">
                            <label class="ipv-form-label">Frequenza Controllo</label>
                            <select name="ipv_rss_schedule" class="ipv-form-select">
                                <option value="every_30_minutes" <?php selected( $rss_schedule, 'every_30_minutes' ); ?>>Ogni 30 minuti (più frequente)</option>
                                <option value="hourly" <?php selected( $rss_schedule, 'hourly' ); ?>>Ogni ora (consigliato)</option>
                                <option value="every_6_hours" <?php selected( $rss_schedule, 'every_6_hours' ); ?>>Ogni 6 ore</option>
                                <option value="twicedaily" <?php selected( $rss_schedule, 'twicedaily' ); ?>>Due volte al giorno</option>
                                <option value="daily" <?php selected( $rss_schedule, 'daily' ); ?>>Una volta al giorno</option>
                            </select>
                            <p class="ipv-form-hint">Quanto spesso controllare il feed per nuovi video</p>
                        </div>

                        <div class="ipv-form-group">
                            <label class="ipv-form-label">Limite Video per Controllo</label>
                            <input type="number" class="ipv-form-input" name="ipv_rss_import_limit" value="<?php echo intval( $import_limit ); ?>" min="1" max="50" />
                            <p class="ipv-form-hint">Numero massimo di video da importare ad ogni controllo (consigliato: 10)</p>
                        </div>

                        <button type="submit" class="ipv-btn ipv-btn-primary">💾 Salva Configurazione</button>
                    </form>
                </div>
            </div>

            <div class="ipv-card ipv-mt-3">
                <div class="ipv-card-header">
                    <h3>🧪 Test & Importazione Manuale</h3>
                </div>
                <div class="ipv-card-body">
                    <div class="ipv-flex ipv-gap-2 ipv-flex-wrap">
                        <form method="post" action="" style="display: inline;">
                            <?php wp_nonce_field( 'ipv_rss_test_feed' ); ?>
                            <input type="hidden" name="ipv_test_feed" value="1" />
                            <button type="submit" class="ipv-btn ipv-btn-secondary">🔍 Testa Feed</button>
                        </form>
                        <form method="post" action="" style="display: inline;">
                            <?php wp_nonce_field( 'ipv_rss_import_now' ); ?>
                            <input type="hidden" name="ipv_import_now" value="1" />
                            <button type="submit" class="ipv-btn ipv-btn-success">▶️ Importa Ora</button>
                        </form>
                    </div>
                    <p class="ipv-form-hint ipv-mt-1"><strong>Testa Feed:</strong> Verifica che il feed sia valido | <strong>Importa Ora:</strong> Forza l'importazione immediata</p>
                </div>
            </div>
        </div>

        <div class="ipv-col-4">
            <div class="ipv-card ipv-card-success">
                <div class="ipv-card-header">
                    <h3>📊 Statistiche RSS</h3>
                </div>
                <div class="ipv-card-body">
                    <div class="ipv-flex ipv-justify-between ipv-items-center ipv-mb-2">
                        <span class="ipv-text-muted">Stato</span>
                        <span class="ipv-badge <?php echo $rss_enabled ? 'ipv-badge-success' : 'ipv-badge-muted'; ?>"><?php echo $rss_enabled ? '✓ Attivo' : '○ Disattivo'; ?></span>
                    </div>
                    <div class="ipv-flex ipv-justify-between ipv-items-center ipv-mb-2">
                        <span class="ipv-text-muted">Ultimo Controllo</span>
                        <strong><?php echo $stats['last_check'] === 'Mai' ? 'Mai' : esc_html( mysql2date( 'd/m/Y H:i', $stats['last_check'] ) ); ?></strong>
                    </div>
                    <div class="ipv-flex ipv-justify-between ipv-items-center ipv-mb-2">
                        <span class="ipv-text-muted">Video Importati</span>
                        <span class="ipv-badge ipv-badge-info"><?php echo intval( $stats['total_imported'] ); ?></span>
                    </div>
                    <div class="ipv-flex ipv-justify-between ipv-items-center ipv-mb-2">
                        <span class="ipv-text-muted">Video Saltati</span>
                        <span class="ipv-badge ipv-badge-warning"><?php echo intval( $stats['total_skipped'] ); ?></span>
                    </div>
                    <?php if ( $next_run ) : ?>
                    <div class="ipv-flex ipv-justify-between ipv-items-center">
                        <span class="ipv-text-muted">Prossimo Controllo</span>
                        <strong><?php echo esc_html( human_time_diff( $next_run ) ); ?></strong>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="ipv-card ipv-card-info ipv-mt-3">
                <div class="ipv-card-header">
                    <h3>❓ Come Funziona</h3>
                </div>
                <div class="ipv-card-body">
                    <div class="ipv-steps">
                        <div class="ipv-step">
                            <div class="ipv-step-number">1</div>
                            <div class="ipv-step-content">
                                <h4>Monitoraggio Automatico</h4>
                                <p>Il sistema controlla il feed RSS alla frequenza impostata</p>
                            </div>
                        </div>
                        <div class="ipv-step">
                            <div class="ipv-step-number">2</div>
                            <div class="ipv-step-content">
                                <h4>Rilevamento Nuovi Video</h4>
                                <p>Identifica automaticamente i video non ancora importati</p>
                            </div>
                        </div>
                        <div class="ipv-step">
                            <div class="ipv-step-number">3</div>
                            <div class="ipv-step-content">
                                <h4>Importazione Automatica</h4>
                                <p>Aggiunge i nuovi video alla coda per il processamento</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ipv-card ipv-mt-3">
                <div class="ipv-card-header">
                    <h3>ℹ️ Come Trovare il Feed</h3>
                </div>
                <div class="ipv-card-body">
                    <p class="ipv-mb-2"><strong>1. Trova il tuo Channel ID:</strong></p>
                    <p class="ipv-text-muted ipv-mb-2" style="font-size: 13px;">Vai su YouTube → Il tuo canale → L'URL contiene il Channel ID (inizia con "UC", 24 caratteri).</p>
                    <p class="ipv-mb-2"><strong>2. Costruisci il feed URL:</strong></p>
                    <code style="display: block; font-size: 12px; word-break: break-all; padding: 10px; background: var(--ipv-bg); border-radius: 4px;">https://www.youtube.com/feeds/videos.xml?channel_id=<span class="ipv-text-primary">TUO_CHANNEL_ID</span></code>
                    <p class="ipv-mt-2 ipv-text-muted" style="font-size: 12px;">💡 Puoi anche trovare il Channel ID nelle impostazioni avanzate del tuo canale YouTube.</p>
                </div>
            </div>
        </div>
    </div>
</div>
