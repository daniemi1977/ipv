<?php
/**
 * IPV Golden Prompt Client Receiver
 *
 * Riceve il Golden Prompt dal server vendor e lo memorizza in modo sicuro.
 * IL GOLDEN PROMPT NON È VISIBILE ALL'UTENTE FINALE.
 *
 * PRIORITÀ GOLDEN PROMPT:
 * 1. Vendor (ricevuto via API) - HA PRIORITÀ
 * 2. Locale (configurato manualmente dall'utente)
 * 3. Fallback (prompt base hardcoded)
 *
 * @package IPV_Production_System_Pro
 * @since 10.5.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class IPV_Pro_Golden_Prompt_Client {

    private static $instance = null;
    private $vendor_url;
    private $license_key;

    /**
     * Option keys per memorizzare il Golden Prompt (offuscato)
     */
    const OPTION_KEY = '_ipv_gp_data_enc';
    const HASH_KEY = '_ipv_gp_hash';
    const UPDATED_KEY = '_ipv_gp_updated';
    const LAST_SYNC_KEY = '_ipv_gp_last_sync';
    const SYNC_STATUS_KEY = '_ipv_gp_sync_status';

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        $this->vendor_url = defined( 'IPV_VENDOR_URL' ) ? IPV_VENDOR_URL : 'https://aiedintorni.it';
        $this->license_key = get_option( 'ipv_pro_license_key', '' );

        // Hook per sync automatico
        add_action( 'ipv_pro_license_activated', [ $this, 'sync_golden_prompt' ] );
        add_action( 'ipv_pro_daily_cron', [ $this, 'check_and_sync' ] );
        
        // REST endpoint per ricevere push dal vendor
        add_action( 'rest_api_init', [ $this, 'register_sync_endpoint' ] );

        // Admin AJAX per sync manuale
        add_action( 'wp_ajax_ipv_sync_vendor_golden_prompt', [ $this, 'ajax_sync_golden_prompt' ] );
        add_action( 'wp_ajax_ipv_check_vendor_golden_prompt', [ $this, 'ajax_check_status' ] );

        // Cron per sync periodico
        add_action( 'init', [ $this, 'schedule_sync_cron' ] );
        add_action( 'ipv_golden_prompt_sync_cron', [ $this, 'check_and_sync' ] );
    }

    /**
     * Schedule cron per sync periodico
     */
    public function schedule_sync_cron() {
        if ( ! wp_next_scheduled( 'ipv_golden_prompt_sync_cron' ) ) {
            wp_schedule_event( time(), 'twicedaily', 'ipv_golden_prompt_sync_cron' );
        }
    }

    /**
     * Register REST endpoint per ricevere push dal vendor
     */
    public function register_sync_endpoint() {
        register_rest_route( 'ipv-pro/v1', '/golden-prompt/sync', [
            'methods' => 'POST',
            'callback' => [ $this, 'receive_push' ],
            'permission_callback' => [ $this, 'verify_push_request' ],
        ]);

        register_rest_route( 'ipv-pro/v1', '/golden-prompt/status', [
            'methods' => 'GET',
            'callback' => [ $this, 'get_status' ],
            'permission_callback' => [ $this, 'verify_push_request' ],
        ]);
    }

    /**
     * Verify push request from vendor
     */
    public function verify_push_request( $request ) {
        $license_key = $request->get_header( 'X-License-Key' );
        
        if ( empty( $license_key ) ) {
            return new WP_Error( 'unauthorized', 'License key mancante', [ 'status' => 401 ] );
        }

        // Verifica che la license key corrisponda
        $local_key = get_option( 'ipv_pro_license_key', '' );
        
        if ( $license_key !== $local_key ) {
            return new WP_Error( 'unauthorized', 'License key non valida', [ 'status' => 401 ] );
        }

        return true;
    }

    /**
     * Receive push from vendor
     */
    public function receive_push( $request ) {
        $data = $request->get_json_params();

        if ( empty( $data['golden_prompt'] ) ) {
            return new WP_REST_Response( [
                'success' => false,
                'message' => 'Golden Prompt mancante'
            ], 400 );
        }

        // Salva il Golden Prompt
        $this->store_golden_prompt( $data['golden_prompt'], $data['updated_at'] ?? null );

        // Log
        if ( class_exists( 'IPV_Prod_Logger' ) ) {
            IPV_Prod_Logger::log( 'Golden Prompt ricevuto via push dal vendor' );
        }

        return new WP_REST_Response( [
            'success' => true,
            'message' => 'Golden Prompt sincronizzato',
            'hash' => md5( $data['golden_prompt'] )
        ], 200 );
    }

    /**
     * GET status endpoint
     */
    public function get_status( $request ) {
        return new WP_REST_Response( [
            'has_golden_prompt' => $this->has_golden_prompt(),
            'hash' => get_option( self::HASH_KEY, null ),
            'updated_at' => get_option( self::UPDATED_KEY, null ),
            'last_sync' => get_option( self::LAST_SYNC_KEY, null )
        ], 200 );
    }

    /**
     * Sincronizza il Golden Prompt dal vendor
     */
    public function sync_golden_prompt() {
        $this->license_key = get_option( 'ipv_pro_license_key', '' );
        
        if ( empty( $this->license_key ) ) {
            update_option( self::SYNC_STATUS_KEY, 'no_license' );
            return false;
        }

        update_option( self::SYNC_STATUS_KEY, 'syncing' );

        $response = wp_remote_get( trailingslashit( $this->vendor_url ) . 'wp-json/ipv-vendor/v1/golden-prompt', [
            'timeout' => 30,
            'headers' => [
                'X-License-Key' => $this->license_key
            ]
        ]);

        update_option( self::LAST_SYNC_KEY, current_time( 'mysql' ) );

        if ( is_wp_error( $response ) ) {
            update_option( self::SYNC_STATUS_KEY, 'error: ' . $response->get_error_message() );
            
            if ( class_exists( 'IPV_Prod_Logger' ) ) {
                IPV_Prod_Logger::log( 'Golden Prompt sync error: ' . $response->get_error_message() );
            }
            return false;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code !== 200 ) {
            update_option( self::SYNC_STATUS_KEY, 'error: HTTP ' . $code );
            return false;
        }

        if ( ! $body['success'] || ! $body['has_golden_prompt'] ) {
            // Nessun Golden Prompt configurato sul vendor
            update_option( self::SYNC_STATUS_KEY, 'no_prompt_configured' );
            return false;
        }

        // Salva il Golden Prompt
        $this->store_golden_prompt( $body['golden_prompt'], $body['updated_at'] );
        update_option( self::SYNC_STATUS_KEY, 'synced' );

        if ( class_exists( 'IPV_Prod_Logger' ) ) {
            IPV_Prod_Logger::log( 'Golden Prompt sincronizzato con successo dal vendor' );
        }

        return true;
    }

    /**
     * Check and sync if needed
     */
    public function check_and_sync() {
        $this->license_key = get_option( 'ipv_pro_license_key', '' );
        
        if ( empty( $this->license_key ) ) {
            return;
        }

        // Controlla l'hash remoto
        $response = wp_remote_get( trailingslashit( $this->vendor_url ) . 'wp-json/ipv-vendor/v1/golden-prompt/hash', [
            'timeout' => 15,
            'headers' => [
                'X-License-Key' => $this->license_key
            ]
        ]);

        if ( is_wp_error( $response ) ) {
            return;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        $remote_hash = $body['hash'] ?? null;
        $local_hash = get_option( self::HASH_KEY, '' );

        // Se l'hash è diverso, sincronizza
        if ( $remote_hash && $remote_hash !== $local_hash ) {
            $this->sync_golden_prompt();
        }
    }

    /**
     * Get encryption key (site-specific)
     * Uses SECURE_AUTH_KEY + site URL hash for uniqueness
     */
    private function get_encryption_key() {
        $base = defined( 'SECURE_AUTH_KEY' ) ? SECURE_AUTH_KEY : 'ipv-default-key-change-me';
        return hash( 'sha256', $base . get_site_url(), true );
    }

    /**
     * Memorizza il Golden Prompt in modo sicuro (AES-256-CBC encryption)
     * SECURITY: Real encryption, not just obfuscation
     */
    private function store_golden_prompt( $prompt, $updated_at = null ) {
        $key = $this->get_encryption_key();
        $iv = openssl_random_pseudo_bytes( 16 );

        // AES-256-CBC encryption
        $encrypted = openssl_encrypt( $prompt, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );

        if ( $encrypted === false ) {
            // Fallback to legacy encoding if OpenSSL fails
            $encoded = base64_encode( strrev( $prompt ) );
            update_option( self::OPTION_KEY, 'legacy:' . $encoded, false );
        } else {
            // Store IV + encrypted data (base64 encoded)
            $encoded = base64_encode( $iv . $encrypted );
            update_option( self::OPTION_KEY, 'aes256:' . $encoded, false );
        }

        update_option( self::HASH_KEY, hash( 'sha256', $prompt ), false );
        update_option( self::UPDATED_KEY, $updated_at ?: current_time( 'mysql' ), false );
    }

    /**
     * Ottieni il Golden Prompt decodificato (uso INTERNO)
     * Questa funzione NON deve essere esposta all'utente
     * SECURITY: Supports both AES-256 and legacy decryption
     */
    public function get_golden_prompt() {
        $stored = get_option( self::OPTION_KEY, '' );

        if ( empty( $stored ) ) {
            return null;
        }

        // Check encryption type
        if ( strpos( $stored, 'aes256:' ) === 0 ) {
            // AES-256-CBC decryption
            $encoded = substr( $stored, 7 );
            $data = base64_decode( $encoded );

            if ( strlen( $data ) < 17 ) {
                return null;
            }

            $iv = substr( $data, 0, 16 );
            $encrypted = substr( $data, 16 );
            $key = $this->get_encryption_key();

            $decrypted = openssl_decrypt( $encrypted, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );

            return $decrypted !== false ? $decrypted : null;

        } elseif ( strpos( $stored, 'legacy:' ) === 0 ) {
            // Legacy decryption (base64 + reverse)
            $encoded = substr( $stored, 7 );
            return strrev( base64_decode( $encoded ) );

        } else {
            // Very old format (plain base64 + reverse, no prefix)
            return strrev( base64_decode( $stored ) );
        }
    }

    /**
     * Verifica se esiste un Golden Prompt dal vendor
     */
    public function has_golden_prompt() {
        return ! empty( get_option( self::OPTION_KEY, '' ) );
    }

    /**
     * Ottieni la data ultimo aggiornamento
     */
    public function get_last_updated() {
        return get_option( self::UPDATED_KEY, null );
    }

    /**
     * Ottieni lo status del sync
     */
    public function get_sync_status() {
        return get_option( self::SYNC_STATUS_KEY, 'never_synced' );
    }

    /**
     * Ottieni la data ultimo sync
     */
    public function get_last_sync() {
        return get_option( self::LAST_SYNC_KEY, null );
    }

    /**
     * AJAX: Sync manuale
     */
    public function ajax_sync_golden_prompt() {
        check_ajax_referer( 'ipv_golden_prompt_sync', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Permessi insufficienti' );
        }

        $result = $this->sync_golden_prompt();

        if ( $result ) {
            wp_send_json_success( [
                'message' => 'Golden Prompt sincronizzato con successo!',
                'updated_at' => $this->get_last_updated(),
                'has_prompt' => true
            ] );
        } else {
            $status = $this->get_sync_status();
            
            if ( $status === 'no_prompt_configured' ) {
                wp_send_json_error( 'Nessun Golden Prompt configurato per questa licenza sul server.' );
            } elseif ( $status === 'no_license' ) {
                wp_send_json_error( 'Licenza non attiva. Attiva prima la licenza.' );
            } else {
                wp_send_json_error( 'Errore durante la sincronizzazione: ' . $status );
            }
        }
    }

    /**
     * AJAX: Check status
     */
    public function ajax_check_status() {
        check_ajax_referer( 'ipv_golden_prompt_sync', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Permessi insufficienti' );
        }

        wp_send_json_success( [
            'has_vendor_prompt' => $this->has_golden_prompt(),
            'updated_at' => $this->get_last_updated(),
            'last_sync' => $this->get_last_sync(),
            'sync_status' => $this->get_sync_status()
        ] );
    }

    /**
     * Cancella il Golden Prompt locale
     */
    public function clear_local() {
        delete_option( self::OPTION_KEY );
        delete_option( self::HASH_KEY );
        delete_option( self::UPDATED_KEY );
        delete_option( self::LAST_SYNC_KEY );
        delete_option( self::SYNC_STATUS_KEY );
    }

    /**
     * Render info box per la pagina Golden Prompt
     */
    public static function render_vendor_status_box() {
        $client = self::instance();
        $has_vendor = $client->has_golden_prompt();
        $updated_at = $client->get_last_updated();
        $last_sync = $client->get_last_sync();
        $sync_status = $client->get_sync_status();

        ?>
        <div class="ipv-vendor-gp-status" style="background: <?php echo $has_vendor ? '#d4edda' : '#fff3cd'; ?>; border: 1px solid <?php echo $has_vendor ? '#c3e6cb' : '#ffeeba'; ?>; border-radius: 8px; padding: 20px; margin-bottom: 20px;">
            <h3 style="margin-top: 0; color: <?php echo $has_vendor ? '#155724' : '#856404'; ?>;">
                <?php echo $has_vendor ? '✅ Golden Prompt dal Vendor Attivo' : '⚠️ Nessun Golden Prompt dal Vendor'; ?>
            </h3>
            
            <?php if ( $has_vendor ) : ?>
                <p style="color: #155724; margin: 10px 0;">
                    <strong>Il tuo canale ha un Golden Prompt personalizzato configurato dal vendor.</strong><br>
                    Questo prompt ha la priorità su quello locale e verrà usato per tutte le generazioni AI.
                </p>
                <p style="color: #666; font-size: 13px;">
                    <strong>Ultimo aggiornamento:</strong> <?php echo $updated_at ? date_i18n( 'd/m/Y H:i', strtotime( $updated_at ) ) : 'N/A'; ?><br>
                    <strong>Ultimo sync:</strong> <?php echo $last_sync ? date_i18n( 'd/m/Y H:i', strtotime( $last_sync ) ) : 'Mai'; ?>
                </p>
            <?php else : ?>
                <p style="color: #856404; margin: 10px 0;">
                    Il vendor non ha ancora configurato un Golden Prompt per la tua licenza.<br>
                    Verrà utilizzato il prompt locale configurato qui sotto.
                </p>
                <?php if ( $sync_status && $sync_status !== 'never_synced' ) : ?>
                    <p style="color: #666; font-size: 13px;">
                        <strong>Stato sync:</strong> <?php echo esc_html( $sync_status ); ?><br>
                        <strong>Ultimo tentativo:</strong> <?php echo $last_sync ? date_i18n( 'd/m/Y H:i', strtotime( $last_sync ) ) : 'Mai'; ?>
                    </p>
                <?php endif; ?>
            <?php endif; ?>

            <div style="margin-top: 15px;">
                <button type="button" class="button button-secondary" id="ipv-sync-vendor-gp">
                    🔄 Sincronizza dal Vendor
                </button>
                <span id="ipv-sync-status" style="margin-left: 10px; display: none;"></span>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            $('#ipv-sync-vendor-gp').on('click', function() {
                var $btn = $(this);
                var $status = $('#ipv-sync-status');
                
                $btn.prop('disabled', true).text('🔄 Sincronizzando...');
                $status.hide();

                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'ipv_sync_vendor_golden_prompt',
                        nonce: '<?php echo wp_create_nonce( 'ipv_golden_prompt_sync' ); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            $status.html('<span style="color: #155724;">✅ ' + response.data.message + '</span>').show();
                            setTimeout(function() {
                                location.reload();
                            }, 1500);
                        } else {
                            $status.html('<span style="color: #721c24;">❌ ' + response.data + '</span>').show();
                        }
                    },
                    error: function() {
                        $status.html('<span style="color: #721c24;">❌ Errore di connessione</span>').show();
                    },
                    complete: function() {
                        $btn.prop('disabled', false).text('🔄 Sincronizza dal Vendor');
                    }
                });
            });
        });
        </script>
        <?php
    }
}

/**
 * Helper function per ottenere il Golden Prompt
 * Da usare SOLO internamente nel codice del plugin
 */
function ipv_get_golden_prompt() {
    return IPV_Pro_Golden_Prompt_Client::instance()->get_golden_prompt();
}

/**
 * Helper function per verificare se esiste un Golden Prompt dal vendor
 */
function ipv_has_golden_prompt() {
    return IPV_Pro_Golden_Prompt_Client::instance()->has_golden_prompt();
}

/**
 * Helper per ottenere lo status del sync
 */
function ipv_get_golden_prompt_sync_status() {
    return IPV_Pro_Golden_Prompt_Client::instance()->get_sync_status();
}
