<?php
/**
 * Plugin Name: LC Schede Tecniche – Grid + Filtri (Touch)
 * Description: Griglia filtrabile per il CPT "scheda tecnica" con filtri AJAX, sincronizzazione automatica meta JetEngine → tassonomie, frase motivazionale del giorno, meniny/sviatky slovacchi da tabella locale e shortcode per tassonomie nel single template.
 * Version:     1.5.0
 * Author:      LC
 * 
 * CHANGELOG v1.5.0:
 * - NUOVO: Sincronizzazione automatica meta field JetEngine → tassonomie
 * - NUOVO: Tool "Sincronizza tutte le schede" per aggiornare schede esistenti
 * - NUOVO: Sezione diagnosi per verificare lo stato di sincronizzazione
 * - FIX: I filtri ora funzionano correttamente con i campi select di JetEngine
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'LC_STF_VERSION', '1.5.0' );
define( 'LC_STF_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'LC_STF_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once LC_STF_PLUGIN_DIR . 'includes/class-lc-schede-tecniche-filters.php';

function lc_stf_instance() {
    static $instance = null;
    if ( null === $instance ) {
        $instance = new LC_Schede_Tecniche_Filters();
    }
    return $instance;
}
add_action( 'plugins_loaded', 'lc_stf_instance' );

add_action( 'init', function() {
    $instance = lc_stf_instance();

    // Main shortcodes
    add_shortcode( 'lc_schede_tecniche_grid', array( $instance, 'render_shortcode' ) );
    add_shortcode( 'lc_daily_quote', array( $instance, 'render_daily_quote_shortcode' ) );
    add_shortcode( 'lc_nameday_local', array( $instance, 'render_nameday_local_shortcode' ) );

    // ALIAS shortcodes (per compatibilità)
    add_shortcode( 'lc_schede_tecniche', array( $instance, 'render_shortcode' ) );
    add_shortcode( 'lc_frase_del_giorno', array( $instance, 'render_daily_quote_shortcode' ) );
    add_shortcode( 'lc_meniny_dnes', array( $instance, 'render_nameday_local_shortcode' ) );

    // Shortcode single template (tassonomie)
    add_shortcode( 'lc_scheda_cliente', array( $instance, 'sc_cliente_shortcode' ) );
    add_shortcode( 'lc_scheda_tipologia', array( $instance, 'sc_tipologia_shortcode' ) );
    add_shortcode( 'lc_tax_terms', array( $instance, 'sc_tax_terms_shortcode' ) );
    add_shortcode( 'lc_scheda_meta', array( $instance, 'sc_scheda_meta_shortcode' ) );
} );

add_action( 'wp_enqueue_scripts', function() {
    wp_enqueue_style(
        'lc-stf-frontend',
        LC_STF_PLUGIN_URL . 'assets/css/frontend.css',
        array(),
        LC_STF_VERSION
    );
    
    wp_enqueue_script(
        'lc-stf-ajax',
        LC_STF_PLUGIN_URL . 'assets/js/ajax-filters.js',
        array( 'jquery' ),
        LC_STF_VERSION,
        true
    );
    
    wp_localize_script( 'lc-stf-ajax', 'lc_stf_ajax', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'lc_stf_filter_nonce' ),
    ) );
} );

// AJAX handlers
add_action( 'wp_ajax_lc_stf_filter', 'lc_stf_ajax_filter' );
add_action( 'wp_ajax_nopriv_lc_stf_filter', 'lc_stf_ajax_filter' );

function lc_stf_ajax_filter() {
    check_ajax_referer( 'lc_stf_filter_nonce', 'nonce' );
    
    $instance = lc_stf_instance();
    $html = $instance->render_grid_only( $_POST );
    
    wp_send_json_success( array( 'html' => $html ) );
}
