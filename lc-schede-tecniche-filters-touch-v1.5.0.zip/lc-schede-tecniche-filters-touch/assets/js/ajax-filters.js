/**
 * LC Schede Tecniche - AJAX Filters
 * Version: 1.4.0
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        
        var $wrapper = $('.lc-stf-wrapper');
        var $grid = $wrapper.find('.lc-stf-grid');
        var $loading = $wrapper.find('.lc-stf-loading');
        var $applyBtn = $('#lc-stf-apply-filters');
        var $resetBtn = $('#lc-stf-reset-filters');
        var $selects = $wrapper.find('.lc-stf-filter-select');

        /**
         * Get all filter values
         */
        function getFilters() {
            var filters = {};
            $selects.each(function() {
                var name = $(this).attr('name');
                var value = $(this).val();
                if (name) {
                    filters[name] = value;
                }
            });
            return filters;
        }

        /**
         * Apply filters via AJAX
         */
        function applyFilters() {
            var filters = getFilters();
            
            // Show loading
            $loading.show();
            $grid.css('opacity', '0.5');

            $.ajax({
                url: lc_stf_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'lc_stf_filter',
                    nonce: lc_stf_ajax.nonce,
                    ...filters
                },
                success: function(response) {
                    if (response.success) {
                        $grid.html(response.data.html);
                    }
                },
                error: function() {
                    console.error('LC STF: Filter AJAX error');
                },
                complete: function() {
                    $loading.hide();
                    $grid.css('opacity', '1');
                }
            });
        }

        /**
         * Reset all filters
         */
        function resetFilters() {
            $selects.each(function() {
                $(this).val('');
            });
            applyFilters();
        }

        // Event: Apply button click
        $applyBtn.on('click', function(e) {
            e.preventDefault();
            applyFilters();
        });

        // Event: Reset button click
        $resetBtn.on('click', function(e) {
            e.preventDefault();
            resetFilters();
        });

        // Event: Enter key on select
        $selects.on('keypress', function(e) {
            if (e.which === 13) {
                e.preventDefault();
                applyFilters();
            }
        });

    });

})(jQuery);
