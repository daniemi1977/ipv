<?php
/**
 * IPV Pro Vendor - Migration Script: Product Descriptions
 *
 * Aggiorna le descrizioni dei prodotti esistenti da HTML a plain text
 * per risolvere il problema del testo bianco su sfondo bianco
 *
 * ISTRUZIONI:
 * 1. Carica questo file nella root del plugin
 * 2. Accedi a: wp-admin/admin.php?page=ipv-migrate-descriptions
 * 3. Clicca "Aggiorna Descrizioni"
 * 4. Elimina questo file dopo l'uso
 *
 * @package IPV_Pro_Vendor
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class IPV_Vendor_Migrate_Descriptions {

    public static function init() {
        add_action( 'admin_menu', [ __CLASS__, 'add_menu_page' ] );
        add_action( 'admin_post_ipv_migrate_descriptions', [ __CLASS__, 'handle_migration' ] );
    }

    public static function add_menu_page() {
        add_submenu_page(
            'ipv-vendor-wizard',
            'Migrazione Descrizioni',
            '🔄 Migra Descrizioni',
            'manage_options',
            'ipv-migrate-descriptions',
            [ __CLASS__, 'render_page' ]
        );
    }

    /**
     * Get plain text descriptions for each variant
     */
    private static function get_descriptions( $variant, $is_yearly = false ) {
        $descriptions = [
            'trial' => [
                'short' => 'Piano di prova con 10 crediti mensili.',
                'long' => "Piano di prova per testare IPV Production System Pro.\n\n" .
                         "✓ 10 crediti mensili\n" .
                         "✓ Accesso completo a tutte le funzionalità\n" .
                         "✓ Costo simbolico di €1.99 (misura anti-spam)\n\n" .
                         "Perfetto per testare il sistema prima di scegliere un piano superiore."
            ],
            'starter' => [
                'short' => 'Piano Starter con 25 crediti mensili. Ideale per blogger e piccoli siti.',
                'long' => "Piano Starter - La soluzione ideale per blogger e piccoli siti.\n\n" .
                         "✓ 25 crediti mensili\n" .
                         "✓ Trascrizioni video illimitate\n" .
                         "✓ Descrizioni AI automatiche\n\n" .
                         ( $is_yearly
                             ? "Prezzo: €199.50/anno\nRisparmio: €39.90 (paghi 10 mesi, ricevi 12 mesi)"
                             : "Prezzo: €19.95/mese" )
            ],
            'professional' => [
                'short' => 'Piano Professional con 100 crediti mensili. Ideale per creator professionisti.',
                'long' => "Piano Professional - La soluzione ideale per creator professionisti.\n\n" .
                         "✓ 100 crediti mensili\n" .
                         "✓ Trascrizioni video illimitate\n" .
                         "✓ Descrizioni AI automatiche\n" .
                         "✓ Analytics avanzate\n\n" .
                         ( $is_yearly
                             ? "Prezzo: €495.00/anno\nRisparmio: €99.00 (paghi 10 mesi, ricevi 12 mesi)"
                             : "Prezzo: €49.95/mese" )
            ],
            'business' => [
                'short' => 'Piano Business con 300 crediti mensili. Ideale per agenzie e grandi aziende.',
                'long' => "Piano Business - La soluzione ideale per agenzie e grandi aziende.\n\n" .
                         "✓ 300 crediti mensili\n" .
                         "✓ Trascrizioni video illimitate\n" .
                         "✓ Descrizioni AI automatiche\n" .
                         "✓ Analytics avanzate\n" .
                         "✓ White label\n" .
                         "✓ Supporto dedicato 24/7\n\n" .
                         ( $is_yearly
                             ? "Prezzo: €1495.00/anno\nRisparmio: €299.00 (paghi 10 mesi, ricevi 12 mesi)"
                             : "Prezzo: €149.95/mese" )
            ],
            'extra_credits' => [
                'short' => 'Acquista crediti extra per IPV Production System Pro.',
                'long' => "Crediti extra per estendere il tuo piano.\n\n" .
                         "✓ Prezzo: €0.35 per credito\n" .
                         "✓ Minimo 10 crediti per ordine\n" .
                         "✓ I crediti extra NON scadono mai\n" .
                         "✓ Si sommano ai crediti mensili del tuo piano\n\n" .
                         "Ideale quando hai bisogno di più crediti occasionalmente senza cambiare piano."
            ]
        ];

        return $descriptions[ $variant ] ?? null;
    }

    /**
     * Migrate all products
     */
    public static function migrate_all_products() {
        $results = [
            'updated' => 0,
            'skipped' => 0,
            'errors' => []
        ];

        // Get all WooCommerce products
        $args = [
            'post_type' => 'product',
            'posts_per_page' => -1,
            'post_status' => 'any',
            'meta_query' => [
                [
                    'key' => '_ipv_product_type',
                    'value' => 'subscription',
                    'compare' => '='
                ]
            ]
        ];

        $products = get_posts( $args );

        foreach ( $products as $post ) {
            $product = wc_get_product( $post->ID );
            if ( ! $product ) {
                $results['skipped']++;
                continue;
            }

            $variant = $product->get_meta( '_ipv_variant_slug' );
            if ( empty( $variant ) ) {
                $results['skipped']++;
                continue;
            }

            // Detect if yearly (from product name)
            $product_name = $product->get_name();
            $is_yearly = strpos( $product_name, 'Annuale' ) !== false;

            // Get descriptions
            $desc = self::get_descriptions( $variant, $is_yearly );
            if ( ! $desc ) {
                $results['errors'][] = sprintf( 'Unknown variant: %s (Product ID: %d)', $variant, $post->ID );
                continue;
            }

            // Update product descriptions
            $product->set_short_description( wp_strip_all_tags( $desc['short'] ) );
            $product->set_description( wp_strip_all_tags( $desc['long'] ) );

            try {
                $product->save();
                $results['updated']++;
            } catch ( Exception $e ) {
                $results['errors'][] = sprintf( 'Error updating product %d: %s', $post->ID, $e->getMessage() );
            }
        }

        // Handle extra credits separately
        $extra_args = [
            'post_type' => 'product',
            'posts_per_page' => -1,
            'post_status' => 'any',
            'meta_query' => [
                [
                    'key' => '_ipv_product_type',
                    'value' => 'extra_credits',
                    'compare' => '='
                ]
            ]
        ];

        $extra_products = get_posts( $extra_args );
        foreach ( $extra_products as $post ) {
            $product = wc_get_product( $post->ID );
            if ( ! $product ) {
                continue;
            }

            $desc = self::get_descriptions( 'extra_credits' );
            $product->set_short_description( wp_strip_all_tags( $desc['short'] ) );
            $product->set_description( wp_strip_all_tags( $desc['long'] ) );

            try {
                $product->save();
                $results['updated']++;
            } catch ( Exception $e ) {
                $results['errors'][] = sprintf( 'Error updating extra credits %d: %s', $post->ID, $e->getMessage() );
            }
        }

        return $results;
    }

    /**
     * Handle migration POST request
     */
    public static function handle_migration() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Unauthorized' );
        }

        check_admin_referer( 'ipv_migrate_descriptions' );

        $results = self::migrate_all_products();

        $redirect_url = add_query_arg( [
            'page' => 'ipv-migrate-descriptions',
            'migrated' => 1,
            'updated' => $results['updated'],
            'skipped' => $results['skipped'],
            'errors' => count( $results['errors'] )
        ], admin_url( 'admin.php' ) );

        // Store errors in transient
        if ( ! empty( $results['errors'] ) ) {
            set_transient( 'ipv_migration_errors', $results['errors'], 300 );
        }

        wp_redirect( $redirect_url );
        exit;
    }

    /**
     * Render migration page
     */
    public static function render_page() {
        // Count products to migrate
        $args = [
            'post_type' => 'product',
            'posts_per_page' => -1,
            'post_status' => 'any',
            'fields' => 'ids',
            'meta_query' => [
                'relation' => 'OR',
                [
                    'key' => '_ipv_product_type',
                    'value' => 'subscription',
                    'compare' => '='
                ],
                [
                    'key' => '_ipv_product_type',
                    'value' => 'extra_credits',
                    'compare' => '='
                ]
            ]
        ];

        $product_count = count( get_posts( $args ) );

        ?>
        <div class="wrap">
            <h1>🔄 Migrazione Descrizioni Prodotti</h1>

            <?php if ( isset( $_GET['migrated'] ) ) : ?>
                <div class="notice notice-success">
                    <p>
                        <strong>✅ Migrazione completata!</strong><br>
                        Prodotti aggiornati: <?php echo intval( $_GET['updated'] ); ?><br>
                        Prodotti saltati: <?php echo intval( $_GET['skipped'] ); ?><br>
                        Errori: <?php echo intval( $_GET['errors'] ); ?>
                    </p>
                </div>

                <?php
                $errors = get_transient( 'ipv_migration_errors' );
                if ( $errors ) :
                    delete_transient( 'ipv_migration_errors' );
                    ?>
                    <div class="notice notice-error">
                        <p><strong>Errori riscontrati:</strong></p>
                        <ul>
                            <?php foreach ( $errors as $error ) : ?>
                                <li><?php echo esc_html( $error ); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <div style="background: #fff; border: 1px solid #ccd0d4; padding: 20px; margin: 20px 0; max-width: 800px;">
                <h2>📋 Informazioni</h2>
                <p>
                    Questo script aggiorna le descrizioni di tutti i prodotti IPV Pro esistenti
                    da formato HTML a formato <strong>plain text</strong>, risolvendo il problema
                    del testo bianco su sfondo bianco nell'editor WooCommerce.
                </p>

                <h3>🔍 Cosa fa lo script:</h3>
                <ul style="list-style: disc; margin-left: 20px;">
                    <li>Trova tutti i prodotti con <code>_ipv_product_type</code> = subscription o extra_credits</li>
                    <li>Identifica il variant (trial, starter, professional, business)</li>
                    <li>Identifica se è mensile o annuale dal nome del prodotto</li>
                    <li>Applica le nuove descrizioni plain text con caratteri ✓</li>
                    <li>Rimuove tutto l'HTML con <code>wp_strip_all_tags()</code></li>
                    <li>Aggiorna sia short_description che description</li>
                </ul>

                <h3>📊 Prodotti da migrare:</h3>
                <p style="font-size: 18px; font-weight: bold; color: #2271b1;">
                    <?php echo $product_count; ?> prodotti trovati
                </p>

                <div style="background: #fff3cd; border: 1px solid #ffc107; padding: 15px; margin: 20px 0; border-radius: 4px;">
                    <p style="margin: 0;">
                        <strong>⚠️ Attenzione:</strong> Questa operazione modificherà permanentemente
                        le descrizioni dei prodotti. Si consiglia di fare un backup del database prima di procedere.
                    </p>
                </div>

                <form method="post" action="<?php echo admin_url( 'admin-post.php' ); ?>">
                    <?php wp_nonce_field( 'ipv_migrate_descriptions' ); ?>
                    <input type="hidden" name="action" value="ipv_migrate_descriptions">

                    <p>
                        <button type="submit" class="button button-primary button-hero"
                                onclick="return confirm('Sei sicuro di voler aggiornare le descrizioni di <?php echo $product_count; ?> prodotti?');">
                            🔄 Aggiorna Descrizioni
                        </button>
                    </p>
                </form>

                <hr style="margin: 30px 0;">

                <h3>✅ Dopo la migrazione:</h3>
                <ol>
                    <li>Verifica che le descrizioni siano leggibili nell'editor WooCommerce</li>
                    <li>Controlla che i prodotti siano visualizzati correttamente nel frontend</li>
                    <li><strong>Elimina questo file</strong> (<code>migrate-product-descriptions.php</code>) per sicurezza</li>
                </ol>
            </div>
        </div>

        <style>
            .wrap h2 { margin-top: 20px; }
            .wrap h3 { margin-top: 15px; }
            .wrap ul, .wrap ol { margin: 10px 0; }
            .wrap code { background: #f0f0f1; padding: 2px 5px; border-radius: 3px; }
        </style>
        <?php
    }
}

// Initialize
IPV_Vendor_Migrate_Descriptions::init();
