<?php
/**
 * Setup Wizard for IPV Pro Vendor Server
 *
 * Interactive installation wizard with step-by-step configuration
 *
 * @package IPV_Pro_Vendor
 * @version 1.4.0-optimized
 */

if (!defined('ABSPATH')) {
    exit;
}

class IPV_Pro_Vendor_Setup_Wizard {

    /**
     * Initialize wizard
     */
    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'add_wizard_page'));
        add_action('admin_init', array(__CLASS__, 'redirect_to_wizard'));
        add_action('admin_post_ipv_vendor_save_settings', array(__CLASS__, 'save_settings'));
        add_action('admin_post_ipv_vendor_create_products', array(__CLASS__, 'create_products')); // v1.4.1-FIXED3
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_assets'));
    }

    /**
     * Redirect to wizard after activation
     */
    public static function redirect_to_wizard() {
        if (get_transient('ipv_vendor_show_wizard')) {
            delete_transient('ipv_vendor_show_wizard');

            // Check if setup is complete (v1.4.1 - direct check without auto-installer dependency)
            $is_setup_complete = get_option('ipv_vendor_setup_complete', false);

            if (!$is_setup_complete) {
                wp_safe_redirect(admin_url('admin.php?page=ipv-vendor-setup'));
                exit;
            }
        }
    }

    /**
     * Get setup progress (v1.4.1 - independent from auto-installer)
     */
    private static function get_setup_progress() {
        global $wpdb;

        $progress = [
            'steps' => [
                'tables' => false,
                'api_keys' => false,
                'woocommerce' => false,
                'products' => false
            ],
            'completed' => 0,
            'total' => 4,
            'percentage' => 0
        ];

        // Check database tables
        $table = $wpdb->prefix . 'ipv_licenses';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") == $table) {
            $progress['steps']['tables'] = true;
            $progress['completed']++;
        }

        // Check API keys
        if (get_option('ipv_vendor_api_key_supadata') && get_option('ipv_vendor_api_key_openai')) {
            $progress['steps']['api_keys'] = true;
            $progress['completed']++;
        }

        // Check WooCommerce
        if (class_exists('WooCommerce')) {
            $progress['steps']['woocommerce'] = true;
            $progress['completed']++;
        }

        // Check products
        $products = wc_get_products(['limit' => 1, 'status' => 'publish']);
        if (!empty($products)) {
            $progress['steps']['products'] = true;
            $progress['completed']++;
        }

        $progress['percentage'] = round(($progress['completed'] / $progress['total']) * 100);

        return $progress;
    }

    /**
     * Add wizard page to admin menu
     */
    public static function add_wizard_page() {
        add_submenu_page(
            null, // Hidden from menu
            'IPV Pro Vendor Setup',
            'Setup Wizard',
            'manage_options',
            'ipv-vendor-setup',
            array(__CLASS__, 'render_wizard')
        );
    }

    /**
     * Enqueue CSS/JS assets
     */
    public static function enqueue_assets($hook) {
        if ($hook !== 'admin_page_ipv-vendor-setup') {
            return;
        }

        wp_enqueue_style('ipv-vendor-wizard', plugins_url('assets/css/wizard.css', dirname(__FILE__)), array(), '1.4.0');
    }

    /**
     * Render setup wizard
     */
    public static function render_wizard() {
        $progress = self::get_setup_progress();
        $current_step = isset($_GET['step']) ? intval($_GET['step']) : 1;

        ?>
        <div class="wrap ipv-vendor-wizard">
            <h1>🚀 IPV Pro Vendor - Setup Wizard</h1>
            <p>Configurazione guidata del server SaaS. Completa tutti i passaggi per iniziare.</p>

            <!-- Progress Bar -->
            <div class="ipv-progress-bar">
                <div class="ipv-progress-fill" style="width: <?php echo $progress['percentage']; ?>%"></div>
            </div>
            <p class="ipv-progress-text"><?php echo $progress['completed']; ?> di <?php echo $progress['total']; ?> passaggi completati (<?php echo $progress['percentage']; ?>%)</p>

            <div class="ipv-wizard-container">
                <!-- Step Navigation -->
                <div class="ipv-wizard-steps">
                    <div class="ipv-step <?php echo $current_step === 1 ? 'active' : ($progress['steps']['tables'] ? 'completed' : ''); ?>">
                        <span class="ipv-step-number">1</span>
                        <span class="ipv-step-title">Database</span>
                    </div>
                    <div class="ipv-step <?php echo $current_step === 2 ? 'active' : ($progress['steps']['api_keys'] ? 'completed' : ''); ?>">
                        <span class="ipv-step-number">2</span>
                        <span class="ipv-step-title">API Keys</span>
                    </div>
                    <div class="ipv-step <?php echo $current_step === 3 ? 'active' : ($progress['steps']['woocommerce'] ? 'completed' : ''); ?>">
                        <span class="ipv-step-number">3</span>
                        <span class="ipv-step-title">WooCommerce</span>
                    </div>
                    <div class="ipv-step <?php echo $current_step === 4 ? 'active' : ($progress['steps']['products'] ? 'completed' : ''); ?>">
                        <span class="ipv-step-number">4</span>
                        <span class="ipv-step-title">Prodotti</span>
                    </div>
                    <div class="ipv-step <?php echo $current_step === 5 ? 'active' : ''; ?>">
                        <span class="ipv-step-number">5</span>
                        <span class="ipv-step-title">Completo</span>
                    </div>
                </div>

                <!-- Step Content -->
                <div class="ipv-wizard-content">
                    <?php
                    switch ($current_step) {
                        case 1:
                            self::render_step_database($progress);
                            break;
                        case 2:
                            self::render_step_api_keys();
                            break;
                        case 3:
                            self::render_step_woocommerce($progress);
                            break;
                        case 4:
                            self::render_step_products();
                            break;
                        case 5:
                            self::render_step_complete();
                            break;
                    }
                    ?>
                </div>
            </div>
        </div>

        <style>
        .ipv-vendor-wizard { max-width: 900px; margin: 40px auto; }
        .ipv-progress-bar { height: 10px; background: #e0e0e0; border-radius: 5px; margin: 20px 0; }
        .ipv-progress-fill { height: 100%; background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); border-radius: 5px; transition: width 0.3s; }
        .ipv-progress-text { text-align: center; color: #666; }
        .ipv-wizard-steps { display: flex; justify-content: space-between; margin: 30px 0; }
        .ipv-step { display: flex; flex-direction: column; align-items: center; flex: 1; position: relative; }
        .ipv-step-number { width: 40px; height: 40px; border-radius: 50%; background: #e0e0e0; display: flex; align-items: center; justify-content: center; font-weight: bold; color: #666; margin-bottom: 8px; }
        .ipv-step.active .ipv-step-number { background: #667eea; color: white; }
        .ipv-step.completed .ipv-step-number { background: #10b981; color: white; }
        .ipv-step.completed .ipv-step-number::before { content: "✓"; }
        .ipv-step-title { font-size: 12px; color: #666; }
        .ipv-wizard-content { background: white; padding: 40px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin-top: 20px; }
        .ipv-wizard-actions { margin-top: 30px; display: flex; justify-content: space-between; }
        .ipv-success-box { background: #d1fae5; border: 1px solid #10b981; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .ipv-warning-box { background: #fef3c7; border: 1px solid #f59e0b; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .ipv-error-box { background: #fee2e2; border: 1px solid #ef4444; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .ipv-form-group { margin: 20px 0; }
        .ipv-form-group label { display: block; font-weight: 600; margin-bottom: 8px; }
        .ipv-form-group input[type="text"] { width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 5px; }
        .ipv-form-group small { color: #6b7280; display: block; margin-top: 5px; }
        </style>
        <?php
    }

    /**
     * Step 1: Database Tables
     */
    private static function render_step_database($progress) {
        ?>
        <h2>📊 Step 1: Creazione Database</h2>

        <?php if ($progress['steps']['tables']): ?>
            <div class="ipv-success-box">
                <strong>✅ Database configurato correttamente!</strong>
                <p>Tutte le 5 tabelle sono state create con successo:</p>
                <ul>
                    <li><code>wp_ipv_licenses</code> - Gestione licenze</li>
                    <li><code>wp_ipv_license_activations</code> - Attivazioni siti</li>
                    <li><code>wp_ipv_api_logs</code> - Audit log API</li>
                    <li><code>wp_ipv_security_log</code> - Eventi sicurezza</li>
                    <li><code>wp_ipv_performance_stats</code> - Statistiche performance</li>
                </ul>
            </div>
        <?php else: ?>
            <div class="ipv-warning-box">
                <strong>⚠️ Tabelle database non trovate</strong>
                <p>Le tabelle database verranno create automaticamente durante l'attivazione del plugin.</p>
            </div>
        <?php endif; ?>

        <h3>Informazioni Database</h3>
        <table class="widefat">
            <tr>
                <th>Database Host:</th>
                <td><code><?php echo DB_HOST; ?></code></td>
            </tr>
            <tr>
                <th>Database Name:</th>
                <td><code><?php echo DB_NAME; ?></code></td>
            </tr>
            <tr>
                <th>Table Prefix:</th>
                <td><code><?php global $wpdb; echo $wpdb->prefix; ?></code></td>
            </tr>
            <tr>
                <th>MySQL Version:</th>
                <td><code><?php echo $wpdb->db_version(); ?></code></td>
            </tr>
        </table>

        <div class="ipv-wizard-actions">
            <span></span>
            <a href="<?php echo admin_url('admin.php?page=ipv-vendor-setup&step=2'); ?>" class="button button-primary button-large">
                Avanti: Configura API Keys →
            </a>
        </div>
        <?php
    }

    /**
     * Step 2: API Keys Configuration
     */
    private static function render_step_api_keys() {
        $youtube_key = get_option('ipv_vendor_youtube_api_key');
        $openai_key = get_option('ipv_vendor_openai_api_key');
        $supadata_key = get_option('ipv_vendor_supadata_key');
        $supadata_secret = get_option('ipv_vendor_supadata_secret');

        ?>
        <h2>🔑 Step 2: Configurazione API Keys</h2>
        <p>Inserisci le chiavi API necessarie per il funzionamento del sistema.</p>

        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
            <?php wp_nonce_field('ipv_vendor_save_settings'); ?>
            <input type="hidden" name="action" value="ipv_vendor_save_settings">
            <input type="hidden" name="redirect_step" value="3">

            <div class="ipv-form-group">
                <label for="youtube_api_key">
                    YouTube Data API Key <span style="color: red;">*</span>
                </label>
                <input type="text"
                       id="youtube_api_key"
                       name="youtube_api_key"
                       value="<?php echo esc_attr($youtube_key); ?>"
                       placeholder="AIzaSy..."
                       required>
                <small>
                    Ottieni la tua chiave su: <a href="https://console.cloud.google.com/apis/credentials" target="_blank">Google Cloud Console</a><br>
                    Abilita "YouTube Data API v3" nel progetto.
                </small>
            </div>

            <div class="ipv-form-group">
                <label for="openai_api_key">
                    OpenAI API Key <span style="color: red;">*</span>
                </label>
                <input type="text"
                       id="openai_api_key"
                       name="openai_api_key"
                       value="<?php echo esc_attr($openai_key); ?>"
                       placeholder="sk-..."
                       required>
                <small>
                    Ottieni la tua chiave su: <a href="https://platform.openai.com/api-keys" target="_blank">OpenAI Platform</a><br>
                    Richiesto per generazione contenuti AI (GPT-4).
                </small>
            </div>

            <div class="ipv-form-group">
                <label for="supadata_key">
                    SupaData API Key <span style="color: red;">*</span>
                </label>
                <input type="text"
                       id="supadata_key"
                       name="supadata_key"
                       value="<?php echo esc_attr($supadata_key); ?>"
                       placeholder="sd_..."
                       required>
                <small>
                    Ottieni le tue credenziali su: <a href="https://supadata.ai" target="_blank">SupaData.ai</a><br>
                    Richiesto per transcript YouTube.
                </small>
            </div>

            <div class="ipv-form-group">
                <label for="supadata_secret">
                    SupaData API Secret
                </label>
                <input type="text"
                       id="supadata_secret"
                       name="supadata_secret"
                       value="<?php echo esc_attr($supadata_secret); ?>"
                       placeholder="Optional">
                <small>Opzionale - richiesto solo per alcuni piani SupaData.</small>
            </div>

            <div class="ipv-warning-box">
                <strong>💡 Suggerimento:</strong> Puoi saltare questo passaggio e configurare le API Keys in seguito in <strong>Impostazioni → IPV Pro Vendor</strong>.
            </div>

            <div class="ipv-wizard-actions">
                <a href="<?php echo admin_url('admin.php?page=ipv-vendor-setup&step=1'); ?>" class="button button-large">
                    ← Indietro
                </a>
                <button type="submit" class="button button-primary button-large">
                    Salva e Continua →
                </button>
            </div>
        </form>
        <?php
    }

    /**
     * Step 3: WooCommerce Check
     */
    private static function render_step_woocommerce($progress) {
        $wc_installed = class_exists('WooCommerce');
        $wc_subs_installed = class_exists('WC_Subscriptions');

        ?>
        <h2>🛒 Step 3: WooCommerce Setup</h2>

        <?php if ($wc_installed): ?>
            <div class="ipv-success-box">
                <strong>✅ WooCommerce è installato!</strong>
                <p>Versione: <code><?php echo WC()->version; ?></code></p>
            </div>
        <?php else: ?>
            <div class="ipv-error-box">
                <strong>❌ WooCommerce non trovato</strong>
                <p>WooCommerce è richiesto per gestire vendite e licenze.</p>
                <a href="<?php echo admin_url('plugin-install.php?s=woocommerce&tab=search&type=term'); ?>" class="button button-primary">
                    Installa WooCommerce
                </a>
            </div>
        <?php endif; ?>

        <?php if ($wc_subs_installed): ?>
            <div class="ipv-success-box">
                <strong>✅ WooCommerce Subscriptions attivo!</strong>
                <p>Potrai vendere abbonamenti ricorrenti mensili.</p>
            </div>
        <?php else: ?>
            <div class="ipv-warning-box">
                <strong>⚠️ WooCommerce Subscriptions non trovato</strong>
                <p>Plugin opzionale ma raccomandato per abbonamenti ricorrenti.</p>
                <small>Puoi anche vendere licenze one-time senza Subscriptions.</small>
            </div>
        <?php endif; ?>

        <h3>Configurazione Gateway Pagamento</h3>
        <?php if ($wc_installed): ?>
            <p>Configura il tuo gateway di pagamento preferito:</p>
            <ul>
                <li><a href="<?php echo admin_url('admin.php?page=wc-settings&tab=checkout&section=stripe'); ?>">Stripe</a> (Raccomandato)</li>
                <li><a href="<?php echo admin_url('admin.php?page=wc-settings&tab=checkout&section=paypal'); ?>">PayPal</a></li>
                <li><a href="<?php echo admin_url('admin.php?page=wc-settings&tab=checkout'); ?>">Altri gateway</a></li>
            </ul>
        <?php endif; ?>

        <div class="ipv-wizard-actions">
            <a href="<?php echo admin_url('admin.php?page=ipv-vendor-setup&step=2'); ?>" class="button button-large">
                ← Indietro
            </a>
            <?php if ($wc_installed): ?>
                <a href="<?php echo admin_url('admin.php?page=ipv-vendor-setup&step=4'); ?>" class="button button-primary button-large">
                    Avanti: Crea Prodotti →
                </a>
            <?php else: ?>
                <span class="button button-primary button-large disabled">
                    Installa WooCommerce per continuare
                </span>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Step 4: Create Products
     */
    private static function render_step_products() {
        // Get saved billing type
        $billing_type = get_option('ipv_vendor_billing_type', 'monthly');
        ?>
        <h2>📦 Step 4: Creazione Prodotti IPV Pro</h2>
        <p>Crea i prodotti WooCommerce per i piani IPV Pro.</p>

        <div class="ipv-warning-box">
            <strong>💡 Nota:</strong> Puoi creare i prodotti manualmente o usare il pulsante qui sotto per crearli automaticamente.
        </div>

        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
            <?php wp_nonce_field('ipv_vendor_create_products'); ?>
            <input type="hidden" name="action" value="ipv_vendor_create_products">

            <div class="ipv-form-group" style="margin: 25px 0; padding: 20px; background: #f9fafb; border: 2px solid #e5e7eb; border-radius: 8px;">
                <label style="font-size: 16px; font-weight: 600; margin-bottom: 15px; display: block;">
                    💳 Tipo di Fatturazione
                </label>
                <div style="display: flex; gap: 20px;">
                    <label style="display: flex; align-items: center; cursor: pointer; padding: 15px 20px; background: white; border: 2px solid #d1d5db; border-radius: 6px; flex: 1;">
                        <input type="radio"
                               name="billing_type"
                               value="monthly"
                               <?php checked($billing_type, 'monthly'); ?>
                               style="margin-right: 10px; width: 20px; height: 20px;">
                        <div>
                            <strong style="display: block; font-size: 15px;">📅 Mensile</strong>
                            <small style="color: #6b7280;">Fatturazione mensile ricorrente</small>
                        </div>
                    </label>
                    <label style="display: flex; align-items: center; cursor: pointer; padding: 15px 20px; background: white; border: 2px solid #d1d5db; border-radius: 6px; flex: 1;">
                        <input type="radio"
                               name="billing_type"
                               value="yearly"
                               <?php checked($billing_type, 'yearly'); ?>
                               style="margin-right: 10px; width: 20px; height: 20px;">
                        <div>
                            <strong style="display: block; font-size: 15px;">📆 Annuale</strong>
                            <small style="color: #6b7280;">Fatturazione annuale (sconto 2 mesi)</small>
                        </div>
                    </label>
                </div>
                <small style="color: #6b7280; display: block; margin-top: 10px;">
                    💡 <strong>Annuale:</strong> I clienti pagano per 10 mesi e ricevono 12 mesi di servizio (sconto ~17%)
                </small>
            </div>

            <h3>Piani Raccomandati</h3>
            <table class="widefat" id="pricing-table">
                <thead>
                    <tr>
                        <th>Piano</th>
                        <th>Prezzo Mensile</th>
                        <th>Prezzo Annuale</th>
                        <th>Credits/Mese</th>
                        <th>Target</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>Trial</strong></td>
                        <td>€0 (gratuito)</td>
                        <td>€0 (gratuito)</td>
                        <td>10 credits</td>
                        <td>Test e demo</td>
                    </tr>
                    <tr style="background: #f9fafb;">
                        <td><strong>Starter</strong></td>
                        <td>€19.95/mese</td>
                        <td><strong>€199.50/anno</strong> <small style="color: #10b981;">(risparmi €39.90)</small></td>
                        <td>25 credits</td>
                        <td>Blogger, piccoli siti</td>
                    </tr>
                    <tr>
                        <td><strong>Professional</strong></td>
                        <td>€49.95/mese</td>
                        <td><strong>€499.50/anno</strong> <small style="color: #10b981;">(risparmi €99.90)</small></td>
                        <td>100 credits</td>
                        <td>Business, agenzie</td>
                    </tr>
                    <tr style="background: #f9fafb;">
                        <td><strong>Business</strong></td>
                        <td>€99.95/mese</td>
                        <td><strong>€999.50/anno</strong> <small style="color: #10b981;">(risparmi €199.90)</small></td>
                        <td>500 credits</td>
                        <td>Enterprise, power users</td>
                    </tr>
                </tbody>
            </table>

            <div style="margin-top: 20px;">
                <button type="submit" class="button button-primary button-large">
                    🚀 Crea Prodotti Automaticamente
                </button>
                <a href="<?php echo admin_url('post-new.php?post_type=product'); ?>" class="button button-large">
                    Crea Manualmente
                </a>
            </div>
        </form>

        <script>
        jQuery(document).ready(function($) {
            // Update table highlighting based on selected billing type
            $('input[name="billing_type"]').on('change', function() {
                var selected = $(this).val();
                if (selected === 'monthly') {
                    $('#pricing-table th:nth-child(2)').css({'background': '#dbeafe', 'font-weight': 'bold'});
                    $('#pricing-table th:nth-child(3)').css({'background': '', 'font-weight': ''});
                } else {
                    $('#pricing-table th:nth-child(2)').css({'background': '', 'font-weight': ''});
                    $('#pricing-table th:nth-child(3)').css({'background': '#dbeafe', 'font-weight': 'bold'});
                }
            }).trigger('change');
        });
        </script>

        <div class="ipv-wizard-actions">
            <a href="<?php echo admin_url('admin.php?page=ipv-vendor-setup&step=3'); ?>" class="button button-large">
                ← Indietro
            </a>
            <a href="<?php echo admin_url('admin.php?page=ipv-vendor-setup&step=5'); ?>" class="button button-primary button-large">
                Avanti: Completa Setup →
            </a>
        </div>
        <?php
    }

    /**
     * Step 5: Setup Complete
     */
    private static function render_step_complete() {
        $progress = self::get_setup_progress();
        $admin_email = get_option('admin_email');

        ?>
        <h2>🎉 Installazione Completata!</h2>

        <?php if ($progress['percentage'] >= 75): ?>
            <div class="ipv-success-box">
                <strong>✅ IPV Pro Vendor è pronto per l'uso!</strong>
                <p>Il server SaaS è configurato e operativo.</p>
            </div>

            <h3>🚀 Prossimi Passi</h3>
            <ol>
                <li><strong>Crea una licenza di prova:</strong>
                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="display: inline;">
                        <?php wp_nonce_field('ipv_vendor_create_trial'); ?>
                        <input type="hidden" name="action" value="ipv_vendor_create_trial">
                        <input type="hidden" name="email" value="<?php echo esc_attr($admin_email); ?>">
                        <button type="submit" class="button button-primary">Genera Licenza Trial</button>
                    </form>
                </li>
                <li><strong>Testa l'API:</strong>
                    <code>curl <?php echo home_url('/wp-json/ipv-vendor/v1/health'); ?></code>
                </li>
                <li><strong>Configura il client:</strong> Installa il plugin client su un sito WordPress</li>
                <li><strong>Monitor performance:</strong> <a href="<?php echo admin_url('admin.php?page=ipv-vendor-stats'); ?>">Dashboard Statistiche</a></li>
            </ol>

            <h3>📊 Riepilogo Configurazione</h3>
            <ul>
                <li>✅ Database: <?php echo $progress['steps']['tables'] ? 'Configurato' : '❌ Non configurato'; ?></li>
                <li>✅ API Keys: <?php echo $progress['steps']['api_keys'] ? 'Configurate' : '⚠️ Da configurare'; ?></li>
                <li>✅ WooCommerce: <?php echo $progress['steps']['woocommerce'] ? 'Installato' : '❌ Non installato'; ?></li>
                <li>✅ Prodotti: <?php echo $progress['steps']['products'] ? 'Creati' : '⚠️ Da creare'; ?></li>
            </ul>

        <?php else: ?>
            <div class="ipv-warning-box">
                <strong>⚠️ Setup non completo</strong>
                <p>Alcuni passaggi richiedono attenzione. Completa la configurazione per usare IPV Pro Vendor.</p>
            </div>
        <?php endif; ?>

        <h3>📚 Documentazione</h3>
        <ul>
            <li><a href="<?php echo plugins_url('README.md', dirname(__FILE__)); ?>">README.md</a> - Guida completa</li>
            <li><a href="https://github.com/daniemi1977/ipv" target="_blank">GitHub Repository</a></li>
            <li><a href="mailto:support@ipv-pro.com">Supporto Email</a></li>
        </ul>

        <div class="ipv-wizard-actions">
            <a href="<?php echo admin_url('admin.php?page=ipv-vendor-setup&step=4'); ?>" class="button button-large">
                ← Indietro
            </a>
            <a href="<?php echo admin_url('admin.php?page=ipv-vendor'); ?>" class="button button-primary button-large">
                Vai al Dashboard →
            </a>
        </div>
        <?php
    }

    /**
     * Save settings from wizard
     */
    public static function save_settings() {
        check_admin_referer('ipv_vendor_save_settings');

        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        // Save API keys
        if (isset($_POST['youtube_api_key'])) {
            update_option('ipv_vendor_youtube_api_key', sanitize_text_field($_POST['youtube_api_key']));
        }
        if (isset($_POST['openai_api_key'])) {
            update_option('ipv_vendor_openai_api_key', sanitize_text_field($_POST['openai_api_key']));
        }
        if (isset($_POST['supadata_key'])) {
            update_option('ipv_vendor_supadata_key', sanitize_text_field($_POST['supadata_key']));
        }
        if (isset($_POST['supadata_secret'])) {
            update_option('ipv_vendor_supadata_secret', sanitize_text_field($_POST['supadata_secret']));
        }

        $redirect_step = isset($_POST['redirect_step']) ? intval($_POST['redirect_step']) : 3;
        wp_safe_redirect(admin_url('admin.php?page=ipv-vendor-setup&step=' . $redirect_step . '&saved=1'));
        exit;
    }

    /**
     * Create IPV Pro products automatically (v1.4.1-FIXED3)
     */
    public static function create_products() {
        check_admin_referer('ipv_vendor_create_products');

        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        if (!class_exists('WooCommerce')) {
            wp_die('WooCommerce non è installato!');
        }

        // Get billing type from form
        $billing_type = isset($_POST['billing_type']) ? sanitize_text_field($_POST['billing_type']) : 'monthly';

        // Save billing type preference
        update_option('ipv_vendor_billing_type', $billing_type);

        // Define product configurations
        $products_config = [
            'trial' => [
                'name' => 'IPV Pro - Trial',
                'credits' => 10,
                'price_monthly' => 0,
                'price_yearly' => 0
            ],
            'starter' => [
                'name' => 'IPV Pro - Starter',
                'credits' => 25,
                'price_monthly' => 19.95,
                'price_yearly' => 199.50  // 10 months price
            ],
            'professional' => [
                'name' => 'IPV Pro - Professional',
                'credits' => 100,
                'price_monthly' => 49.95,
                'price_yearly' => 499.50  // 10 months price
            ],
            'business' => [
                'name' => 'IPV Pro - Business',
                'credits' => 500,
                'price_monthly' => 99.95,
                'price_yearly' => 999.50  // 10 months price
            ]
        ];

        $created = 0;
        $is_yearly = ($billing_type === 'yearly');

        foreach ($products_config as $variant => $config) {
            // Build product name based on billing type
            $product_name = $config['name'];
            if ($variant !== 'trial') {
                $product_name .= $is_yearly ? ' - Annuale' : ' - Mensile';
            }

            // Check if product already exists
            $existing = wc_get_products([
                'name' => $product_name,
                'limit' => 1,
                'status' => ['publish', 'draft']
            ]);

            if (!empty($existing)) {
                continue; // Skip if exists
            }

            // Get price based on billing type
            $price = $is_yearly ? $config['price_yearly'] : $config['price_monthly'];

            // Build description
            if ($variant === 'trial') {
                $desc = 'Piano di prova gratuito con ' . $config['credits'] . ' crediti mensili per testare IPV Production System Pro.';
            } else {
                $billing_label = $is_yearly ? 'anno (12 mesi di servizio al prezzo di 10)' : 'mese';
                $target_map = [
                    'starter' => 'blogger e piccoli siti',
                    'professional' => 'business e agenzie',
                    'business' => 'enterprise e power users'
                ];
                $target = $target_map[$variant] ?? '';
                $desc = sprintf(
                    'Piano %s ideale per %s. Include %d crediti mensili. Fatturazione: €%.2f/%s.',
                    ucfirst($variant),
                    $target,
                    $config['credits'],
                    $price,
                    $billing_label
                );
            }

            // Create product
            $product = new WC_Product_Simple();
            $product->set_name($product_name);
            $product->set_status('publish');
            $product->set_catalog_visibility('visible');
            $product->set_description($desc);
            $product->set_regular_price($price);
            $product->set_virtual(true);
            $product->set_downloadable(false);

            // Add custom meta
            $product->update_meta_data('_ipv_variant_slug', $variant);
            $product->update_meta_data('_ipv_credits_total', $config['credits']);
            $product->update_meta_data('_ipv_product_type', 'subscription');
            $product->update_meta_data('_ipv_billing_type', $billing_type);
            $product->update_meta_data('_ipv_billing_period', $is_yearly ? 'year' : 'month');

            $product_id = $product->save();

            if ($product_id) {
                $created++;
            }
        }

        // Create Extra Credits product (independent of billing type)
        $extra_exists = wc_get_products([
            'name' => 'IPV Pro - Crediti Extra',
            'limit' => 1,
            'status' => ['publish', 'draft']
        ]);

        if (empty($extra_exists)) {
            $extra = new WC_Product_Simple();
            $extra->set_name('IPV Pro - Crediti Extra');
            $extra->set_status('publish');
            $extra->set_regular_price(0.35);
            $extra->set_description('Acquista crediti extra per IPV Production System Pro. Prezzo per credito: €0.35 (minimo 10 crediti). I crediti extra non scadono mai.');
            $extra->set_virtual(true);
            $extra->set_sold_individually(false);

            $extra->update_meta_data('_ipv_product_type', 'credits_extra');
            $extra->update_meta_data('_ipv_min_quantity', 10);

            if ($extra->save()) {
                $created++;
            }
        }

        wp_safe_redirect(admin_url('admin.php?page=ipv-vendor-setup&step=5&created=' . $created . '&billing=' . $billing_type));
        exit;
    }
}
