
# IPV Production System Pro – Changelog

## v4.5
- Added Prompt Gold integration
- Added Markdown/Notion renderer
- Added Short Filter (<5 minutes)
- Added Custom Template for CPT
- Added Info screen in admin
- General improvements and fixes
