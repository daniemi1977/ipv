<?php
/**
 * IPV Production System Pro - Diagnostics Tool
 *
 * Tool di diagnostica per troubleshooting connessione server e problemi API
 *
 * @package IPV_Production_System_Pro
 * @version 10.0.8
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class IPV_Prod_Diagnostics {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function init() {
        add_action( 'admin_menu', [ $this, 'register_menu' ] );
        add_action( 'admin_post_ipv_run_diagnostics', [ $this, 'run_diagnostics' ] );
    }

    /**
     * Register diagnostics menu
     */
    public function register_menu() {
        add_submenu_page(
            'edit.php?post_type=ipv_video',
            __( 'Diagnostica Sistema', 'ipv-production-system-pro' ),
            __( 'Diagnostica', 'ipv-production-system-pro' ),
            'manage_options',
            'ipv-diagnostics',
            [ $this, 'render_page' ]
        );
    }

    /**
     * Render diagnostics page
     */
    public function render_page() {
        ?>
        <div class="wrap">
            <h1>🔍 Diagnostica Sistema IPV</h1>
            <p>Questo strumento verifica la configurazione e la connessione al server IPV Pro Vendor.</p>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <?php wp_nonce_field( 'ipv_diagnostics', 'ipv_diagnostics_nonce' ); ?>
                <input type="hidden" name="action" value="ipv_run_diagnostics">
                <?php submit_button( 'Esegui Diagnostica', 'primary', 'submit', false ); ?>
            </form>

            <hr>

            <?php
            // Show results if available
            if ( isset( $_GET['ran'] ) && $_GET['ran'] === '1' ) {
                $results = get_transient( 'ipv_diagnostics_results' );
                if ( $results ) {
                    $this->render_results( $results );
                    delete_transient( 'ipv_diagnostics_results' );
                }
            }
            ?>

            <div style="margin-top: 30px; padding: 15px; background: #f0f0f1; border-left: 4px solid #2271b1;">
                <h3>ℹ️ Cosa Controlla Questo Tool</h3>
                <ol>
                    <li><strong>Configurazione Locale</strong> - License key e server URL</li>
                    <li><strong>Server Raggiungibilità</strong> - Se il server risponde</li>
                    <li><strong>Versione Server</strong> - Quale versione è installata</li>
                    <li><strong>Validazione Licenza</strong> - Se la licenza è valida</li>
                    <li><strong>Test SupaData</strong> - Se le API di trascrizione funzionano</li>
                    <li><strong>Test OpenAI</strong> - Se le API di generazione descrizione funzionano</li>
                    <li><strong>Crediti Disponibili</strong> - Quanti crediti rimangono</li>
                </ol>
            </div>
        </div>
        <?php
    }

    /**
     * Run diagnostics
     */
    public function run_diagnostics() {
        check_admin_referer( 'ipv_diagnostics', 'ipv_diagnostics_nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Unauthorized' );
        }

        $results = [
            'timestamp' => current_time( 'mysql' ),
            'tests' => []
        ];

        // Test 1: Check local configuration
        $results['tests'][] = $this->test_local_config();

        // Test 2: Check server health
        $results['tests'][] = $this->test_server_health();

        // Test 3: Validate license
        $results['tests'][] = $this->test_license_validation();

        // Test 4: Check credits
        $results['tests'][] = $this->test_credits();

        // Test 5: Test SupaData API
        $results['tests'][] = $this->test_supadata_api();

        // Store results in transient
        set_transient( 'ipv_diagnostics_results', $results, 60 );

        // Redirect back
        wp_safe_redirect( add_query_arg( 'ran', '1', admin_url( 'edit.php?post_type=ipv_video&page=ipv-diagnostics' ) ) );
        exit;
    }

    /**
     * Test 1: Local configuration
     */
    private function test_local_config() {
        $test = [
            'name' => 'Configurazione Locale',
            'status' => 'success',
            'messages' => []
        ];

        // Check license key
        $license_key = get_option( 'ipv_license_key', '' );
        if ( empty( $license_key ) ) {
            $test['status'] = 'error';
            $test['messages'][] = '❌ License key NON configurata! Vai su IPV Videos → Licenza per configurarla.';
        } else {
            $test['messages'][] = '✅ License key configurata: ' . substr( $license_key, 0, 8 ) . '...' . substr( $license_key, -4 );
        }

        // Check server URL
        $server_url = get_option( 'ipv_api_server_url', '' );
        if ( empty( $server_url ) ) {
            $test['status'] = 'error';
            $test['messages'][] = '❌ Server URL NON configurato! Vai su IPV Videos → Impostazioni → Server per configurarlo.';
        } else {
            $test['messages'][] = '✅ Server URL configurato: ' . $server_url;
        }

        // Check license info cache
        $license_info = get_option( 'ipv_license_info', [] );
        if ( ! empty( $license_info ) && isset( $license_info['status'] ) ) {
            $test['messages'][] = '✅ License info cache: Status = ' . $license_info['status'];
        } else {
            $test['messages'][] = '⚠️ License info cache vuota (normale se licenza mai validata)';
        }

        return $test;
    }

    /**
     * Test 2: Server health check
     */
    private function test_server_health() {
        $test = [
            'name' => 'Server Raggiungibilità',
            'status' => 'unknown',
            'messages' => []
        ];

        $server_url = get_option( 'ipv_api_server_url', '' );
        if ( empty( $server_url ) ) {
            $test['status'] = 'error';
            $test['messages'][] = '❌ Impossibile testare: server URL non configurato';
            return $test;
        }

        $health_url = rtrim( $server_url, '/' ) . '/wp-json/ipv-vendor/v1/health';
        $test['messages'][] = '🔍 Testando: ' . $health_url;

        $response = wp_remote_get( $health_url, [ 'timeout' => 10 ] );

        if ( is_wp_error( $response ) ) {
            $test['status'] = 'error';
            $test['messages'][] = '❌ Errore connessione: ' . $response->get_error_message();
            $test['messages'][] = '💡 Possibili cause:';
            $test['messages'][] = '   - Server URL errato';
            $test['messages'][] = '   - Server offline';
            $test['messages'][] = '   - Firewall blocca la connessione';
            $test['messages'][] = '   - Plugin IPV Pro Vendor non attivo sul server';
            return $test;
        }

        $status_code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $status_code === 200 && isset( $body['status'] ) && $body['status'] === 'ok' ) {
            $test['status'] = 'success';
            $test['messages'][] = '✅ Server raggiungibile!';
            if ( isset( $body['version'] ) ) {
                $test['messages'][] = '✅ Versione server: ' . $body['version'];
            }
            if ( isset( $body['service'] ) ) {
                $test['messages'][] = '✅ Service: ' . $body['service'];
            }
        } else {
            $test['status'] = 'error';
            $test['messages'][] = '❌ Server risponde ma con errore';
            $test['messages'][] = '   HTTP Status: ' . $status_code;
            $test['messages'][] = '   Response: ' . wp_json_encode( $body );
        }

        return $test;
    }

    /**
     * Test 3: License validation
     */
    private function test_license_validation() {
        $test = [
            'name' => 'Validazione Licenza',
            'status' => 'unknown',
            'messages' => []
        ];

        $license_key = get_option( 'ipv_license_key', '' );
        if ( empty( $license_key ) ) {
            $test['status'] = 'error';
            $test['messages'][] = '❌ Impossibile testare: license key non configurata';
            return $test;
        }

        $api_client = IPV_Prod_API_Client::instance();

        // Try to validate license via server
        $server_url = get_option( 'ipv_api_server_url', '' );
        if ( empty( $server_url ) ) {
            $test['status'] = 'error';
            $test['messages'][] = '❌ Impossibile testare: server URL non configurato';
            return $test;
        }

        $validate_url = rtrim( $server_url, '/' ) . '/wp-json/ipv-vendor/v1/license/validate';
        $test['messages'][] = '🔍 Validando licenza su: ' . $validate_url;

        $response = wp_remote_post( $validate_url, [
            'timeout' => 15,
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $license_key,
                'X-License-Key' => $license_key
            ],
            'body' => wp_json_encode([
                'license_key' => $license_key,
                'site_url' => home_url()
            ])
        ]);

        if ( is_wp_error( $response ) ) {
            $test['status'] = 'error';
            $test['messages'][] = '❌ Errore chiamata: ' . $response->get_error_message();
            return $test;
        }

        $status_code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $status_code === 200 && isset( $body['success'] ) && $body['success'] ) {
            $test['status'] = 'success';
            $test['messages'][] = '✅ Licenza VALIDA!';

            if ( isset( $body['license'] ) ) {
                $license = $body['license'];
                $test['messages'][] = '   - Product: ' . ( $license['product_name'] ?? 'N/A' );
                $test['messages'][] = '   - Status: ' . ( $license['status'] ?? 'N/A' );
                $test['messages'][] = '   - Expiry: ' . ( $license['expiry_date'] ?? 'Never' );
                $test['messages'][] = '   - Site: ' . ( $license['site_url'] ?? 'N/A' );
            }
        } elseif ( $status_code === 401 ) {
            $test['status'] = 'error';
            $test['messages'][] = '❌ Licenza NON VALIDA (401 Unauthorized)';
            $test['messages'][] = '   Messaggio: ' . ( $body['message'] ?? 'Sconosciuto' );
            $test['messages'][] = '💡 Possibili cause:';
            $test['messages'][] = '   - License key errata o scaduta';
            $test['messages'][] = '   - Licenza non attivata per questo dominio';
            $test['messages'][] = '   - Server non riesce a validare la licenza (problema database)';
        } else {
            $test['status'] = 'error';
            $test['messages'][] = '❌ Errore validazione licenza';
            $test['messages'][] = '   HTTP Status: ' . $status_code;
            $test['messages'][] = '   Response: ' . wp_json_encode( $body );
        }

        return $test;
    }

    /**
     * Test 4: Check credits
     */
    private function test_credits() {
        $test = [
            'name' => 'Crediti Disponibili',
            'status' => 'unknown',
            'messages' => []
        ];

        if ( ! IPV_Prod_API_Client::is_license_active() ) {
            $test['status'] = 'warning';
            $test['messages'][] = '⚠️ Impossibile testare: licenza non attiva';
            return $test;
        }

        $api_client = IPV_Prod_API_Client::instance();

        $server_url = get_option( 'ipv_api_server_url', '' );
        $license_key = get_option( 'ipv_license_key', '' );

        if ( empty( $server_url ) || empty( $license_key ) ) {
            $test['status'] = 'error';
            $test['messages'][] = '❌ Configurazione incompleta';
            return $test;
        }

        $credits_url = rtrim( $server_url, '/' ) . '/wp-json/ipv-vendor/v1/credits';

        $response = wp_remote_get( $credits_url, [
            'timeout' => 10,
            'headers' => [
                'Authorization' => 'Bearer ' . $license_key,
                'X-License-Key' => $license_key
            ]
        ]);

        if ( is_wp_error( $response ) ) {
            $test['status'] = 'error';
            $test['messages'][] = '❌ Errore: ' . $response->get_error_message();
            return $test;
        }

        $status_code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $status_code === 200 && isset( $body['success'] ) && $body['success'] ) {
            $credits = $body['credits'] ?? [];
            $remaining = $credits['credits_remaining'] ?? 0;
            $total = $credits['credits_total'] ?? 0;

            if ( $remaining > 0 ) {
                $test['status'] = 'success';
                $test['messages'][] = '✅ Crediti disponibili: ' . $remaining . '/' . $total;
            } else {
                $test['status'] = 'warning';
                $test['messages'][] = '⚠️ Crediti esauriti: 0/' . $total;
            }

            if ( isset( $credits['credits_reset_date'] ) ) {
                $test['messages'][] = '   Reset: ' . $credits['credits_reset_date'];
            }
        } else {
            $test['status'] = 'error';
            $test['messages'][] = '❌ Errore recupero crediti';
            $test['messages'][] = '   HTTP Status: ' . $status_code;
        }

        return $test;
    }

    /**
     * Test 5: Test SupaData API
     */
    private function test_supadata_api() {
        $test = [
            'name' => 'Test SupaData API',
            'status' => 'unknown',
            'messages' => []
        ];

        if ( ! IPV_Prod_API_Client::is_license_active() ) {
            $test['status'] = 'warning';
            $test['messages'][] = '⚠️ Impossibile testare: licenza non attiva';
            return $test;
        }

        $test['messages'][] = '⏭️ Test SupaData saltato (richiede video_id reale e scala crediti)';
        $test['messages'][] = '💡 Per testare SupaData:';
        $test['messages'][] = '   1. Vai su un video esistente';
        $test['messages'][] = '   2. Clicca "Rigenera Trascrizione"';
        $test['messages'][] = '   3. Controlla se funziona';
        $test['status'] = 'info';

        return $test;
    }

    /**
     * Render diagnostic results
     */
    private function render_results( $results ) {
        ?>
        <div style="margin-top: 20px;">
            <h2>📊 Risultati Diagnostica</h2>
            <p><strong>Timestamp:</strong> <?php echo esc_html( $results['timestamp'] ); ?></p>

            <?php foreach ( $results['tests'] as $test ) : ?>
                <div style="margin: 20px 0; padding: 15px; border: 2px solid <?php
                    echo $test['status'] === 'success' ? '#46b450' :
                         ($test['status'] === 'error' ? '#dc3232' :
                         ($test['status'] === 'warning' ? '#ffb900' : '#72aee6'));
                ?>; border-radius: 4px; background: #fff;">
                    <h3 style="margin-top: 0;">
                        <?php
                        if ( $test['status'] === 'success' ) echo '✅';
                        elseif ( $test['status'] === 'error' ) echo '❌';
                        elseif ( $test['status'] === 'warning' ) echo '⚠️';
                        else echo 'ℹ️';
                        ?>
                        <?php echo esc_html( $test['name'] ); ?>
                    </h3>
                    <?php foreach ( $test['messages'] as $message ) : ?>
                        <div style="margin: 5px 0; font-family: monospace;">
                            <?php echo esc_html( $message ); ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>

            <div style="margin-top: 30px; padding: 15px; background: #e7f5fe; border-left: 4px solid #2271b1;">
                <h3>🔧 Prossimi Passi</h3>
                <?php
                $has_errors = false;
                foreach ( $results['tests'] as $test ) {
                    if ( $test['status'] === 'error' ) {
                        $has_errors = true;
                        break;
                    }
                }

                if ( $has_errors ) : ?>
                    <p><strong>Risolvi gli errori sopra prima di procedere:</strong></p>
                    <ol>
                        <li>Se manca <strong>license key</strong>: Vai su IPV Videos → Licenza</li>
                        <li>Se manca <strong>server URL</strong>: Vai su IPV Videos → Impostazioni → Server</li>
                        <li>Se il server non risponde: Verifica che IPV Pro Vendor sia attivo sul server</li>
                        <li>Se la licenza non è valida: Controlla che sia attivata per questo dominio</li>
                    </ol>
                <?php else : ?>
                    <p>✅ <strong>Tutto OK!</strong> Il sistema è configurato correttamente.</p>
                    <p>Se continui ad avere problemi con SupaData o altre API:</p>
                    <ol>
                        <li>Verifica che il server abbia la versione <strong>v1.3.1 o successiva</strong></li>
                        <li>Controlla i log del server in: <code>/wp-content/debug.log</code></li>
                        <li>Contatta il supporto con questi risultati diagnostici</li>
                    </ol>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
}
