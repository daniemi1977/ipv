/**
 * IPV Video Wall v7.0 - AJAX Handler
 * 
 * Features:
 * - Real-time filter changes (no page reload)
 * - Load more blocks with same filters
 * - Animation on new content
 * - State management
 */

(function($) {
    'use strict';

    // Configuration
    const IPV_VideoWallV7 = {
        // State
        currentBlock: 0,
        currentFilters: {
            categoria: '',
            relatore: '',
            anno: ''
        },
        totalVideos: 0,
        isLoading: false,

        // Init
        init: function() {
            this.cacheElements();
            this.bindEvents();
        },

        // Cache DOM elements
        cacheElements: function() {
            this.$container = $('.ipv-video-wall-container');
            this.$wall = $('.ipv-video-wall');
            this.$content = $('.ipv-video-wall-content');
            this.$loadMoreBtn = $('.ipv-load-more-btn');
            this.$loading = $('.ipv-wall-loading');
            this.$filterInputs = $('.ipv-filter-input');
            this.$resetBtn = $('#ipv-reset-filters');
        },

        // Bind events
        bindEvents: function() {
            const self = this;

            // Filter changes
            this.$filterInputs.on('change', function() {
                self.onFilterChange();
            });

            // Load more button
            this.$loadMoreBtn.on('click', function(e) {
                e.preventDefault();
                self.loadMoreVideos();
            });

            // Reset filters
            this.$resetBtn.on('click', function() {
                self.resetFilters();
            });
        },

        // Handle filter change
        onFilterChange: function() {
            // Update filter state
            this.currentFilters.categoria = $('#ipv-filter-categoria').val();
            this.currentFilters.relatore = $('#ipv-filter-relatore').val();
            this.currentFilters.anno = $('#ipv-filter-anno').val();

            // Reset block counter
            this.currentBlock = 0;

            // Reload first block
            this.loadVideos(0);
        },

        // Load videos via AJAX
        loadVideos: function(blockNumber) {
            const self = this;

            if (this.isLoading) {
                return;
            }

            this.isLoading = true;
            this.showLoading();

            $.ajax({
                url: ipvVideoWallV7.ajaxUrl,
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'ipv_v7_load_videos',
                    nonce: ipvVideoWallV7.nonce,
                    block_number: blockNumber,
                    categoria: this.currentFilters.categoria,
                    relatore: this.currentFilters.relatore,
                    anno: this.currentFilters.anno
                },
                success: function(response) {
                    if (response.success) {
                        self.onVideosLoaded(response.data, blockNumber);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', error);
                    self.hideLoading();
                },
                complete: function() {
                    self.isLoading = false;
                    self.hideLoading();
                }
            });
        },

        // Handle videos loaded
        onVideosLoaded: function(data, blockNumber) {
            const self = this;

            if (blockNumber === 0) {
                // First block: replace all content
                this.$content.html(data.html);
                this.currentBlock = 0;

                // Update load more button
                this.updateLoadMoreButton(data.has_more, data.total);
            } else {
                // Additional blocks: append
                this.$content.append(data.html);
                this.currentBlock = blockNumber;

                // Scroll to new content smoothly
                setTimeout(function() {
                    const newBlock = self.$content.find('[data-block="' + blockNumber + '"]');
                    if (newBlock.length) {
                        $('html, body').animate({
                            scrollTop: newBlock.offset().top - 200
                        }, 500);
                    }
                }, 100);

                // Update load more button
                if (!data.has_more) {
                    self.$loadMoreBtn.hide();
                } else {
                    self.$loadMoreBtn.data('block', blockNumber + 1);
                }
            }

            // Update total
            this.totalVideos = data.total;
            this.updateLoadMoreInfo();
        },

        // Load more videos
        loadMoreVideos: function() {
            const nextBlock = this.currentBlock + 1;
            this.loadVideos(nextBlock);
        },

        // Update load more button
        updateLoadMoreButton: function(hasMore, total) {
            if (hasMore) {
                this.$loadMoreBtn.show();
                this.$loadMoreBtn.prop('disabled', false);
            } else {
                this.$loadMoreBtn.hide();
            }
        },

        // Update load more info
        updateLoadMoreInfo: function() {
            const loaded = (this.currentBlock + 1) * 5;
            const total = this.totalVideos;

            this.$container.find('.ipv-loaded-count').text(Math.min(loaded, total));
            this.$container.find('.ipv-total-count').text(total);
        },

        // Reset filters
        resetFilters: function() {
            this.$filterInputs.val('');
            this.currentFilters = {
                categoria: '',
                relatore: '',
                anno: ''
            };
            this.currentBlock = 0;
            this.loadVideos(0);
        },

        // Show loading spinner
        showLoading: function() {
            this.$loading.show();
        },

        // Hide loading spinner
        hideLoading: function() {
            this.$loading.hide();
        }
    };

    // Initialize on document ready
    $(document).ready(function() {
        IPV_VideoWallV7.init();
    });

})(jQuery);
