<?php
/**
 * Plugin Name: IPV Production System Pro
 * Plugin URI: https://aiedintorni.it
 * Description: Professional video production system for YouTube content creators: multi-source imports (YouTube/Vimeo/Dailymotion), AI-powered transcriptions, automated descriptions with Golden Prompt, video wall with AJAX filters, and Elementor integration.
 * Version: 9.2.2
 * Author: Daniele / IPV
 * Text Domain: ipv-production-system-pro
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * 
 * CHANGELOG v9.2.2:
 * - Feature: Added [ipv_coming_soon] shortcode for premieres/scheduled videos
 * - Feature: Download Golden Prompt button in Settings
 * - Feature: Template & Appearance settings (colors, layouts, display options)
 * - Feature: Video player behavior (embed, modal, redirect)
 * - Feature: Show/hide elements (views, duration, date, categories, speakers)
 * - Feature: Default video wall layout (grid, list, masonry)
 * - Feature: Videos per page setting
 * 
 * CHANGELOG v9.2.1:
 * - Fix: Added missing "Bulk Import" menu from v7.9.40
 * - Fix: Added missing "Video Wall" menu from v7.9.40
 * - Feature: Added "Language" menu for multilingua management
 * - Fix: Complete menu parity with v7.9.40
 * 
 * CHANGELOG v9.2.0:
 * - Feature: Restored SupaData multiple API keys system (3 separate keys)
 * - Feature: Restored key rotation mode (Fixed / Round-Robin)
 * - Feature: Key status indicator showing current rotation state
 * - Fix: Full backward compatibility with v7.9.40 settings
 * - Maintained: All v9.1.7 enterprise features (Elementor, multilingua, REST API, etc.)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ============================================
// CONSTANTS
// ============================================

define( 'IPV_PROD_VERSION', '9.2.2' );
define( 'IPV_PROD_PLUGIN_FILE', __FILE__ );
define( 'IPV_PROD_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'IPV_PROD_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// ============================================
// LOAD TEXT DOMAIN
// ============================================

function ipv_prod_load_textdomain() {
    // Se il Language Manager ha già caricato una lingua specifica, non sovrascrivere
    $plugin_locale = get_option( 'ipv_plugin_language', 'auto' );
    
    if ( $plugin_locale !== 'auto' ) {
        // La lingua è già stata caricata dal Language Manager
        return;
    }
    
    // Altrimenti usa il comportamento standard di WordPress
    load_plugin_textdomain(
        'ipv-production-system-pro',
        false,
        dirname( plugin_basename( __FILE__ ) ) . '/languages'
    );
}
add_action( 'plugins_loaded', 'ipv_prod_load_textdomain', 5 );

// ============================================
// LOAD CORE HELPERS (Prima dell'autoloader)
// ============================================
require_once IPV_PROD_PLUGIN_DIR . 'includes/class-helpers.php';

// ============================================
// LANGUAGE MANAGER (Prima del textdomain standard)
// ============================================
require_once IPV_PROD_PLUGIN_DIR . 'includes/class-language-manager.php';

// ============================================
// CPT (Deve essere caricato presto per l'hook init)
// ============================================
require_once IPV_PROD_PLUGIN_DIR . 'includes/class-cpt.php';

// ============================================
// VIDEO LIST COLUMNS (Colonne personalizzate nella lista video)
// ============================================
require_once IPV_PROD_PLUGIN_DIR . 'includes/class-video-list-columns.php';

// ============================================
// TAXONOMY MANAGER
// ============================================
require_once IPV_PROD_PLUGIN_DIR . 'includes/class-taxonomy-manager.php';

// ============================================
// AUTOLOAD CLASSES
// ============================================

spl_autoload_register( function( $class ) {
    // Mappa prefissi alle convenzioni di naming file
    $prefix_map = [
        'IPV_Prod_' => 'class-',       // IPV_Prod_Queue -> class-queue.php
        'IPV_'      => 'class-ipv-',   // IPV_Markdown -> class-ipv-markdown.php
    ];

    foreach ( $prefix_map as $prefix => $file_prefix ) {
        if ( strpos( $class, $prefix ) === 0 ) {
            $class_name = str_replace( $prefix, '', $class );
            $class_file = strtolower( str_replace( '_', '-', $class_name ) );
            
            $file = IPV_PROD_PLUGIN_DIR . 'includes/' . $file_prefix . $class_file . '.php';
            
            if ( file_exists( $file ) ) {
                require_once $file;
                return;
            }
            
            // Fallback: prova senza prefisso ipv-
            if ( $prefix === 'IPV_' ) {
                $file = IPV_PROD_PLUGIN_DIR . 'includes/class-' . $class_file . '.php';
                if ( file_exists( $file ) ) {
                    require_once $file;
                    return;
                }
            }
        }
    }
} );

// ============================================
// LEGACY HELPER FUNCTIONS (Per retrocompatibilità)
// ============================================

/**
 * @deprecated Use IPV_Prod_Helpers::duration_to_seconds()
 */
function ipv_duration_to_seconds( $duration ) {
    return IPV_Prod_Helpers::duration_to_seconds( $duration );
}

/**
 * @deprecated Use IPV_Prod_Helpers::get_formatted_duration()
 */
function ipv_get_formatted_duration( $post_id ) {
    return IPV_Prod_Helpers::get_formatted_duration( $post_id );
}

// ============================================
// MAIN PLUGIN CLASS
// ============================================

class IPV_Production_System_Pro {

    private static $instance = null;

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // CPT è già inizializzato tramite require_once (class-cpt.php ha init() alla fine)

        // Settings
        add_action( 'admin_init', [ 'IPV_Prod_Settings', 'register_settings' ] );

        // Video Wall
        IPV_Prod_Video_Wall::init();
        IPV_Prod_Video_Wall_Admin::init();

        // Coming Soon (shortcode [ipv_coming_soon])
        IPV_Prod_Coming_Soon::init();

        // Admin menu
        add_action( 'admin_menu', [ $this, 'register_menu' ] );

        // Admin assets
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );

        // Cron Schedules
        add_filter( 'cron_schedules', [ $this, 'add_cron_schedules' ] );
        
        // Cron Actions - SISTEMA UNIFICATO
        add_action( 'ipv_prod_process_queue', [ 'IPV_Prod_Queue', 'process_queue' ] );
        add_action( 'ipv_prod_update_youtube_data', [ 'IPV_Prod_Queue', 'update_all_youtube_data' ] );

        // Auto-schedule CRON se non esiste
        add_action( 'admin_init', [ $this, 'ensure_cron_scheduled' ] );

        // AJAX
        add_action( 'wp_ajax_ipv_prod_get_stats', [ $this, 'ajax_get_stats' ] );
        add_action( 'wp_ajax_ipv_prod_process_queue', [ $this, 'ajax_process_queue' ] );
        add_action( 'wp_ajax_ipv_prod_start_cron', [ $this, 'ajax_start_cron' ] );

        // Activation/Deactivation
        register_activation_hook( IPV_PROD_PLUGIN_FILE, [ $this, 'activate' ] );
        register_deactivation_hook( IPV_PROD_PLUGIN_FILE, [ $this, 'deactivate' ] );

        // Save duration on post save
        add_action( 'save_post_ipv_video', [ $this, 'save_duration_seconds' ] );

        // Markdown filter
        add_filter( 'the_content', [ $this, 'filter_video_content' ] );
    }

    /**
     * Add custom cron schedules
     */
    public function add_cron_schedules( $schedules ) {
        $schedules['ipv_every_5_minutes'] = [
            'interval' => 300,
            'display'  => __( 'Every 5 Minutes', 'ipv-production-system-pro' ),
        ];
        return $schedules;
    }

    /**
     * Register admin menu
     */
    public function register_menu() {
        // Main menu
        add_menu_page(
            __( 'IPV Production System', 'ipv-production-system-pro' ),
            __( 'IPV Production', 'ipv-production-system-pro' ),
            'manage_options',
            'ipv-production',
            [ $this, 'render_dashboard' ],
            'dashicons-video-alt3',
            25
        );

        // Dashboard (duplica main per avere submenu corretto)
        add_submenu_page(
            'ipv-production',
            __( 'Dashboard', 'ipv-production-system-pro' ),
            __( 'Dashboard', 'ipv-production-system-pro' ),
            'manage_options',
            'ipv-production'
        );

        // Import Video
        add_submenu_page(
            'ipv-production',
            __( 'Import Video', 'ipv-production-system-pro' ),
            __( 'Import Video', 'ipv-production-system-pro' ),
            'manage_options',
            'ipv-production-import',
            [ 'IPV_Prod_YouTube_Importer', 'render_page' ]
        );

        // Auto-Import RSS (nome corretto come nelle tabs)
        add_submenu_page(
            'ipv-production',
            __( 'Auto-Import RSS', 'ipv-production-system-pro' ),
            __( 'Auto-Import RSS', 'ipv-production-system-pro' ),
            'manage_options',
            'ipv-production-rss',
            [ 'IPV_Prod_RSS_Importer', 'render_settings_page' ]
        );

        // Queue (nome breve come nelle tabs)
        add_submenu_page(
            'ipv-production',
            __( 'Queue', 'ipv-production-system-pro' ),
            __( 'Queue', 'ipv-production-system-pro' ),
            'manage_options',
            'ipv-production-queue',
            [ 'IPV_Prod_Queue', 'render_admin_page' ]
        );

        // Bulk Import
        add_submenu_page(
            'ipv-production',
            __( 'Bulk Import', 'ipv-production-system-pro' ),
            __( 'Bulk Import', 'ipv-production-system-pro' ),
            'manage_options',
            'ipv-production-bulk-import',
            [ 'IPV_Prod_Bulk_Import', 'render_page' ]
        );

        // Video Wall
        add_submenu_page(
            'ipv-production',
            __( 'Video Wall', 'ipv-production-system-pro' ),
            __( 'Video Wall', 'ipv-production-system-pro' ),
            'manage_options',
            'ipv-production-video-wall',
            [ 'IPV_Prod_Video_Wall_Admin', 'render_admin_page' ]
        );

        // Bulk Tools
        add_submenu_page(
            'ipv-production',
            __( 'Bulk Tools', 'ipv-production-system-pro' ),
            __( 'Bulk Tools', 'ipv-production-system-pro' ),
            'manage_options',
            'ipv-production-bulk',
            [ 'IPV_Prod_Bulk_Tools', 'render_page' ]
        );

        // Settings
        add_submenu_page(
            'ipv-production',
            __( 'Settings', 'ipv-production-system-pro' ),
            __( 'Settings', 'ipv-production-system-pro' ),
            'manage_options',
            'ipv-production-settings',
            [ 'IPV_Prod_Settings', 'render_page' ]
        );

        // Language
        add_submenu_page(
            'ipv-production',
            __( 'Language', 'ipv-production-system-pro' ),
            __( 'Language', 'ipv-production-system-pro' ),
            'manage_options',
            'ipv-production-language',
            [ 'IPV_Prod_Language_Manager', 'render_page' ]
        );
    }

    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets( $hook ) {
        // Solo nelle pagine del plugin
        if ( strpos( $hook, 'ipv-production' ) === false && get_post_type() !== 'ipv_video' ) {
            return;
        }

        // Bootstrap 5 CSS
        wp_enqueue_style(
            'bootstrap',
            'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css',
            [],
            '5.3.2'
        );

        // Bootstrap Icons
        wp_enqueue_style(
            'bootstrap-icons',
            'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css',
            [],
            '1.11.1'
        );

        // Plugin CSS
        wp_enqueue_style(
            'ipv-prod-admin',
            IPV_PROD_PLUGIN_URL . 'assets/css/admin.css',
            [ 'bootstrap', 'bootstrap-icons' ],
            IPV_PROD_VERSION
        );

        // Bootstrap JS
        wp_enqueue_script(
            'bootstrap',
            'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js',
            [ 'jquery' ],
            '5.3.2',
            true
        );

        // Plugin JS
        wp_enqueue_script(
            'ipv-prod-admin',
            IPV_PROD_PLUGIN_URL . 'assets/js/admin.js',
            [ 'jquery', 'bootstrap' ],
            IPV_PROD_VERSION,
            true
        );

        wp_localize_script( 'ipv-prod-admin', 'ipv_admin', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'ipv_admin_nonce' ),
            'i18n'     => [
                'confirm_delete' => __( 'Are you sure?', 'ipv-production-system-pro' ),
                'processing'     => __( 'Processing...', 'ipv-production-system-pro' ),
                'success'        => __( 'Success!', 'ipv-production-system-pro' ),
                'error'          => __( 'Error occurred', 'ipv-production-system-pro' ),
            ],
        ] );
    }

    /**
     * Render Dashboard
     */
    public function render_dashboard() {
        $total_videos = wp_count_posts( 'ipv_video' );
        $published = isset( $total_videos->publish ) ? $total_videos->publish : 0;
        $draft = isset( $total_videos->draft ) ? $total_videos->draft : 0;
        
        $queue_stats = IPV_Prod_Queue::get_stats();
        
        $supadata_key = get_option( 'ipv_supadata_api_key', '' );
        $openai_key   = get_option( 'ipv_openai_api_key', '' );
        $youtube_key  = get_option( 'ipv_youtube_api_key', '' );
        
        $next_cron = wp_next_scheduled( 'ipv_prod_process_queue' );
        ?>
        <div class="wrap ipv-prod-wrap">
            <div class="ipv-prod-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h1 class="mb-1">
                            <i class="bi bi-youtube text-white me-2"></i>
                            IPV Production System Pro
                        </h1>
                        <p class="text-muted mb-0">
                            <?php esc_html_e( 'Video production management dashboard', 'ipv-production-system-pro' ); ?>
                        </p>
                    </div>
                    <div>
                        <span class="badge bg-light text-dark">v<?php echo esc_html( IPV_PROD_VERSION ); ?></span>
                    </div>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="row g-4 mb-4">
                <div class="col-md-3">
                    <div class="card shadow-sm h-100">
                        <div class="card-body text-center">
                            <i class="bi bi-collection-play fs-1 text-primary mb-2"></i>
                            <h3 class="mb-1"><?php echo esc_html( $published ); ?></h3>
                            <p class="text-muted mb-0"><?php esc_html_e( 'Published Videos', 'ipv-production-system-pro' ); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card shadow-sm h-100">
                        <div class="card-body text-center">
                            <i class="bi bi-hourglass-split fs-1 text-warning mb-2"></i>
                            <h3 class="mb-1"><?php echo esc_html( $queue_stats['pending'] ?? 0 ); ?></h3>
                            <p class="text-muted mb-0"><?php esc_html_e( 'In Queue', 'ipv-production-system-pro' ); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card shadow-sm h-100">
                        <div class="card-body text-center">
                            <i class="bi bi-check-circle fs-1 text-success mb-2"></i>
                            <h3 class="mb-1"><?php echo esc_html( $queue_stats['done'] ?? 0 ); ?></h3>
                            <p class="text-muted mb-0"><?php esc_html_e( 'Processed', 'ipv-production-system-pro' ); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card shadow-sm h-100">
                        <div class="card-body text-center">
                            <i class="bi bi-clock-history fs-1 text-info mb-2"></i>
                            <h3 class="mb-1"><?php echo $next_cron ? esc_html( date_i18n( 'H:i', $next_cron ) ) : 'N/A'; ?></h3>
                            <p class="text-muted mb-0"><?php esc_html_e( 'Next CRON', 'ipv-production-system-pro' ); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- API Status -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="bi bi-key me-2"></i><?php esc_html_e( 'API Keys Status', 'ipv-production-system-pro' ); ?></h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <?php if ( $supadata_key ) : ?>
                                <i class="bi bi-check-circle-fill text-success"></i> SupaData: <strong><?php esc_html_e( 'OK', 'ipv-production-system-pro' ); ?></strong>
                            <?php else : ?>
                                <i class="bi bi-x-circle-fill text-danger"></i> SupaData: <strong><?php esc_html_e( 'Missing', 'ipv-production-system-pro' ); ?></strong>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-4">
                            <?php if ( $openai_key ) : ?>
                                <i class="bi bi-check-circle-fill text-success"></i> OpenAI: <strong><?php esc_html_e( 'OK', 'ipv-production-system-pro' ); ?></strong>
                            <?php else : ?>
                                <i class="bi bi-x-circle-fill text-danger"></i> OpenAI: <strong><?php esc_html_e( 'Missing', 'ipv-production-system-pro' ); ?></strong>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-4">
                            <?php if ( $youtube_key ) : ?>
                                <i class="bi bi-check-circle-fill text-success"></i> YouTube: <strong><?php esc_html_e( 'OK', 'ipv-production-system-pro' ); ?></strong>
                            <?php else : ?>
                                <i class="bi bi-x-circle-fill text-danger"></i> YouTube: <strong><?php esc_html_e( 'Missing', 'ipv-production-system-pro' ); ?></strong>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="bi bi-lightning me-2"></i><?php esc_html_e( 'Quick Actions', 'ipv-production-system-pro' ); ?></h5>
                </div>
                <div class="card-body">
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=ipv-production-import' ) ); ?>" class="btn btn-primary me-2">
                        <i class="bi bi-youtube me-1"></i> <?php esc_html_e( 'Import Video', 'ipv-production-system-pro' ); ?>
                    </a>
                    <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=ipv_video' ) ); ?>" class="btn btn-outline-secondary me-2">
                        <i class="bi bi-list me-1"></i> <?php esc_html_e( 'Manage Videos', 'ipv-production-system-pro' ); ?>
                    </a>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=ipv-production-settings' ) ); ?>" class="btn btn-outline-secondary">
                        <i class="bi bi-gear me-1"></i> <?php esc_html_e( 'Settings', 'ipv-production-system-pro' ); ?>
                    </a>
                </div>
            </div>

            <div class="mt-4 text-muted small">
                <strong><?php esc_html_e( 'Shortcode:', 'ipv-production-system-pro' ); ?></strong> 
                <code>[ipv_video_wall]</code> <?php esc_html_e( 'or', 'ipv-production-system-pro' ); ?> 
                <code>[ipv_video_wall show_filters="yes"]</code>
            </div>
        </div>
        <?php
    }

    /**
     * Filter video content for markdown
     */
    public function filter_video_content( $content ) {
        if ( get_post_type() !== 'ipv_video' ) {
            return $content;
        }

        $md = get_post_meta( get_the_ID(), IPV_Prod_Helpers::META_AI_DESCRIPTION, true );
        if ( $md && class_exists( 'IPV_Markdown_Full' ) ) {
            return IPV_Markdown_Full::parse( $md );
        }

        return $content;
    }

    /**
     * Save duration in seconds
     */
    public function save_duration_seconds( $post_id ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        $duration_seconds = get_post_meta( $post_id, IPV_Prod_Helpers::META_YT_DURATION_SEC, true );
        if ( empty( $duration_seconds ) ) {
            $duration_iso = get_post_meta( $post_id, IPV_Prod_Helpers::META_YT_DURATION, true );
            if ( $duration_iso ) {
                $seconds = IPV_Prod_Helpers::duration_to_seconds( $duration_iso );
                update_post_meta( $post_id, IPV_Prod_Helpers::META_YT_DURATION_SEC, $seconds );
            }
        }
    }

    /**
     * AJAX: Get stats
     */
    public function ajax_get_stats() {
        check_ajax_referer( 'ipv_admin_nonce', 'nonce' );
        
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }

        $total = wp_count_posts( 'ipv_video' );
        wp_send_json_success( [
            'total_videos' => isset( $total->publish ) ? $total->publish : 0,
            'pending'      => isset( $total->pending ) ? $total->pending : 0,
        ] );
    }

    /**
     * AJAX: Process queue
     */
    public function ajax_process_queue() {
        check_ajax_referer( 'ipv_admin_nonce', 'nonce' );
        
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }

        if ( class_exists( 'IPV_Prod_Queue' ) ) {
            IPV_Prod_Queue::process_queue();
        }
        
        wp_send_json_success( [ 'message' => __( 'Queue processed', 'ipv-production-system-pro' ) ] );
    }

    /**
     * Ensure CRON is scheduled
     */
    public function ensure_cron_scheduled() {
        // Queue processing (every 5 minutes)
        if ( ! wp_next_scheduled( 'ipv_prod_process_queue' ) ) {
            wp_schedule_event( time(), 'ipv_every_5_minutes', 'ipv_prod_process_queue' );
            IPV_Prod_Helpers::log( 'CRON auto-scheduled: process_queue' );
        }

        // YouTube data update (hourly)
        if ( ! wp_next_scheduled( 'ipv_prod_update_youtube_data' ) ) {
            wp_schedule_event( time(), 'hourly', 'ipv_prod_update_youtube_data' );
            IPV_Prod_Helpers::log( 'CRON auto-scheduled: update_youtube_data' );
        }
    }

    /**
     * AJAX: Start/Restart CRON
     */
    public function ajax_start_cron() {
        check_ajax_referer( 'ipv_admin_nonce', 'nonce' );
        
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }

        // Remove existing cron
        $timestamp = wp_next_scheduled( 'ipv_prod_process_queue' );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, 'ipv_prod_process_queue' );
        }

        // Schedule new cron
        wp_schedule_event( time(), 'ipv_every_5_minutes', 'ipv_prod_process_queue' );
        
        // Process immediately
        if ( class_exists( 'IPV_Prod_Queue' ) ) {
            IPV_Prod_Queue::process_queue();
        }

        $next = wp_next_scheduled( 'ipv_prod_process_queue' );
        
        wp_send_json_success( [ 
            'message'  => __( 'CRON started!', 'ipv-production-system-pro' ),
            'next_run' => $next ? date_i18n( 'H:i:s', $next ) : 'N/A',
            'status'   => $next ? 'active' : 'error',
        ] );
    }

    /**
     * Activation
     */
    public function activate() {
        // Schedule CRON: queue processing (every 5 minutes)
        if ( ! wp_next_scheduled( 'ipv_prod_process_queue' ) ) {
            wp_schedule_event( time(), 'ipv_every_5_minutes', 'ipv_prod_process_queue' );
        }

        // Schedule CRON: YouTube update (hourly)
        if ( ! wp_next_scheduled( 'ipv_prod_update_youtube_data' ) ) {
            wp_schedule_event( time(), 'hourly', 'ipv_prod_update_youtube_data' );
        }

        // Create queue table
        if ( class_exists( 'IPV_Prod_Queue' ) ) {
            IPV_Prod_Queue::create_table();
        }

        // Flush rewrite rules
        flush_rewrite_rules();
    }

    /**
     * Deactivation
     */
    public function deactivate() {
        // Remove CRON: queue processing
        $timestamp = wp_next_scheduled( 'ipv_prod_process_queue' );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, 'ipv_prod_process_queue' );
        }

        // Remove CRON: YouTube update
        $timestamp = wp_next_scheduled( 'ipv_prod_update_youtube_data' );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, 'ipv_prod_update_youtube_data' );
        }
    }
}

// ============================================
// INIT
// ============================================

add_action( 'plugins_loaded', function() {
    IPV_Production_System_Pro::get_instance();
}, 10 );
