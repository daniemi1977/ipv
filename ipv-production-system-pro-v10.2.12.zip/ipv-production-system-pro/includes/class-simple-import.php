<?php
/**
 * IPV Simple Import - Import e Pubblica Subito
 * 
 * Importa video da YouTube e li pubblica immediatamente,
 * senza aspettare trascrizione/AI.
 * 
 * @version 9.1.0
 * CHANGELOG v9.1.0:
 * - Rimosso extract_video_id() duplicato → usa IPV_Prod_Helpers
 * - Rimosso video_exists() duplicato → usa IPV_Prod_Helpers  
 * - Rimosso set_thumbnail() duplicato → usa IPV_Prod_Helpers
 * - Usa costanti META_* standardizzate
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class IPV_Prod_Simple_Import {

    /**
     * Init
     */
    public static function init() {
        add_action( 'admin_post_ipv_simple_import', [ __CLASS__, 'handle_import' ] );
        add_action( 'wp_ajax_ipv_quick_import', [ __CLASS__, 'ajax_quick_import' ] );
    }

    /**
     * Handle form submission
     */
    public static function handle_import() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Unauthorized' );
        }

        check_admin_referer( 'ipv_simple_import_nonce' );

        $url = isset( $_POST['youtube_url'] ) ? sanitize_text_field( wp_unslash( $_POST['youtube_url'] ) ) : '';
        
        if ( empty( $url ) ) {
            wp_safe_redirect( admin_url( 'edit.php?post_type=ipv_video&page=ipv-import&error=url_empty' ) );
            exit;
        }

        $result = self::import_video( $url );

        if ( is_wp_error( $result ) ) {
            wp_safe_redirect( admin_url( 'edit.php?post_type=ipv_video&page=ipv-import&error=' . urlencode( $result->get_error_message() ) ) );
        } else {
            wp_safe_redirect( admin_url( 'edit.php?post_type=ipv_video&page=ipv-import&success=1&post_id=' . $result ) );
        }
        exit;
    }

    /**
     * AJAX quick import
     */
    public static function ajax_quick_import() {
        check_ajax_referer( 'ipv_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }

        $url = isset( $_POST['url'] ) ? sanitize_text_field( wp_unslash( $_POST['url'] ) ) : '';
        
        if ( empty( $url ) ) {
            wp_send_json_error( __( 'URL missing', 'ipv-production-system-pro' ) );
        }

        $result = self::import_video( $url );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
        }

        wp_send_json_success( [
            'post_id'   => $result,
            'edit_link' => get_edit_post_link( $result, 'raw' ),
            'view_link' => get_permalink( $result ),
            'title'     => get_the_title( $result ),
        ] );
    }

    /**
     * Import a single video and publish immediately
     */
    public static function import_video( $url ) {
        // Usa helper centralizzato per estrazione ID
        $video_id = IPV_Prod_Helpers::extract_youtube_id( $url );
        
        if ( ! $video_id ) {
            return new WP_Error( 'invalid_url', __( 'Invalid YouTube URL', 'ipv-production-system-pro' ) );
        }

        // Usa helper centralizzato per verifica duplicati
        $existing = IPV_Prod_Helpers::video_exists( $video_id );
        if ( $existing ) {
            return new WP_Error( 
                'duplicate', 
                sprintf( __( 'Video already imported (ID: %d)', 'ipv-production-system-pro' ), $existing ) 
            );
        }

        // v10.2.5 FIX - Improved video data retrieval with better logging
        $video_data = null;
        $data_source = 'fallback';

        // v10.2.9 - Clear cache to ensure fresh data (like bulk refresh does)
        delete_transient( 'ipv_yt_video_' . $video_id );

        // v10.2.9 - Enhanced debug logging
        IPV_Prod_Logger::log( '=== IMPORT VIDEO START ===', [
            'video_id' => $video_id,
            'license_active' => IPV_Prod_API_Client::is_license_active()
        ]);

        // Try server API first
        $api_result = IPV_Prod_YouTube_API::get_video_data( $video_id );
        
        // v10.2.9 - Log API result
        IPV_Prod_Logger::log( 'API Result Check', [
            'is_error' => is_wp_error( $api_result ),
            'has_title' => isset( $api_result['title'] ) ? 'YES: ' . $api_result['title'] : 'NO',
            'result_keys' => is_array( $api_result ) ? array_keys( $api_result ) : 'NOT_ARRAY'
        ]);
        
        if ( ! is_wp_error( $api_result ) && ! empty( $api_result['title'] ) ) {
            $video_data = $api_result;
            $data_source = 'api';
            IPV_Prod_Helpers::log( '✅ Video data from API SUCCESS', [
                'video_id' => $video_id,
                'title' => $video_data['title']
            ]);
        } else {
            // Log API failure
            if ( is_wp_error( $api_result ) ) {
                IPV_Prod_Helpers::log( '❌ API FAILED - trying oEmbed', [
                    'video_id' => $video_id,
                    'error_code' => $api_result->get_error_code(),
                    'error_message' => $api_result->get_error_message()
                ]);
            } else {
                IPV_Prod_Helpers::log( '⚠️ API returned but no title - trying oEmbed', [
                    'video_id' => $video_id,
                    'api_result_type' => gettype( $api_result ),
                    'api_result_keys' => is_array( $api_result ) ? implode( ', ', array_keys( $api_result ) ) : 'N/A'
                ]);
            }
            
            // Fallback to oEmbed
            $video_data = self::get_youtube_data_oembed( $video_id );
            $data_source = 'oembed';
            
            IPV_Prod_Helpers::log( 'Video data from oEmbed', [
                'video_id' => $video_id,
                'title' => $video_data['title'] ?? 'N/A',
                'has_title' => ! empty( $video_data['title'] ) && strpos( $video_data['title'], 'Video YouTube' ) === false
            ]);
        }

        // Create post
        $post_data = [
            'post_type'   => 'ipv_video',
            'post_status' => 'publish',
            'post_title'  => $video_data['title'] ?? 'Video YouTube ' . $video_id,
            'post_content' => $video_data['description'] ?? '',
        ];

        // Use YouTube publish date as post_date if available
        if ( ! empty( $video_data['published_at'] ) ) {
            $post_data['post_date'] = get_date_from_gmt( $video_data['published_at'] );
            $post_data['post_date_gmt'] = $video_data['published_at'];
        }

        $post_id = wp_insert_post( $post_data );

        if ( ! $post_id || is_wp_error( $post_id ) ) {
            return new WP_Error( 'insert_failed', __( 'Failed to create post', 'ipv-production-system-pro' ) );
        }

        // Save basic meta
        update_post_meta( $post_id, IPV_Prod_Helpers::META_VIDEO_ID, $video_id );
        update_post_meta( $post_id, IPV_Prod_Helpers::META_YOUTUBE_URL, $url );
        update_post_meta( $post_id, IPV_Prod_Helpers::META_IMPORT_DATE, current_time( 'mysql' ) );
        update_post_meta( $post_id, IPV_Prod_Helpers::META_VIDEO_SOURCE, 'youtube' );

        // v10.2.2 FIX - Save complete YouTube metadata using centralized method
        // This ensures all metadata is saved consistently, including title
        if ( ! empty( $video_data ) && isset( $video_data['video_id'] ) ) {
            // Full API data available - save using centralized method
            IPV_Prod_YouTube_API::save_video_meta( $post_id, $video_data );

            // Tags
            if ( ! empty( $video_data['tags'] ) ) {
                wp_set_object_terms( $post_id, $video_data['tags'], 'post_tag', true );
            }
        }

        // Usa helper centralizzato per thumbnail
        IPV_Prod_Helpers::set_youtube_thumbnail( 
            $post_id, 
            $video_id, 
            $video_data['thumbnail_url'] ?? null 
        );

        // Log
        IPV_Prod_Helpers::log( 'Video imported and published', [
            'post_id'  => $post_id,
            'video_id' => $video_id,
        ] );

        return $post_id;
    }

    /**
     * Get basic video data from YouTube oEmbed (fallback method)
     * v10.2.5 - Enhanced fallback with better error handling
     */
    public static function get_youtube_data_oembed( $video_id ) {
        // Default data
        $data = [
            'title'       => 'Video YouTube ' . $video_id,
            'description' => '',
        ];

        // Try oEmbed (no API key required)
        $oembed_url = 'https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=' . $video_id . '&format=json';
        
        $oembed_response = wp_remote_get( $oembed_url, [
            'timeout' => 30,
            'sslverify' => false, // Some hosts have SSL issues
            'user-agent' => 'Mozilla/5.0 (compatible; WordPress/' . get_bloginfo( 'version' ) . ')',
        ]);

        if ( is_wp_error( $oembed_response ) ) {
            IPV_Prod_Helpers::log( 'oEmbed request failed', [
                'video_id' => $video_id,
                'error' => $oembed_response->get_error_message()
            ]);
        } elseif ( wp_remote_retrieve_response_code( $oembed_response ) === 200 ) {
            $oembed_data = json_decode( wp_remote_retrieve_body( $oembed_response ), true );
            if ( $oembed_data && ! empty( $oembed_data['title'] ) ) {
                $data['title'] = $oembed_data['title'];
                $data['channel_title'] = $oembed_data['author_name'] ?? '';
                $data['thumbnail_url'] = $oembed_data['thumbnail_url'] ?? '';
                
                IPV_Prod_Helpers::log( 'oEmbed success', [
                    'video_id' => $video_id,
                    'title' => $data['title']
                ]);
            } else {
                IPV_Prod_Helpers::log( 'oEmbed empty response', [
                    'video_id' => $video_id,
                    'response' => substr( wp_remote_retrieve_body( $oembed_response ), 0, 200 )
                ]);
            }
        } else {
            IPV_Prod_Helpers::log( 'oEmbed HTTP error', [
                'video_id' => $video_id,
                'status' => wp_remote_retrieve_response_code( $oembed_response )
            ]);
        }

        // Ensure we have a thumbnail URL
        if ( empty( $data['thumbnail_url'] ) ) {
            $data['thumbnail_url'] = 'https://img.youtube.com/vi/' . $video_id . '/maxresdefault.jpg';
        }

        return $data;
    }
}

// Backwards compatibility alias (old class name)
if ( ! class_exists( 'IPV_Simple_Import' ) ) {
    class_alias( 'IPV_Prod_Simple_Import', 'IPV_Simple_Import' );
}

// Initialize
add_action( 'init', [ 'IPV_Prod_Simple_Import', 'init' ] );

