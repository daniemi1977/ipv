/**
 * IPV Pro Vendor Admin JavaScript
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        console.log('IPV Pro Vendor Admin JS loaded');

        // Add any admin JavaScript functionality here
        // Example: AJAX calls, UI enhancements, etc.
    });

})(jQuery);
